﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 14.9.2020 г.
 * Time: 11:19
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace planets
{
	class Planet
	{
		public string plName;
		public double diameter;
		public double mass;		// измерва се в земни маси
		public double days;		// денонощие (дни)
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Planet pl = new Planet();
			
			Console.Write("Planet: ");
			pl.plName = Console.ReadLine();
			if(pl.plName == "Mercury")
			{
				pl.diameter = 0.382;
				pl.mass = 0.06;
				pl.days = 58.6;
			}
			else if(pl.plName == "Venus")
			{
				pl.diameter = 0.949;
				pl.mass = 0.82;
				pl.days = -243;	// върти се по посока на часовниковата стрелка
			}
			else if(pl.plName == "Earth")
			{
				pl.diameter = 1.0;
				pl.mass = 1.0;
				pl.days = 1.0;
			}
			else if(pl.plName == "Mars")
			{
				pl.diameter = 0.53;
				pl.mass = 0.11;
				pl.days = 1.03;
			}
			else if(pl.plName == "Jupiter")
			{
				pl.diameter = 11.2;
				pl.mass = 318;
				pl.days = 0.414;
			}
			else if(pl.plName == "Saturn")
			{
				pl.diameter = 9.41;
				pl.mass = 95;
				pl.days = 0.426;
			}
			else if(pl.plName == "Uranus")
			{
				pl.diameter = 3.98;
				pl.mass = 14.6;
				pl.days = 0.718;
			}
			else if(pl.plName == "Neptune")
			{
				pl.diameter = 3.81;
				pl.mass = 17.2;
				pl.days = 0.671;
			}
			
			// Приемаме, че името на планетата е въведено коректно
			Console.WriteLine(pl.plName);
			Console.WriteLine("Diameter: " + pl.diameter);
			Console.WriteLine("Mass: " + pl.mass);
			Console.WriteLine("Days: " + pl.days);
			
			Console.ReadKey(true);
		}
	}
}