﻿using System;

namespace matchbox
{
    class Box { public double w, h, n; }
    class Program
    {
        static void Main(string[] args)
        {
            Box b = new Box();
            Console.Write("Enter W: ");
            b.w = double.Parse(Console.ReadLine());
            Console.Write("Enter H: ");
            b.h = double.Parse(Console.ReadLine());

            double len = Math.Sqrt((b.w * b.w) + (b.h * b.h));

            Console.Write("Enter the length of the matchstick: ");
            b.n = double.Parse(Console.ReadLine());
            if (b.n <= len) Console.WriteLine("Result: Yes");
            else Console.WriteLine("Result: No");
            Console.ReadKey(true);
        }
    }
}
