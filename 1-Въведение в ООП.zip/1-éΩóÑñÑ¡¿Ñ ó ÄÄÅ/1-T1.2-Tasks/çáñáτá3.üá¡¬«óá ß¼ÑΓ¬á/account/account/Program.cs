﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.9.2020 г.
 * Time: 15:21
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace account
{
	class Person
	{
		public string fName;
		public string lName;
	}
	class Client
	{
		public double amount;
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Person p = new Person();
			Client c = new Client();
			
			p.fName = "Ilko";
			p.lName = "Stoev";
			c.amount = 1700.52;
			
			Console.WriteLine("Name: " + p.fName + " " + p.lName);
			Console.WriteLine("Amount: " + c.amount);
			
			Console.ReadKey(true);
		}
	}
}