﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.9.2020 г.
 * Time: 14:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace rect
{
	class Rectangle
	{
		public double length;
		public double width;
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Rectangle rec = new Rectangle();
			
			rec.length = 7.7;
			rec.width = 4.9;
			double s = rec.length * rec.width;
			
			Console.WriteLine("Length: " + rec.length);
			Console.WriteLine("Width: " + rec.width);
			Console.WriteLine("S: " + s);
			
			Console.ReadKey(true);
		}
	}
}