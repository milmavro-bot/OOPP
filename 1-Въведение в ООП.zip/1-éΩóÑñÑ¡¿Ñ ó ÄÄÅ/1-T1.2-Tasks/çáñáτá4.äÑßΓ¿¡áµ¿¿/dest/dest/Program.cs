﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 14.9.2020 г.
 * Time: 10:16
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace dest
{
	class Destination
	{
		public string city;
		public int kilometers;
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Destination d = new Destination();
			
			d.city = "Plovdiv";
			d.kilometers = 165;
			Console.WriteLine("Destination 1");
			Console.WriteLine("City: " + d.city);
			Console.WriteLine("Kilometers to Sofia: " + d.kilometers);
			Console.WriteLine();
			
			d.city = "Varna";
			d.kilometers = 469;
			Console.WriteLine("Destination 2");
			Console.WriteLine("City: " + d.city);
			Console.WriteLine("Kilometers to Sofia: " + d.kilometers);
			Console.WriteLine();
			
			d.city = "Burgas";
			d.kilometers = 393;
			Console.WriteLine("Destination 3");
			Console.WriteLine("City: " + d.city);
			Console.WriteLine("Kilometers to Sofia: " + d.kilometers);
			
			Console.ReadKey(true);
		}
	}
}