﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 14.9.2020 г.
 * Time: 15:39
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace angles
{
	class Angle
	{
		public double angleSin;
		public double angleCos;
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Angle a = new Angle();
			
			Console.Write("Enter degrees: ");
			double degrees = Convert.ToDouble(Console.ReadLine());
			double rad = Math.PI * degrees / 180.0;
			a.angleSin = Math.Sin(rad);
			a.angleCos = Math.Cos(rad);
			
			Console.WriteLine("Radians: " + rad.ToString("f4"));
			Console.WriteLine("Sin of " + degrees + ": " + a.angleSin.ToString("f4"));
			Console.WriteLine("Cos of " + degrees + ": " + a.angleCos.ToString("f4"));
			
			Console.ReadKey(true);
		}
	}
}