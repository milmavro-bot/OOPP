﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 20.9.2020 г.
 * Time: 17:52
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace InternetArticles
{
	class NetArticle
	{
		int readers, likes, dislikes;
		
		public void Initialize()
		{
			Console.WriteLine("Initializing new article");
			Console.Write("Number of readers: ");
			readers = int.Parse(Console.ReadLine());
			Console.Write("Likes: ");
			likes = int.Parse(Console.ReadLine());
			Console.Write("Dislikes: ");
			dislikes = int.Parse(Console.ReadLine());
		}
		public void AddReaders(int rdrs)
		{
			if(rdrs > 0) readers += rdrs;
		}
		public void AddLikes(int lks)
		{
			if(lks > 0) {likes += lks; readers += lks;}
		}
		public void AddDislikes(int dslks)
		{
			if(dslks > 0) { dislikes += dslks; readers += dslks;}
		}
		public double GetPositiveIndex()
		{
			return likes * 1.0 / (likes + dislikes);
		}
		public double GetEmotionalIndex()
		{
			return (double)(likes + dislikes) / readers;
		}
		public void Information()
		{
			Console.WriteLine("Readers: {0}", readers);
			Console.WriteLine("Likes: {0}", likes);
			Console.WriteLine("Dislikes: {0}", dislikes);
		}
		public void CompareTo(NetArticle other)
		{
			Console.Clear();
			double p1 = GetPositiveIndex();
			double p2 = other.GetPositiveIndex();
			double e1 = GetEmotionalIndex();
			double e2 = other.GetEmotionalIndex();
			Console.WriteLine("First article");
			Information();
			Console.WriteLine("Positive index {0}", p1.ToString("f3"));
			Console.WriteLine("Emotional index {0}", e1.ToString("f3"));
			Console.WriteLine("Second article");
			other.Information();
			Console.WriteLine("Positive index {0}", p2.ToString("f3"));
			Console.WriteLine("Emotional index {0}", e2.ToString("f3"));
			Console.Write ("More readers: ");
			if (readers > other.readers ) Console.WriteLine("the first article");
			else if (readers < other.readers ) Console.WriteLine("the second article");
			else Console.WriteLine("---");
			Console.Write ("Higher positive index: ");
			if (p1 > p2 ) Console.WriteLine("the first article");
			else if (p1 < p2 ) Console.WriteLine("the second article");
			else Console.WriteLine("---");
			Console.Write ("Higher emotional index: ");
			if (e1 > e2 ) Console.WriteLine("the first article");
			else if (e1 < e2 ) Console.WriteLine("the second article");
			else Console.WriteLine("---");
			
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			NetArticle a1 = new NetArticle();
			NetArticle a2 = new NetArticle();
			
			a1.Initialize();
			a2.Initialize();
			a1.Information();
			a2.Information();
			Console.ReadKey();
			Random r = new Random();
			
			a1.AddReaders(r.Next(-10, 101));
			a2.AddReaders(r.Next(-10, 101));
			a1.AddLikes(r.Next(-10, 101));
			a2.AddLikes(r.Next(-10, 101));
			a1.AddDislikes(r.Next(-10, 101));
			a2.AddDislikes(r.Next(-10, 101));
			
			a1.CompareTo(a2);
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}