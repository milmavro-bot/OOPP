﻿/*
 * Created by SharpDevelop.
 * User: mega
 * Date: 25.9.2020 г.
 * Time: 11:53
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace zad6
{
	class CashRegister
	{
		public int itemCount;
		public double totalPrice;
		public double custMoney;
		public void AddItem()
		{
			double price = -1;
			Console.WriteLine("Enter the price of an item: ");
			while (price!=0)
			{
				price = double.Parse(Console.ReadLine());
				if (price > 0)
				{
					itemCount++;
					totalPrice+=price;
				}
			}
		}
		public double GetTotal()
		{
			return totalPrice;
		}
		public int GetCount()
		{
			return itemCount;
		}
		public void Display()
		{
			Console.WriteLine("Item count: " + GetCount().ToString());
			Console.WriteLine("TotalPrice: " + GetTotal().ToString());
		}
		public void DisplayChange()
		{
			Console.Write("Enter Customer's money: ");
			double money = double.Parse(Console.ReadLine());
			double change = 0;
			if(money>GetTotal())
			{
				change = money - GetTotal();
				Console.WriteLine("Change: " + change.ToString());
			}
			else
			{
				change = GetTotal() - money;
				Console.WriteLine("Short by " + change.ToString());
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			CashRegister reg1 = new CashRegister();
			reg1.AddItem();
			reg1.Display();
			reg1.DisplayChange();
			
			Console.ReadKey(true);
		}
	}
}