﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 19.9.2020 г.
 * Time: 16:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FunctionFx
{
	class Fx
	{
		int x;
		public void ReadX()
		{
			Console.Write("x = ");
			x = int.Parse(Console.ReadLine());
		}
		public int CalcFx()
		{
			if((x < -2) || (x > 2)) return 2 * x;
			return -3 * x;
		}
		public void PrintResult()
		{
			int res = CalcFx();
			Console.WriteLine("f(x) = " + CalcFx());
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Fx myFx = new Fx();
			myFx.ReadX();
			myFx.PrintResult();
			
			Console.ReadKey(true);
		}
	}
}