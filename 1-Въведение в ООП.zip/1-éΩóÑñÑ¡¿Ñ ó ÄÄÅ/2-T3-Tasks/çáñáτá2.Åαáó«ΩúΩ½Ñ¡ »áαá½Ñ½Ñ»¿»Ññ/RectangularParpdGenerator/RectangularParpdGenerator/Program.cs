﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 19.9.2020 г.
 * Time: 12:45
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace RectangularParpdGenerator
{
	class RPrlpd
	{
		public double length, width, height;
		
		public void GenerateDimensions()
		{
			Random r = new Random();
			length = 1 + r.NextDouble()*100;
			width = 1 + r.NextDouble()*100;
			height = 1 + r.NextDouble()*100;
		}
		
		public void BriefData()
		{
			Console.WriteLine("Parallelepiped");
			Console.WriteLine("Length: " + length);
			Console.WriteLine("Width: " + width);
			Console.WriteLine("Height: " + height);
		}
		public double GetSurfaceArea()
		{
			return 2*(length*width + length*height + width*height);
		}
		public double GetVolume()
		{
			return length*width*height;
		}
		public void ChangeDimsBy(double d1, double d2, double d3)
		{
			if(length + d1 > 0) 
			{ 
				length += d1;
				Console.WriteLine("Length succesfully changed by {0}", d1);
			}
			if(width + d2 > 0) 
			{
				width += d2;
				Console.WriteLine("Width succesfully changed by {0}", d2);
			}
			if(height + d3 > 0) 
			{
				height += d3;
				Console.WriteLine("Height succesfully changed by {0}", d3);
			}
		}
		public void Info()
		{
			BriefData();
			Console.WriteLine("Surface area: " + GetSurfaceArea());
			Console.WriteLine("Volume: " + GetVolume());
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			RPrlpd p1 = new RPrlpd();
			p1.GenerateDimensions();
			p1.BriefData();
			Random r = new Random();
			p1.ChangeDimsBy( -10 + 20*r.NextDouble(), -10 + 20*r.NextDouble(), -10 + 20*r.NextDouble());
			p1.Info();
			
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}