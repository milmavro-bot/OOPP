﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 9.10.2020 г.
 * Time: 16:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace AnnualIncome
{
	class AnnualSalaryReference
	{
		private int year;
		private double dailyWage;
		
		public AnnualSalaryReference(int y, double dw)
		{
			year = y;
			dailyWage = dw;
		}
		
		int GetWorkingDays(int month) 
		{
			int daysInThisMonth = DateTime.DaysInMonth(year, month);	// дни в месеца
			DateTime cday = new DateTime(year, month, 1);				// текущ ден
			int wd = daysInThisMonth;									// вземеме дните в месеца и вадим почивните дни
			for (int i = 0; i < daysInThisMonth; i++) 
			{
				if(cday.DayOfWeek == DayOfWeek.Saturday || cday.DayOfWeek == DayOfWeek.Sunday) wd--;
				cday = cday.AddDays(1);
			}
			return wd;
		}
		
		public void PrintReference()
		{
			Console.WriteLine ("\nAnnual salary reference for {0}", year);
			Console.WriteLine("Daily wage: {0:c2}", dailyWage);
			Console.WriteLine(new String('-',50));
			Console.WriteLine("{0,12}{1,20}{2,20}", "Month", "Working days", "Monthly salary");
			DateTime cm;		// текущ месец
			double annSal = 0;	// годишна заплата
			for (int i = 1; i < 13; i++) 
			{
				cm = new DateTime(year, i, 1);
				Console.WriteLine("{0,12:MMMM}{1,15}{2,25:c2}", cm, GetWorkingDays(i),
				                  GetWorkingDays(i) * dailyWage);
				annSal += GetWorkingDays(i) * dailyWage;
			}
			Console.WriteLine(new String('-',50));
			Console.WriteLine("Total annual salary for {0}{1, 22:c2}", year, annSal);
			
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Enter a year for the reference: ");
			int y = int.Parse(Console.ReadLine());
			Console.Write("Enter a daily wage for the mentioned year: ");
			double dw = double.Parse(Console.ReadLine());
			
			AnnualSalaryReference asr = new AnnualSalaryReference(y, dw);
			asr.PrintReference();
			
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}