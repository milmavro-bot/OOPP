﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 14.10.2020 г.
 * Time: 8:03
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace WorkingDays
{
	class Program
	{
		public static void Main(string[] args)
		{
			int month = int.Parse(Console.ReadLine());
			int year = int.Parse(Console.ReadLine());
			int daysInThisMonth = DateTime.DaysInMonth(year, month);
			DateTime cday = new DateTime(year, month, 1);
			int wd = daysInThisMonth;
			for(int i = 0; i < daysInThisMonth; i++)
			{
				if(cday.DayOfWeek == DayOfWeek.Saturday || cday.DayOfWeek == DayOfWeek.Sunday) wd--;
				cday = cday.AddDays(1);
			}
			Console.WriteLine(wd);
			
			Console.ReadKey(true);
		}
	}
}