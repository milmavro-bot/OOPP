﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 10.10.2020 г.
 * Time: 12:39
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace CarR
{
	class CarRental
	{
		string model;			// модел на автомобила
		DateTime dateTake;		// дата на вземане
		DateTime dateReturn;	// дата на връщане
		double price;			// цена за 1 ден
		
		// Конструктор
		public CarRental(string m, DateTime d1, DateTime d2, double p)
		{
			model = m;
			dateTake = d1;
			dateReturn = d2;
			price = p;
		}
		
		// Намиране на броя на дните, за които е нает автомобилът
		int DateDiff()
		{
			return (dateReturn - dateTake).Days;
		}
		// Добавяне на възможност за изчисляване на дължимата
		// сума в зависимост от броя дни, за които е нает
		double CalcSum()
		{
			return price * DateDiff();
		}
		// Добавяне на възможност за ползване на отстъпки
		double CalcDiscount()
		{
			switch (DateDiff()) {
				case 2: case 3:
					return CalcSum() * 0.05;
				case 4: case 5: case 6:
					return CalcSum() * 0.1;
				case 7:
					return CalcSum() * 0.15;
				default:
					return 0;
			}
		}
		
		// Отпечатване на резултата в табличен вид
		public void PrintInfo()
		{
			double total = CalcSum() - CalcDiscount();
			Console.WriteLine("Car rental information: {0}", model);
			Console.WriteLine();
			Console.WriteLine(new String('-', 96));
			Console.WriteLine("Rental date\tReturn date\tNumber of days\t\tSum\t\tDiscount\tTotal");
			Console.WriteLine("{0:dd MMMM yyyy}{1,16:dd MMMM yyyy}{2,12}{3,24:c2}{4,18:c2}{5,15:c2}",
			                  dateTake, dateReturn, DateDiff(), CalcSum(), CalcDiscount(), total);
			Console.WriteLine(new String('-', 96));
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			DateTime dtTake = new DateTime(2020, 5, 3);
			DateTime dtReturn = new DateTime(2020, 5, 8);
			
			// Добавяне на обект от класа CarRental
			CarRental car = new CarRental("Mazda 6", dtTake, dtReturn, 35);
			car.PrintInfo();
			
			//CarRental car2 = new CarRental("Mazda 6", new DateTime(2020, 5, 3), new DateTime(2020, 5, 8), 35);
			//car2.PrintInfo();
			
			Console.ReadKey(true);
		}
	}
}