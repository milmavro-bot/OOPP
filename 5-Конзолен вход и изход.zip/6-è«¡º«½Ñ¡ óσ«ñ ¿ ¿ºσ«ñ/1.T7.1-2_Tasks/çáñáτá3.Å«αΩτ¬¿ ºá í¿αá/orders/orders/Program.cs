﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 8.10.2020 г.
 * Time: 12:05
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace orders
{
	class Order
	{
		string packaging;
		int year, month, day, quantity;
		double price;
		
		// Конструктор
		public Order(string pck, int y, int m, int d, int q, double p)
		{
			packaging = pck;
			year = y;
			month = m;
			day = d;
			quantity = q;
			price = p;
		}
		
		// Дължимата сума е равна на заявеното количество по цената
		double CalcTotal()
		{
			return quantity * price;
		}
		
		// Статус Изпълнена!, ако датата на поръчката е преди текущата и Неизпълнена! - в противен случай
		public void Status()
		{
			DateTime dt = new DateTime(year, month, day);
			DateTime currentDate = DateTime.Today;
			if(currentDate < dt)
			{
				Console.WriteLine("fulfilled");
			}
			else
			{
				Console.WriteLine("unfulfilled!");
			}
		}
		
		// Метод за отпечатване на поръчката в табличен вид
		public void PrintOrder()
		{
			Console.WriteLine("\nInformation on ordering beer:");
			Console.WriteLine();
			Console.WriteLine("Packaging\tQuantity\tOrder date\tPrice\t\tTotal");
			Console.WriteLine(new String('-', 70));
			DateTime d;
			d = new DateTime(year, month, day);
			Console.WriteLine("{0,6}{1,15}{2,22:dd MMMM yyyy}{3,12:c2}{4,15:c2}",
			                  packaging, quantity, d, price, CalcTotal());
			Console.WriteLine(new String('-', 70));
			Console.Write("Status: ");
			Status();
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Enter packaging: ");
			string pack = Console.ReadLine();
			Console.Write("Enter year of the order: ");
			int orderY = int.Parse(Console.ReadLine());
			Console.Write("Enter month of the order: ");
			int orderM = int.Parse(Console.ReadLine());
			Console.Write("Enter day of the order: ");
			int orderD = int.Parse(Console.ReadLine());
			Console.Write("Requested quantity: ");
			int orderQuantity = int.Parse(Console.ReadLine());
			Console.Write("Price: ");
			double pr = double.Parse(Console.ReadLine());
			
			// Деклариране на обект ord на класа Order
			Order ord = new Order(pack, orderY, orderM, orderD, orderQuantity, pr);
			ord.PrintOrder();
			
			Console.ReadKey(true);
		}
	}
}