﻿/*
 * Created by SharpDevelop.
 * User: mega
 * Date: 10/9/2020
 * Time: 9:44 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace ZeitPlan
{
	class Classes
	{
		int classDuration, breakDuration, numOfClasses;
		
		// Конструктор
		public Classes ( int cd, int bd, int nc )
		{
			classDuration = cd;
			breakDuration = bd;
			numOfClasses = nc;
		}
		
		// Метод DateTime GetStartTimeOfClass(int clsNum) – изчислява и връща обект от тип
		// DateTime, който показва кога започва учебния час с пореден номер clsNum.
		// Например при часове по 45 минути и междучасия от 10 минути, третият час започва в 9:50;
		public DateTime GetStartTimeOfClass(int clsNum)
		{
			int k = 0;
			k = (clsNum - 1) * classDuration + (clsNum - 1) * breakDuration;
			if(clsNum >= 4)
			{
				if(breakDuration < 10) k = k - breakDuration + 15;
				else k += breakDuration;
			}
			TimeSpan ts = new TimeSpan(0, k, 0);
			DateTime start= new DateTime(1, 1, 1, 8, 0, 0);
			start = start + ts;
			return start;
		}
		
		// Извежда на екрана информация за:
		// броя на часовете, продължителността на един час и на едно междучасие;
		// графика на часовете в табличен вид по модела, показан на изображенията по-долу.
		// Да се използва методът GetStartTimeOfClass(…).
		public void Print()
		{
			Console.WriteLine("Class\tStarts at\tEnds at");
			for(int i = 0; i < numOfClasses; i++)
			{
				TimeSpan classend = new TimeSpan(0, classDuration, 0);
				DateTime clend = new DateTime();
				clend = GetStartTimeOfClass(i + 1) + classend;
				Console.WriteLine( "{0,4}. {1,14: HH:mm} {2,12: HH:mm}", (i + 1),
				                  GetStartTimeOfClass(i + 1), clend);
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			// Създава обект от класа Classes, като
			// използва стойности по избор, които се
			// задават директно в кода (така е в
			// примерите) или се организира диалог с
			// потребителя. Приемаме, че ще бъдат
			// използвани коректни данни при
			// създаване на обекта;
			int c, b, n;
			Console.Write("Number per Classes per day: ");
			n = int.Parse(Console.ReadLine());
			Console.Write("Class duration: ");
			c = int.Parse(Console.ReadLine());
			Console.Write("Break duration: ");
			b = int.Parse(Console.ReadLine());
			Classes c1 = new Classes(c, b, n);
			
			// Извежда на екрана графика на часовете
			// за този обект чрез извикване на
			// съответния метод.
			c1.Print();
			
			Console.ReadKey(true);
		}
	}
}