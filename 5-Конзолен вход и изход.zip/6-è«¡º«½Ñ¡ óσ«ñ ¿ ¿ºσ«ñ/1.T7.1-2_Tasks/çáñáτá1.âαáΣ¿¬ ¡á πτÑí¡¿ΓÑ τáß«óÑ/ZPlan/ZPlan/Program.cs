﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 9.10.2020 г.
 * Time: 13:05
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace ZPlan
{
	class Program
	{
		public static void Main(string[] args)
		{
			int k = 0;
			Console.Write("Number per Classes per day: ");
			int clsNum = int.Parse(Console.ReadLine());
			Console.Write("Class duration: ");
			int classDuration = int.Parse(Console.ReadLine());
			Console.Write("Break duration: ");
			int breakDuration = int.Parse(Console.ReadLine());
			
			k = (clsNum - 1) * classDuration + (clsNum - 1) * breakDuration;
			if(clsNum >= 4)
			{
				if(breakDuration < 10) { k = k - breakDuration + 15; }
				else { k += breakDuration; }
			}
			Console.WriteLine(k);
			TimeSpan ts = new TimeSpan(0, k, 0);
			Console.WriteLine(ts);
			DateTime start = new DateTime(1, 1, 1, 8, 0, 0);
			start = start + ts;
			Console.WriteLine(start);
			
			Console.ReadKey(true);
		}
	}
}