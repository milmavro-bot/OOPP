﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 30.11.2020 г.
 * Time: 9:35
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace PseudoGraphics
{
	static class ConsoleGr
	{
		// Метод void DrawRect(int size) – чертае на екрана фигура,
		// съставена от size на брой реда, а във всеки ред има по size на брой символа *.
		public static void DrawRect(int size)
		{
			for(int i = 1; i <= size; i++)
			{
				for(int j = 1; j <= size; j++)
				{
					Console.Write("*");
				}
				Console.WriteLine();
			}
		}
		// Метод void DrawRect(int size, char c) – чертае на екрана фигура,
		// съставена от size на брой реда,
		// а във всеки ред има по size на брой от символите c.
		public static void DrawRect(int size, char c)
		{
			for(int i = 1; i <= size; i++)
			{
				for(int j = 1; j <= size; j++)
				{
					Console.Write(c);
				}
				Console.WriteLine();
			}
		}
		// Метод void DrawRect(int rows, int cols) – чертае на екрана фигура,
		// съставена от rows на брой реда,
		// а във всеки ред има по cols на брой символа *.
		public static void DrawRect(int rows, int cols)
		{
			for(int i = 1; i <= rows; i++)
			{
				for(int j = 1; j <= cols; j++)
				{
					Console.Write("*");
				}
				Console.WriteLine();
			}
		}
		// Метод void DrawRect(int rows, int cols, char c) – чертае на екрана фигура,
		// съставена от rows на брой реда,
		// а във всеки ред има по cols на брой символа от символите c.
		public static void DrawRect(int rows, int cols, char c)
		{
			for(int i = 1; i <= rows; i++)
			{
				for(int j = 1; j <= cols; j++)
				{
					Console.Write(c);
				}
				Console.WriteLine();
			}
		}
		// Метод void DrawRect(int rows, int cols, char outer, char inner) – чертае на екрана фигура,
		// съставена от rows на брой реда,
		// а във всеки ред има по cols на брой символа.
		// Символите на първия и последния ред,
		// както и в първата и последната колона,
		// са от вида outer,
		// докато останалите символи са от вида inner.
		public static void DrawRect(int rows, int cols, char outer, char inner)
		{
			for(int i = 1; i <= rows; i++)
			{
				for(int j = 1; j <= cols; j++)
				{
					if(i == 1 || i == rows || j == 1 || j == cols)
					{
						Console.Write(outer);
					}
					else
					{
						Console.Write(inner);
					}
				}
				Console.WriteLine();
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Графика в конзолата");
			Console.WriteLine("1. Фигура от * с равен брой редове и колони");
			Console.WriteLine("2. Фигура от избран символ с равен брой редове и колони");
			Console.WriteLine("3. Фигура от * с различен брой редове и колони");
			Console.WriteLine("4. Фигура от избран символ с различен брой редове и колони");
			Console.WriteLine("5. Фигура от два избрани символа с различен брой редове и колони");
			Console.Write("Вашият избор е: ");
			int n = int.Parse(Console.ReadLine());
			int size, rows, cols;
			char c, contour;
			
			switch (n) {
					case 1:
						Console.WriteLine("Въведете размер на фигурата:");
						size = int.Parse(Console.ReadLine());
						ConsoleGr.DrawRect(size);
						break;
					case 2:
						Console.WriteLine("Въведете размер на фигурата:");
						size = int.Parse(Console.ReadLine());
						Console.WriteLine("Въведете символ:");
						c = char.Parse(Console.ReadLine());
						ConsoleGr.DrawRect(size, c);
						break;
					case 3:
						Console.WriteLine("Въведете редове на фигурата:");
						rows = int.Parse(Console.ReadLine());
						Console.WriteLine("Въведете колони на фигурата:");
						cols = int.Parse(Console.ReadLine());
						ConsoleGr.DrawRect(rows, cols);
						break;
					case 4:
						Console.WriteLine("Въведете редове на фигурата:");
						rows = int.Parse(Console.ReadLine());
						Console.WriteLine("Въведете колони на фигурата:");
						cols = int.Parse(Console.ReadLine());
						Console.WriteLine("Въведете символ:");
						c = char.Parse(Console.ReadLine());
						ConsoleGr.DrawRect(rows, cols, c);
						break;
					case 5:
						Console.WriteLine("Въведете редове на фигурата:");
						rows = int.Parse(Console.ReadLine());
						Console.WriteLine("Въведете колони на фигурата:");
						cols = int.Parse(Console.ReadLine());
						Console.WriteLine("Въведете символ за контура:");
						contour = char.Parse(Console.ReadLine());
						Console.WriteLine("Въведете символ за вътрешността:");
						c = char.Parse(Console.ReadLine());
						ConsoleGr.DrawRect(rows, cols, contour, c);
						break;
					default:
						Console.WriteLine("Грешка! Менюто е от 1 до 5!");
						break;
			}
			
			Console.ReadKey(true);
		}
	}
}