﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 3.12.2020 г.
 * Time: 7:51
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace PseudoGraphics_11v
{
	static class ConsoleGr
	{
		public static void DrawRect(int size)
		{
			for(int i = 1; i <= size; i++)
			{
				for(int j = 1; j <= size; j++)
				{
					Console.Write('*');
				}
				Console.WriteLine();
			}
		}
		public static void DrawRect(int size, char c)
		{
			for(int i = 1; i <= size; i++)
			{
				for(int j = 1; j <= size; j++)
				{
					Console.Write(c);
				}
				Console.WriteLine();
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			ConsoleGr.DrawRect(8, '@');
			
			Console.ReadKey(true);
		}
	}
}