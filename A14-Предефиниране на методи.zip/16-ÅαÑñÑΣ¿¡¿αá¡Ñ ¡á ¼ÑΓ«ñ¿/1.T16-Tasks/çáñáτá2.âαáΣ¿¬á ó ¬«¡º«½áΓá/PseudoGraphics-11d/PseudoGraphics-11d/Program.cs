﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 4.12.2020 г.
 * Time: 9:12
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace PseudoGraphics_11d
{
	static class ConsoleGr
	{
		public static void DrawRect(int size)
		{
			for(int i = 1; i <= size; i++)
			{
				for(int j = 1; j <= size; j++)
				{
					Console.Write('*');
				}
				Console.WriteLine();
			}
		}
		public static void DrawRect(int size, char c)
		{
			for(int i = 1; i <= size; i++)
			{
				for(int j = 1; j <= size; j++)
				{
					Console.Write(c);
				}
				Console.WriteLine();
			}
		}
		public static void DrawRect(int rows, int cols)
		{
			for(int i = 1; i <= rows; i++)
			{
				for(int j = 1; j <= cols; j++)
				{
					Console.Write('*');
				}
				Console.WriteLine();
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			ConsoleGr.DrawRect(5, 4);
			
			Console.ReadKey(true);
		}
	}
}