﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 2.12.2020 г.
 * Time: 8:21
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MathCHelper_11v
{
	static class MathC
	{
		public static bool IsClamp(double value)
		{
			if(value >= 0.0 && value <= 1.0) return true;
			return false;
		}
		public static bool IsClamp(int value, int min, int max)
		{
			if(min > max)
			{
				throw new System.ArgumentException("The min parameter....");
			}
			if(value >= min && value <= max) return true;
			return false;
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Точка в квадрат");
			Console.Write("x: ");
			double x = double.Parse(Console.ReadLine());
			Console.Write("y: ");
			double y = double.Parse(Console.ReadLine());
			if(MathC.IsClamp(x) && MathC.IsClamp(y))
			{
				Console.WriteLine("Точката принадлежи на квадрата.");
			}
			else
			{
				Console.WriteLine("Точката НЕ принадлежи на квадрата.");
			}
			
			Console.WriteLine("\nЗдравен статус");
			Console.Write("Въведете вашите точки: ");
			int helth = int.Parse(Console.ReadLine());
			if(MathC.IsClamp(helth, 1, 100))
			{
				if(MathC.IsClamp(helth, 1, 20)) Console.WriteLine("лошо здраве");
				else if(MathC.IsClamp(helth, 20, 50)) Console.WriteLine("добро здраве");
				else Console.WriteLine("отлично здраве");
			}
			else
			{
				Console.WriteLine("Не може да се определи по тази скала!");
			}
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}