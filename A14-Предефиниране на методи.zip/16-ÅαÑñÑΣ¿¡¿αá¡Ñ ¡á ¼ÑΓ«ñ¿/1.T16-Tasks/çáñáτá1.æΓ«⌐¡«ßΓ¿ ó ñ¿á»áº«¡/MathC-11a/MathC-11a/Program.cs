﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 3.12.2020 г.
 * Time: 10:29
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MathC_11a
{
	static class MathC
	{
		public static bool IsClamp(double value)
		{
			if(value >= 0.0 && value <= 1.0) return true;
			return false;
		}
		public static bool IsClamp(int value, int min, int max)
		{
			if(min > max)
			{
				throw new System.ArgumentException("The min value cannot be greater...");
			}
			if(value >= min && value <= max) return true;
			return false;
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Точка в квадрат");
			Console.Write("x: ");
			double x = double.Parse(Console.ReadLine());
			Console.Write("y: ");
			double y = double.Parse(Console.ReadLine());
			if(MathC.IsClamp(x) && MathC.IsClamp(y))
			{
				Console.WriteLine("Точката принадлежи на квадрата.");
			}
			else
			{
				Console.WriteLine("Точката НЕ принадлежи на квадрата.");
			}
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}