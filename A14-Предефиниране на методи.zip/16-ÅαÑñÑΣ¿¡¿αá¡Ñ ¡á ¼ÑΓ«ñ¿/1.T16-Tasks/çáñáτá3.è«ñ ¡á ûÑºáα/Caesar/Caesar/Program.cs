﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 1.12.2020 г.
 * Time: 14:08
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Caesar
{
	static class Caesar
	{
		static readonly string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		
		// Метод string CodeIt(string message) – връща кодирана версия на съобщението,
		// като замества всяка буква от оригинала със следващата буква в азбуката
		// ( A -> B, B -> C, C -> D, … Y -> Z, Z -> A).
		// Всички символи, които не са латински букви,
		// се пропускат и не се появяват в резултата.
		// Кодираното съобщение е съставено само от главни букви.
		
		// Например "hello" се кодира като "IFMMP".
		public static string CodeIt(string message)
		{
			return Caesar.CodeIt(message, 1);
		}
		// Метод string CodeIt(string message, int step) – връща кодирана версия на съобщението,
		// като замества всяка буква от оригинала с буквата,
		// която е на step позиции напред в азбуката.
		// Всички символи, които не са латински букви,
		// се пропускат и не се появяват в резултата.
		// Кодираното съобщение е съставено само от главни букви.
		
		// Например "hello" при step = 7 се кодира като "OLSSV".
		public static string CodeIt(string message, int step)
		{
			string temp = "";
			step %= alphabet.Length;
			if(step < 0 ) step += alphabet.Length;
			//if(step == 0) return message;
			foreach (var c in message.ToUpper()) {
				int index = alphabet.IndexOf(c);
				if (index >= 0) temp += alphabet[(index + step) % alphabet.Length];
			}
			return temp;
		}
		// Метод string CodeIt(string message, char was, char toBe) – връща кодирана версия на съобщението,
		// като замества всяка буква от оригинала с буквата,
		// която е на толкова позиции напред в азбуката,
		// колкото е стъпката, определена от буквите was и toBe.
		// Всички символи, които не са латински букви, се пропускат и не се появяват в резултата.
		// Кодираното съобщение е съставено само от главни букви.
		
		// Например "hello" при was = 'D' и toBe = 'N' (това определя стъпка 10) се кодира като "ROVVY".
		public static string CodeIt(string message, char was, char toBe)
		{
			return Caesar.CodeIt(message, toBe - was);
		}
		
		// Метод string DecodeIt(string message) – връща декодирана версия на съобщението,
		// като замества всяка буква от оригинала със предходната буква в азбуката
		// ( A -> Z, B -> A, C -> B, … Y -> X, Z -> Y).
		// Всички символи, които не са латински букви, се пропускат и не се появяват в резултата.
		// Декодираното съобщение е съставено само от главни букви.
		
		// Например "WBSOB" се декодира като "VARNA".
		public static string DecodeIt(string message)
		{
			return Caesar.CodeIt(message, -1);
		}
		// Метод string DecodeIt(string message, int step) – връща декодирана версия на съобщението,
		// като замества всяка буква от оригинала с буквата, която е на step позиции назад в азбуката.
		// Всички символи, които не са латински букви, се пропускат и не се появяват в резултата.
		// Декодираното съобщение е съставено само от главни букви.
		
		// Например "TLAHSSPJH" при step = 7 се декодира като "METALLICA".
		public static string DecodeIt(string message, int step)
		{
			return Caesar.CodeIt(message, -1 * step);
		}
		// Метод string DecodeIt(string message, char was, char toBe) – връща декодирана версия на съобщението,
		// като замества всяка буква от оригинала с буквата, която е на толкова позиции назад в азбуката,
		// колкото е стъпката, определена от буквите was и toBe.
		// Всички символи, които не са латински букви, се пропускат и не се появяват в резултата.
		// Декодираното съобщение е съставено само от главни букви.
		
		// Например "LM" при was = 'F' и toBe = 'B' (това определя стъпка 4 назад) се декодира като "HI".
		public static string DecodeIt(string message, char was, char toBe)
		{
			return Caesar.CodeIt(message, toBe - was);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Въведете текст за кодиране:");
			string mes = Console.ReadLine();
			Console.WriteLine("Изберете вид на кодирането: 1) С едно напред   2) С посочена стъпка   3) С посочени символи");
			int ch = int.Parse(Console.ReadLine());
			if(ch==1)
			{
				Console.WriteLine("Кодиран текст:"+Environment.NewLine + Caesar.CodeIt(mes));
			}
			else if(ch==2)
			{
				Console.Write("Посочете стъпка за кодиране: ");
				int st = int.Parse(Console.ReadLine());
				Console.WriteLine("Кодиран текст:"+Environment.NewLine + Caesar.CodeIt(mes, st));
			}
			else if(ch==3)
			{
				Console.Write("Посочете стар символ: ");
				char st = char.Parse(Console.ReadLine().ToUpper());
				Console.Write("Посочете нов символ: ");
				char nv = char.Parse(Console.ReadLine().ToUpper());
				Console.WriteLine("Кодиран текст:"+Environment.NewLine + Caesar.CodeIt(mes, st, nv));
			}
			
			Console.WriteLine("Въведете текст за декодиране:");
			mes = Console.ReadLine();
			Console.WriteLine("Изберете вид на декодирането: 1) С едно назад   2) С посочена стъпка   3) С посочени символи");
			ch = int.Parse(Console.ReadLine());
			if(ch==1)
			{
				Console.WriteLine("Кодиран текст:"+Environment.NewLine + Caesar.DecodeIt(mes));
			}
			else if(ch==2)
			{
				Console.Write("Посочете стъпка за кодиране: ");
				int st = int.Parse(Console.ReadLine());
				Console.WriteLine("Кодиран текст:"+Environment.NewLine + Caesar.DecodeIt(mes, st));
			}
			else if(ch==3)
			{
				Console.Write("Посочете стар символ: ");
				char st = char.Parse(Console.ReadLine().ToUpper());
				Console.Write("Посочете нов символ: ");
				char nv = char.Parse(Console.ReadLine().ToUpper());
				Console.WriteLine("Кодиран текст:"+Environment.NewLine + Caesar.DecodeIt(mes, st, nv));
			}
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}