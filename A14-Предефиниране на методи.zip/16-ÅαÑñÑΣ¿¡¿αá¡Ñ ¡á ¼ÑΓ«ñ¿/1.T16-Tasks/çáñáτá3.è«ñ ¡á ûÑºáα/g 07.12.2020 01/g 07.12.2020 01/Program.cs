﻿using System;

namespace g_07._12._2020_01
{
    class Ceaser
    {
        public static string CodeIt(string message,int step)
        {
            string final=null;
            char[] arr = message.ToUpper().ToCharArray();
            for(int i=0;i<arr.Length;i++)
            {
                if(Char.IsLetter(arr[i]))
                {
                    if (Convert.ToChar(arr[i] + step) > 'Z')
                    {
                        final += Convert.ToChar(arr[i] + step - 26);
                    }
                    else
                    {
                        final += Convert.ToChar(arr[i] + step);
                    }
                }
            }
            return final;
        }
        public static string CodeIt(string message)
        {
            return CodeIt(message, 1);
        }
        public static string CodeIt(string message, char was,char toBe)
        {
            int diff = toBe - was;
            return CodeIt(message, diff);
        }
        public static string DecodeIt(string message, int step)
        {
            string final = null;
            char[] arr = message.ToUpper().ToCharArray();
            for (int i = 0; i < arr.Length; i++)
            {
                if (Char.IsLetter(arr[i]))
                {
                    if (Convert.ToChar(arr[i] + (-step)) < 'A')
                    {
                        final += Convert.ToChar(arr[i] - step + 26);
                    }
                    else
                    {
                        final += Convert.ToChar(arr[i] - step);
                    }
                }
            }
            return final;
        }
        public static string DecodeIt(string message)
        {
            return DecodeIt(message, 1);
        }
        public static string DecodeIt(string message, char was,char toBe)
        {
            int diff = was - toBe;
            return DecodeIt(message, diff);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = System.Text.Encoding.Unicode;
            Console.OutputEncoding = System.Text.Encoding.Unicode;
            Console.WriteLine("Въведете текст за кодиране:");
            string cText = Console.ReadLine();
            Console.WriteLine("Изберете вид на кодирането: 1) С едно напред   2) С посочена стъпка   3) С посочени символи");
            int cChoice = int.Parse(Console.ReadLine());
            if(cChoice==1)
            {
                Console.WriteLine("Кодиран текст: ");
                Console.WriteLine(Ceaser.CodeIt(cText));
            }
            else if(cChoice==2)
            {
                Console.Write("Посочете стъпка за кодиране: ");
                int cStep = int.Parse(Console.ReadLine());
                Console.WriteLine("Кодиран текст: ");
                Console.WriteLine(Ceaser.CodeIt(cText,cStep));
            }
            else if(cChoice==3)
            {
                Console.Write("Посочете стар символ: ");
                char cOld = char.Parse(Console.ReadLine());
                Console.Write("Посочете нов символ: ");
                char cNew = char.Parse(Console.ReadLine());
                Console.WriteLine("Кодиран текст: ");
                Console.WriteLine(Ceaser.CodeIt(cText,cOld,cNew));
            }
            Console.WriteLine("Въведете текст за декодиране:");
            string dText = Console.ReadLine();
            Console.WriteLine("Изберете вид на декодирането: 1) С едно назад   2) С посочена стъпка   3) С посочени символи");
            int dChoice = int.Parse(Console.ReadLine());
            if (dChoice == 1)
            {
                Console.WriteLine("Декодиран текст: ");
                Console.WriteLine(Ceaser.DecodeIt(dText));
            }
            else if (dChoice == 2)
            {
                Console.Write("Посочете стъпка за кодиране: ");
                int dStep = int.Parse(Console.ReadLine());
                Console.WriteLine("Декодиран текст: ");
                Console.WriteLine(Ceaser.DecodeIt(dText, dStep));
            }
            else if (dChoice == 3)
            {
                Console.Write("Посочете стар символ: ");
                char dOld = char.Parse(Console.ReadLine());
                Console.Write("Посочете нов символ: ");
                char dNew = char.Parse(Console.ReadLine());
                Console.WriteLine("Декодиран текст: ");
                Console.WriteLine(Ceaser.DecodeIt(dText, dOld, dNew));
            }
        }
    }
}
