﻿using System;
using System.Linq;

namespace CeasarCode
{
    public static class Ceaser
    {
        public static string CodeIt(string message)
        {
            return Codeit(message, 1);
        }

        public static string Codeit(string message, int step)
        {
            string result = string.Empty;
            foreach (var letter in message)
            {
                if(letter - 'A' + step < 0) result += (char)((26 + (letter - 'A' + step)) + 'A');
                else result += (char)((letter - 'A' + step)%26 + 'A');
            }

            return result;
        }

        public static string CodeIt(string message, char was, char toBe)
        {
            int step = toBe - was;
            return Codeit(message, step);
        }

        public static string DecodeIt(string message)
        {
            return Codeit(message, -1);
        }

        public static string DecodeIt(string message, int step)
        {
            return Codeit(message, step * (-1));
        }

        public static string DecodeIt(string message, char was, char toBe)
        {
            int step = toBe - was;
            return Codeit(message, step * (-1));
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            Console.WriteLine("Choose type of Encryption: ");
            int type = int.Parse(Console.ReadLine());
            if (type == 2)
            {
                Console.Write("Step: ");
                int step = int.Parse(Console.ReadLine());
                Console.WriteLine(Ceaser.Codeit(input.ToUpper(), step));
            }
            else if (type == 3)
            {
                Console.Write("Enter two chars: ");
                string chars = Console.ReadLine();
                Console.WriteLine(Ceaser.CodeIt(input.ToUpper(), chars[0], chars[2]));
            }
            else
            {
                Console.WriteLine(Ceaser.CodeIt(input.ToUpper()));
            }
            input = Console.ReadLine();
            Console.WriteLine("Choose type of Decryption: ");
            type = int.Parse(Console.ReadLine());
            if (type == 2)
            {
                Console.Write("Step: ");
                int step = int.Parse(Console.ReadLine());
                Console.WriteLine(Ceaser.DecodeIt(input.ToUpper(), step));
            }
            else if (type == 3)
            {
                Console.Write("Enter two chars: ");
                string chars = Console.ReadLine();
                Console.WriteLine(Ceaser.DecodeIt(input.ToUpper(), chars[0], chars[2]));
            }
            else
            {
                Console.WriteLine(Ceaser.DecodeIt(input.ToUpper()));
            }
        }
    }
}