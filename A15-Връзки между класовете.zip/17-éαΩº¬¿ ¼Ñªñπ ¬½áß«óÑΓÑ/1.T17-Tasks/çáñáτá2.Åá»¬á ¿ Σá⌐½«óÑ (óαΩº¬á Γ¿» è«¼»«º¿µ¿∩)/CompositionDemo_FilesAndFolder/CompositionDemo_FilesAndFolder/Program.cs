﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 12.12.2020 г.
 * Time: 14:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace CompositionDemo_FilesAndFolder
{
	class File
	{
		string name;			// име и разширение
		DateTime crTime;		// дата и час на създаване
		
		// Конструктор
		public File(string nm)
		{
			if(string.IsNullOrEmpty(nm)) throw new ArgumentException("Invalid or missing file name!");
			name = nm;
			crTime = DateTime.Now;
		}
		
		// void Rename(string newName) – заменя текущото име на файла с новото,
		// изпратено чрез параметъра.
		// Ако newName е празен низ, да се генерира изключение от вида ArgumentException.
		public void Rename(string newName)
		{
			if(string.IsNullOrEmpty(newName)) throw new ArgumentException("Invalid or missing file name!");
			name = newName;
		}
		
		// void PrintInfo() – извежда на екрана информация за файла – име, дата на създаване;
		public void PrintInfo()
		{
			Console.WriteLine("File: {0}, created: {1:HH:mm:ss, dd.MM.yyyy}", name, crTime);
		}
	}
	
	class Folder
	{
		string name;			// име
		DateTime crTime;		// даа и час на създаване
		List<File> fList;		// списък с файловете
		
		// Конструктор
		public Folder(string nm)
		{
			if(string.IsNullOrEmpty(nm)) throw new ArgumentException("Invalid or missing file name!");
			name = nm;
			crTime = DateTime.Now;
			fList = new List<File>();
		}
		
		// void ManageFiles() – организира меню за многократен избор на действие измежду 5 възможности:
		// 		- създаване на фай;
		// 		- преименуване на файл;
		// 		- изтриване на файл;
		// 		- преглед на информацията за файлвете в папката;
		// 		- изход.
		
		// След края на всяко избрано действие се извежда надпис
		// и се осигурява изчакване до натискане на клавиш (Console.ReadKey(true)).
		// Всяко ново извеждане на менюто става на изчистен екран (Console.Clear()).
		public void ManageFiles()
		{
			do
			{
				Console.Clear();
				Console.WriteLine("Папка {0} - избор на действие", name);
				Console.WriteLine("1. Създаване на файл");
				Console.WriteLine("2. Преименуване на файл");
				Console.WriteLine("3. Изтриване на файл");
				Console.WriteLine("4. Преглед на съдържанието на папката");
				Console.WriteLine("5. Изход");
				Console.Write("Вашият избор е: ");
				int ch = int.Parse(Console.ReadLine());
				switch (ch) 
				{
					case 1:
						CreateFile();
						break;
					case 2:
						RenameFile();
						break;
					case 3:
						DeleteFile();
						break;
					case 4:
						PrintFolderInfo();
						break;
					default:
						return;
				}
				Console.WriteLine("Натиснете клавиш, за да продължите!");
				Console.ReadKey(true);
			}
			while(true);
		}
		// void CreateFile() – организира диалог, в който от клавиатурата се въвежда име, 
		// "създава" се файл с това име и се добавя в списъка с файлове.
		
		// Евентуална проверка за дублиране на имена!
		void CreateFile()
		{
			Console.Write("Въведете име за файла: ");
			string nm = Console.ReadLine();
			fList.Add(new File(nm));
		}
		// int ChooseFile() – организира диалог за избор на номер на файл
		// и избрания номер или -1, ако в папката няма файлове
		int ChooseFile()
		{
			if(fList.Count < 1) return -1;
			do
			{
				Console.WriteLine("Изберете номер на файл - число от 1 до {0} включително!", fList.Count);
				Console.Write("Вашият избор е: ");
				int ch = int.Parse(Console.ReadLine());
				if(ch>=1 && ch<=fList.Count) return ch;
				Console.WriteLine("Невалиден избор!");
			}
			while(true);
		}
		// void RenameFile() – организира извършването на следните дейности:
		// 	- избор файл (чрез метода ChooseFile(); при върнат резултат -1 прекъсва работа с подходящо съобщение);
		// 	- извеждане на информация за файла;
		
		// 	- изискване на потвърждение дали това е търсеният файл (при Не – нов избор);
		
		// 	- въвеждане на ново име от клавиатурата;
		// 	- преименуване на файла (чрез съответния метод от клас File)
		
		//		ЕВЕНТУАЛНА ПТОВЕРКА ЗА ДУБЛИРАНЕ НА ИМЕНА
		
		void RenameFile()
		{
			int fIndex = ChooseFile() - 1;
			if(fIndex < 0 ) 
			{
				Console.WriteLine("Папката е празна!");
				return;
			}
			Console.Write("Избраният файл за преименуване е: ");
			fList[fIndex].PrintInfo();
			Console.Write("Въведете ново име за файла: ");
			string newName = Console.ReadLine();
			fList[fIndex].Rename(newName);
		}
		
		// void DeleteFile() – организира извършването на следните дейности:
		// 	- избор файл (чрез метода ChooseFile(); при върнат резултат -1 прекъсва работа с подходящо съобщение);
		//  - извеждане на информация за файла;
		
		//	- изискване на потвърждение дали това е търсеният файл (при Не – нов избор);
		
		//  - изтриване на файла от списъка с файлове.
		void DeleteFile()
		{
			int fIndex = ChooseFile() - 1;
			if(fIndex < 0 ) 
			{
				Console.WriteLine("Папката е празна!");
				return;
			}
			Console.Write("Избраният файл за изтриване е: ");
			fList[fIndex].PrintInfo();
			fList.RemoveAt(fIndex);
		}
		
		// void PrintFolderInfo() – извежда на екрана информация за папката – името,
		// след това списък с информация за всеки от файловете и (на нов ред) броя на файловете.
		void PrintFolderInfo()
		{
			Console.WriteLine();
			Console.WriteLine("Папка {0}, създаване: {1:HH:mm:ss, dd.MM.yyyy}", name, crTime);
			Console.WriteLine(new String('-', 50));
			if (fList.Count > 0)
			{
				foreach (File f in fList) {
					f.PrintInfo();
				}
				Console.WriteLine("Общо: {0} файл/а", fList.Count);
			}
			else
			{
				Console.WriteLine("В момента папката е празна!");
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Folder fld = new Folder("Test folder");
			fld.ManageFiles();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}