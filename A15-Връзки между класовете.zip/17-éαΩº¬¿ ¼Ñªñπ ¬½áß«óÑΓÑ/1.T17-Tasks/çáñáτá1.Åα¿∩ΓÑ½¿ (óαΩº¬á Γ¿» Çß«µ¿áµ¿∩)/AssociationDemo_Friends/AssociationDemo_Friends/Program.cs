﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 9.12.2020 г.
 * Time: 18:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace AssociationDemo_Friends
{
	class Person
	{
		string name;				// имената на съответния човек
		int age;					// възрастта на съответния човек
		List<Person> friendsList;	// списък с приятелите на съответния човек
		
		// Конструктор
		public Person(string nm, int ag)
		{
			if(string.IsNullOrEmpty(nm) || string.IsNullOrWhiteSpace(nm)) throw new ArgumentException("Invalid name: " + nm);
			if(ag < 1) throw new ArgumentException("Invalid age: " + age);
			name = nm;
			age = ag;
			friendsList = new List<Person>();
		}
		// void CreateFriendship(Person other) – създава ново "приятелство" между текущия човек и other,
		// като добавя всеки от двамата в списъка с приятелите на другия.
		// Ако вече са "приятели" методът не прави нищо
		// (тоест в списъка с приятелите не трябва да има повторения).
		// Човек не трябва да бъде "приятел" със себе си!
		public void CreateFriendship(Person other) 
		{
			if (this == other) return;
			if(friendsList.IndexOf(other) < 0 ) friendsList.Add(other);
			if (other.friendsList.IndexOf(this) < 0) other.friendsList.Add(this);
		}
		// void DestroyFriendship(Person other) – разрушава "приятелството"
		// между текущия човек и other,
		// като премахва всеки от двамата в списъка с приятелите на другия.
		public void DestroyFriendship(Person other) 
		{
			if(friendsList.Contains(other)) friendsList.Remove(other);
			if (other.friendsList.Contains(this)) other.friendsList.Remove(this);
		}
		// string GetShortInfo() – връща текст, съдържащ името и възрастта на човека
		string GetShortInfo() 
		{
			return name + ",  age: " + age;
		}
		// void PrintInfo() – извежда на екрана информация за човека и броя на приятелите му,
		// както и кратка информация за всеки от тях
		public void PrintInfo()
		{
			Console.WriteLine("{0} has {1} friend/s", GetShortInfo(), friendsList.Count);
			if (friendsList.Count > 0) 
			{
				Console.Write("Friends:");
				foreach (Person fr in friendsList) 
				{
					Console.Write("  " + fr.GetShortInfo() + ";");
				}
				Console.WriteLine();
			}
			Console.WriteLine(new String('-', 50));
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Random r = new Random();
			string[] fNames = {"Tony", "Alex", "John", "Peter", "Nora", "Lyra", "Kim"};
			string[] lNames = {"Snow", "Belaqua", "Silver", "Pann", "Roberts", "Braxton", "Bodnia"};
			int n = r.Next(3, 8);
			Person[] prs = new Person[n];
			for (int i = 0; i < n; i++) 
			{
				int f = r.Next(fNames.Length);
				int l = r.Next(lNames.Length);
				int age = r.Next(16, 81);
				prs[i] = new Person(fNames[f] + " " + lNames[l], age);
			}
			
			// Извеждане на началното състояние на героите
			Console.WriteLine("Initial characters data:");
			foreach (Person p in prs) 
			{
				p.PrintInfo();
			}
			
			// Създаване на приятелства
			n = 15; //r.Next(20, 31);
			for (int i = 0; i < n; i++) 
			{
				int f = r.Next(prs.Length);
				int l = r.Next(prs.Length);
				prs[f].CreateFriendship(prs[l]);
			}
			
			// След създаването на приятелства
			Console.WriteLine("After becoming friends:");
			foreach (Person p in prs) 
			{
				p.PrintInfo();
			}
			
			// "Разваляне на приятелства
			n = 8; //r.Next(10, 16);
			for (int i = 0; i < n; i++) 
			{
				int f = r.Next(prs.Length);
				int l = r.Next(prs.Length);
				prs[f].DestroyFriendship(prs[l]);
			}
			
			// След разваляне на приятелства
			Console.WriteLine("After losing friends:");
			foreach (Person p in prs) 
			{
				p.PrintInfo();
			}
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}