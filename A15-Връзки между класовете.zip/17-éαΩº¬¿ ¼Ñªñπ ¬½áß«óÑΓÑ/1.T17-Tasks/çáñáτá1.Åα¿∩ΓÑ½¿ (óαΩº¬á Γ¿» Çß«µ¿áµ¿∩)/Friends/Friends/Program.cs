﻿/*
 * Created by SharpDevelop.
 * User: Nicol
 * Date: 12.12.2020 г.
 * Time: 15:48
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace Friends
{
	class Person
	{
		string name;
		int age;
		List<Person> friendsList;
		public Person (string nm, int ag)
		{
			if(nm!="") name = nm;
			else throw new ArgumentException("Не сте въвели име!");
			if(ag>=1) age = ag;
			else throw new ArgumentException("Не сте въвели име!");
			friendsList = new List<Person>();
		}
		public void CreateFriendship(Person other)
		{
			if(this!=other && !this.friendsList.Contains(other))
			{
				friendsList.Add(other);
				other.friendsList.Add(this);
			}	   
		}
		public void DestroyFriendship(Person other)
		{
			if(this!=other && this.friendsList.Contains(other))
			{
				friendsList.Remove(other);
				other.friendsList.Remove(this);
			}
		}
		public string GetShortInfo()
		{
			return string.Format("{0,18},\tage: {1}  has {2} friends",name,age,friendsList.Count);
		}
		public void PrintInfo()
		{
			Console.WriteLine(GetShortInfo());
			Console.Write("Friends: ");
			Console.WriteLine(string.Join("; ",friendsList));
			Console.WriteLine(new String('-',50));
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			string[] first = {"Ross", "Rachel", "Chandler", "Monica", "Joey", "Phoebe", "Mike"};
			string[] last = {"Geller", "Green", "Bing", "Burke","Tribbiani", "Buffay", "Hannigan"};
			Random rnd = new Random();
			int p = rnd.Next(3,8);
			Person[] people = new Person[p];
			Person pers;
			for(int i=0; i<p; i++)
			{
				string name="";
				int age;
				int f = rnd.Next(1,8);
				name+=first[f-1]+" ";
				int l = rnd.Next(1,8);
				name+=last[l-1];
				age = rnd.Next(16,81);
				pers = new Person(name,age);
				people[i] = pers;
			}
			Console.WriteLine("Initial characters data:");
			for(int i=0; i<p; i++)
			{
				Console.WriteLine(people[i].GetShortInfo());
				Console.WriteLine(new String('-',50));
			}
			Console.ReadKey(true);
			Console.Clear();
			Console.WriteLine("After becoming friends:");
			for(int i=0; i<15; i++)
			{
				people[rnd.Next(0,p)].CreateFriendship(people[rnd.Next(0,p)]);
			}
			for(int i=0; i<p; i++)
			{
				people[i].PrintInfo();
			}
			Console.ReadKey(true);
			Console.Clear();
			Console.WriteLine("After losing friends:");
			for(int i=0; i<8; i++)
			{
				people[rnd.Next(0,p)].DestroyFriendship(people[rnd.Next(0,p)]);
			}
			for(int i=0; i<p; i++)
			{
				people[i].PrintInfo();
			}
			Console.ReadKey(true);
		}
	}
}