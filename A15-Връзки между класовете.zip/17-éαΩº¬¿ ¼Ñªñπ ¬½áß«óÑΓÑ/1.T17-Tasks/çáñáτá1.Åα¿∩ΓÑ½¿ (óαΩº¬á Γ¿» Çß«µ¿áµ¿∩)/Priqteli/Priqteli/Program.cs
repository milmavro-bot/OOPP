﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Priqteli
{
    class Person
    {
        string name;
        int age;
        List<Person> friendsList = new List<Person>();
        public Person ( string nm, int ag)
        {
            if (nm == "" || ag < 1) throw new ArgumentException();
            else
            {
                name = nm;
                age = ag;
            }
        }
        public void CreateFriendship(ref Person other)
        {
            if (friendsList==null)
            {
                if (other.name == this.name && other.age == this.age) return;
                friendsList.Add(other);
                other.friendsList.Add(this);
                return;
            }
            if (friendsList.Contains(other)) return;
            if (other.name == this.name && other.age == this.age) return;
            friendsList.Add(other);
            other.friendsList.Add(this);
        }
        public void DestroyFriendship(ref Person other)
        {
            if (friendsList == null) return;
            if (!friendsList.Contains(other)) return;
            friendsList.Remove(other);
            other.friendsList.Remove(this);
        }
        string GetShortInfo()
        {
            return String.Format("{0}, Age: {1}", name, age);
        }
        public void PrintInfo()
        {
            if(friendsList==null)
            {
                Console.WriteLine("{0} has {1} friend/s", GetShortInfo(), 0);
                return;
            }
            if(friendsList!=null)Console.WriteLine("{0} has {1} friend/s", GetShortInfo(), friendsList.Count);
            if(friendsList.Count>0)
            {
                Console.Write("Friends:  ");
                for (int i = 0; i < friendsList.Count; i++)
                {
                    Console.Write("{0}; ", friendsList[i].GetShortInfo());

                }
                Console.WriteLine();
                
            }
            Console.WriteLine("-------------------------------------------");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            string[] fnames = { "Tony", "Alex", "John", "Peter", "Nora", "Lyra", "Kim" } ;
            string[] lnames = { "Snow", "Belaqua", "Silver", "Pann", "Roberts", "Braxton", "Bodnia" };
            Person[] people = new Person[8];
            int size = rnd.Next(3, 8);
            for( int i=0; i<size; i++)
            {
                string n = fnames[rnd.Next(0, 7)] + " " +lnames[rnd.Next(0, 7)];
                int a = rnd.Next(16, 81);
                people[i] = new Person(n, a);
            }
            for(int i=0; i<15; i++)
            {
                int p1 = rnd.Next(0, size), p2 = rnd.Next(0, size);
                //Console.WriteLine("{0} {1}", p1, p2);
                people[p1].CreateFriendship(ref people[p2]);
            }
            Console.WriteLine("After becoming friends: ");
            for(int i=0; i<size; i++)
            {
                people[i].PrintInfo();
            }
            for (int i = 0; i < 8; i++)
            {
                int p1 = rnd.Next(0, size), p2 = rnd.Next(0, size);
                people[p1].DestroyFriendship(ref people[p2]);
            }
            Console.WriteLine("After losing friends: ");
            for (int i = 0; i < size; i++)
            {
                people[i].PrintInfo();
            }
            Console.ReadKey(true);
        }
    }
}
