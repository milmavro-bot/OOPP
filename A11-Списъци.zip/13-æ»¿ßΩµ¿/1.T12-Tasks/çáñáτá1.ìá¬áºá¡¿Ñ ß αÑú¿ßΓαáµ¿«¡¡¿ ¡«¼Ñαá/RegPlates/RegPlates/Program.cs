﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 9.11.2020 г.
 * Time: 11:57
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace RegPlates
{
	class Nums
	{
		List<string> regPlates, numList;
		// Конструктор
		public Nums()
		{
			regPlates = new List<string>();
			numList = new List<string>();
			GetData();
			RemoveZeroes();
			RemoveDuplicates();
		}
		
		// Метод void GetData() – извършва запълването на regPlates със стойности,
		// като организира въвеждане от клавиатурата (за край се въвежда "---").
		void GetData() 
		{
			Console.WriteLine("Запълване на списъка");
			string t = "";
			do
			{
				Console.Write("Въведете номер (--- за край): ");
				t = Console.ReadLine();
				if(t=="---") return;
				regPlates.Add(t);
			}
			while(true);
		}
		// Метод void RemoveZeroes() – копира съдържанието на regPlates в numList
		// и изтрива от numList всички "номера"
		// които съдържат 0.
		void RemoveZeroes() 
		{
			Console.WriteLine("Премахване на номерата с 0 от списъка");
			numList.AddRange(regPlates);
			for (int i = 0; i < numList.Count; ) {
				if(numList[i].IndexOf('0')>=0) 
				{
					numList.RemoveAt(i);
				}
				else
				{
					i++;
				}
			}
		}
		// Метод void RemoveDuplicates() – премахва от numList повторенията
		// (тоест всеки номер в списъка трябва да се среща само по веднъж)
		// и сортира списъка.
		void RemoveDuplicates() 
		{
			Console.WriteLine("Премахване на дублиранията на номера в списъка");
			for (int i = 0; i < numList.Count; ) {
				if(numList.LastIndexOf(numList[i])!=i) 
				{
					numList.RemoveAt(i);
				}
				else
				{
					i++;
				}
			}
			numList.Sort();
		}
		
		// Метод void PrintLists() – извежда на екрана номерата от първия списък
		// (разделени с по 2 интервала)
		// и от втория списък (отново разделени с по 2 интервала).
		public void PrintLists() 
		{
			Console.WriteLine("Начален списък");
			Console.WriteLine(string.Join("  ", regPlates));
			Console.WriteLine("Редактиран списък");
			if(numList.Count > 0)
			{	
				Console.WriteLine(string.Join("  ", numList));
			}
			else
			{
				Console.WriteLine("Списъкът е празен :(");
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Nums n = new Nums();
			n.PrintLists();
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}