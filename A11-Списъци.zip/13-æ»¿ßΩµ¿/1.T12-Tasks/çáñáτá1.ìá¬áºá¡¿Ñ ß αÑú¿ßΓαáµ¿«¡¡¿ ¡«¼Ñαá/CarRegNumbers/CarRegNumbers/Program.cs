﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 8.11.2020 г.
 * Time: 15:21
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Linq;

namespace CarRegNumbers
{
	class Nums
	{
		List<string> regPlates;	// всички номера, записани по пътя
		List<string> numList;	// финалния списък с номерата, отговарящи на изискванията
		
		// Конструктор
		public Nums()
		{
			regPlates = new List<string>();
			numList = new List<string>();
			GetData();
			RemoveZeroes();
			RemoveDuplicates();
		}
		
		// Метод void GetData() – извършва запълването на regPlates със стойности,
		// като организира въвеждане от клавиатурата (за край се въвежда "---").
		void GetData()
		{
			Console.WriteLine("Запълване на списъка");
			do
			{
				Console.Write("Въведете номер (--- за край): ");
				regPlates.Add(Console.ReadLine());
			}
			while(!(regPlates.Contains("---")));
			regPlates.Remove("---");
		}
		// Метод void RemoveZeroes() – копира съдържанието на regPlates в numList
		// и изтрива от numList всички "номера"
		// които съдържат 0.
		void RemoveZeroes()
		{
			Console.WriteLine("Премахване на номерата с 0 от списъка");
			numList.AddRange(regPlates);
			for(int i = 0; i < numList.Count; )
			{
				if(numList[i].Contains('0'))
				{
					numList.Remove(numList[i]);
				}
				else
				{
					i++;
				}
			}
		}
		// Метод void RemoveDuplicates() – премахва от numList повторенията
		// (тоест всеки номер в списъка трябва да се среща само по веднъж)
		// и сортира списъка.
		void RemoveDuplicates()
		{
			Console.WriteLine("Премахване на дублиранията на номера в списъка");
			numList = numList.Distinct().ToList();
			numList.Sort();
		}
		
		// Метод void PrintLists() – извежда на екрана номерата от първия списък
		// (разделени с по 2 интервала)
		// и от втория списък (отново разделени с по 2 интервала).
		public void PrintLists() 
		{
			Console.WriteLine("Начален списък");
			Console.WriteLine(string.Join("  ", regPlates));
			Console.WriteLine("Редактиран списък");
			if(numList.Count > 0)
			{	
				Console.WriteLine(string.Join("  ", numList));
			}
			else
			{
				Console.WriteLine("Списъкът е празен :(");
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Nums n = new Nums();
			n.PrintLists();
			
			Console.ReadKey(true);
		}
	}
}