﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.11.2020 г.
 * Time: 10:12
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Linq;

namespace CarRegNumbers_sol
{
	class Nums
	{
		List<string> regPlates, numList;
		public Nums()
		{
			regPlates = new List<string>();
			numList = new List<string>();
			// Methods:
			GetData();
			RemoveZeroes();
			RemoveDuplicates();
		}
		
		void GetData()
		{
			Console.WriteLine("Запълване на списъка");
			//Solution 1
			/*string t = "";
			do
			{
				Console.Write("Въведете номер (--- за край): ");
				t = Console.ReadLine();
				if(t == "---") return;
				regPlates.Add(t);
			}
			while(true);*/
			
			// Solution 2
			do
			{
				Console.Write("Въведете номер (--- за край): ");
				regPlates.Add(Console.ReadLine());
			}
			while(!(regPlates.Contains("---")));
			regPlates.Remove("---");
		}
		void RemoveZeroes()
		{
			Console.WriteLine("Премахване на номерата с 0 от списъка");
			numList.AddRange(regPlates);
			// Solution 1
			/*for(int i = 0; i < numList.Count; )
			{
				if(numList[i].IndexOf('0') >= 0)
				{
					numList.RemoveAt(i);
				}
				else
				{
					i++;
				}
			}*/
			
			// Solution 2
			for(int i = 0; i < numList.Count; )
			{
				if(numList[i].Contains('0'))
				{
					numList.Remove(numList[i]);
				}
				else
				{
					i++;
				}
			}
		}
		void RemoveDuplicates()
		{
			Console.WriteLine("Премахване на дублиранията на номерата в списъка.");
			// Solution (traditional)
			/*for(int i = 0; i < numList.Count; )
			{
				if(numList.LastIndexOf(numList[i]) != i)
				{
					numList.RemoveAt(i);
				}
				else
				{
					i++;
				}
			}*/
			
			// Solution (extra)
			numList = numList.Distinct().ToList();
			numList.Sort();
		}
		
		public void PrintLists()
		{
			Console.WriteLine("Начален списък");
			Console.WriteLine(string.Join("  ", regPlates));
			Console.WriteLine("Редактиран списък");
			if(numList.Count > 0)
			{
				Console.WriteLine(string.Join("  ", numList));
			}
			else
			{
				Console.WriteLine("Списъкът е празен :(");
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Nums n = new Nums();
			n.PrintLists();
			
			Console.ReadKey(true);
		}
	}
}