﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 19.11.2020 г.
 * Time: 10:01
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace Sets_UIS_11a
{
	class UID_Sets
	{
		List<int> listA, listB;
		
		public UID_Sets()
		{
			listA = new List<int>();
			listB = new List<int>();
			// Methods:
			FillTheLists();
		}
		
		void FillTheLists()
		{
			Random r = new Random();
			int a;
			while(true)
			{
				a = r.Next(1, 101);
				if(listA.Contains(a)) break;
				listA.Add(a);
			}
			while(true)
			{
				a = r.Next(1, 101);
				if(listB.Contains(a)) break;
				listB.Add(a);
			}
		}
		
		public void Print()
		{
			Console.WriteLine("A = {0}", "{" + string.Join(", ", listA) + "}");
			Console.WriteLine("B = {0}", "{" + string.Join(", ", listB) + "}");
			Union_AB();
			Intersection_AB();
			Difference_AB();
		}
		
		void Union_AB()
		{
			List<int> listAUB = new List<int>(listA.Count + listB.Count);
			listAUB.AddRange(listA);
			foreach (var n in listB) {
				if(!listAUB.Contains(n)) listAUB.Add(n);
			}
			Console.WriteLine("A U B = {0}", "{" + string.Join(", ", listAUB) + "}");
		}
		void Intersection_AB()
		{
			List<int> listAIB = new List<int>(listA.Count);
			
			foreach (var n in listB) {
				if(listA.Contains(n)) listAIB.Add(n);
			}
			Console.WriteLine("A {1} B = {0}", "{" + string.Join(", ", listAIB) + "}", '\u2229');
		}
		void Difference_AB()
		{
			List<int> listAdifB = new List<int>(listA.Count);
			
			foreach (var n in listA) {
				if(!listB.Contains(n)) listAdifB.Add(n);
			}
			Console.WriteLine("A - B = {0}", "{" + string.Join(", ", listAdifB) + "}");
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.Unicode;
			UID_Sets s = new UID_Sets();
			s.Print();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}