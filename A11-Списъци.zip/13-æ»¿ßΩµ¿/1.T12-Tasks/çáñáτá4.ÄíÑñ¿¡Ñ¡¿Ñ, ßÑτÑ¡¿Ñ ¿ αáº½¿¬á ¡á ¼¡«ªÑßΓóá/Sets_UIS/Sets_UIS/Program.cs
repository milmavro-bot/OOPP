﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 14.11.2020 г.
 * Time: 15:33
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace Sets_UIS
{
	class UID_Sets
	{
		List<int> listA, listB;
		
		// Конструктор
		public UID_Sets()
		{
			listA = new List<int>();	// списък с елементите на първото множество (A)
			listB = new List<int>();	// списък с еменентите на второто множество (B)
			FillTheLists();
		}
		
		// Метод void FillTheLists() – извършва запълването на listA и listB със стойности,
		// като организира въвеждане на случайни числа в интервала от 1 до 100 вкл,
		// като не се допускат повторения.
		// Във всеки от списък да се запишат случаен брой числа.
		
		// Указания: За всеки списък се стартира безкраен цикъл
		// и в него се генерира случайно число от посочения диапазон.
		// Ако новото число вече фигурира в списъка – числото не се добавя,
		// а цикъла приключва.
		// Ако новото число не се среща в списъка –
		// добавя се в списъка и цикъла продължава.
		void FillTheLists()
		{
			Random r = new Random();
			int a;
			while (true) 
			{
				a = r.Next(1, 101);
				if(listA.Contains(a)) break;
				listA.Add(a);
			}
			while (true) 
			{
				a = r.Next(1, 101);
				if(listB.Contains(a)) break;
				listB.Add(a);
			}
		}
		
		// Метод void Print() – извежда на екрана съдържанието на двата списъка,
		// всеки на отделен ред.
		// След това се показват резултатите от работата на методите за намиране на обединение,
		// сечение и разлика.
		public void Print()
		{
			Console.WriteLine("A = {0}","{" + string.Join(", ", listA) + "}");
			Console.WriteLine("B = {0}","{" + string.Join(", ", listB) + "}");
			Union_AB();
			Intersection_AB();
			Difference_AB();
		}
		
		// Метод void Union_AB() – намира и извежда множеството от числата,
		// които образуват обединение на списъците listA и listB
		// (тоест числата,
		// които се срещат поне в един от двата списъка –
		// повтарящите се числа се включват в обединението само един път).
		// Пример: А = { 12, 5, 18, 9, 59}   B = { 73, 18, 92, 9} => A U B = { 12, 5, 18, 9, 59, 73, 92, 58}
		void Union_AB()
		{
			List<int> listAUB = new List<int>(listA.Count + listB.Count);
			listAUB.AddRange(listA);
			
			foreach(var n in listB)
			{
				if(!listAUB.Contains(n)) listAUB.Add(n);
			}
			Console.WriteLine("A U B = {0}","{" + string.Join(", ", listAUB) + "}");
		}
		// Метод void Intersection_AB() – намира и извежда множеството от числата,
		// които образуват сечение на списъците listA и listB
		// (тоест числата,
		// които се срещат и в двата списъка).
		// За да изведете символа ∩ използвайте това '\u2229'
		// Пример: А = { 12, 5, 18, 9, 59}   B = { 73, 18, 92, 9} => A ∩ B = { 18, 9}
		void Intersection_AB()
		{
			List<int> listAIB = new List<int>(listA.Count);
			
			
			foreach(var n in listB)
			{
				if(listA.Contains(n)) listAIB.Add(n);
			}
			Console.WriteLine("A {1} B = {0}","{" + string.Join(", ", listAIB) + "}", '\u2229');	
		}
		// Метод void Difference_AB() – намира и извежда множеството от числата,
		// които образуват разликата на списъците listA и listB 
		// (тоест числата,
		// които се срещат само в listA,
		// но не и в listB).
		// Пример: А = { 12, 5, 18, 9, 59}   B = { 73, 18, 92, 9} => A - B = { 12, 5, 59}
		void Difference_AB()
		{
			List<int> listAdifB = new List<int>(listA.Count);
			
			foreach(var n in listA)
			{
				if(!listB.Contains(n)) listAdifB.Add(n);
			}
			Console.WriteLine("A - B = {0}","{" + string.Join(", ", listAdifB) + "}");
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.Unicode;
			UID_Sets s = new UID_Sets();
			s.Print();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}