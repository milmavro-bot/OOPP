﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 12.11.2020 г.
 * Time: 20:18
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace Polynomial
{
	class Polynomial
	{
		List<decimal> cfList;	// списък с коефициентите на многочлена
		
		// Конструктор
		public Polynomial()
		{
			cfList = new List<decimal>();
			GetCoeff();
			//EditCoeff();
		}
		
		// Метод void GetCoeffs() – извършва запълването на cfList със стойности,
		// като организира въвеждане от клавиатурата.
		// Най-напред се въвежда коефициента пред нулевата степен,
		// после коефициента пред първата степен и т.н.
		// За край се въвежда ""(празен ред).
		void GetCoeff()
		{
			Console.WriteLine("Въвеждане на коефициенти:");
			for (int i = 0; ; i++) {
				Console.Write("Коефициент пред степен {0} (само Enter за край): ",i);
				try{
					cfList.Add(decimal.Parse(Console.ReadLine()));
				}
				catch
				{
					break;
				}
			}
			Console.WriteLine("Край на въвеждането!");
			
			cfList.Reverse();
			/*while (cfList.Count > 0) 
			{
				if(cfList[0] == 0m) cfList.RemoveAt(0);
			}*/
		}
		// Метод void ЕditCoeffs() – предлага избор между:
		// - промяна на стойността на определен коефициент;
		// - изтриване на коефициент;
		// - добавяне на коефициент.
		
		// За целта се организира диалог,
		// като първо се извежда многочлена на екрана,
		// след това се "прочита" от клавиатурата вида на действието, …
		// Това се повтаря до въвеждане на  "край".
		void EditCoeff()
		{
			PrintPoly();
		}
		// Метод void CalcAndPrintPolyValues() – изчислява и извежда на екрана стойността на полинома
		// за определена стойност на променливата.
		// За целта най-напред се извежда многочлена на екрана,
		// след това се организира диалог,
		// като от клавиатурата се въвежда стойността на променливата,
		// а после се извежда пресметнатата стойност на многочлена.
		// Това се повтаря до заявяване на отказ.
		public void CalcAndPrintPolyValues()
		{
			decimal m, v;
			if(cfList.Count == 0m)
			{
				PrintPoly();
				return;
			}
			do
			{
				PrintPoly();
				Console.Write("Стойност за х: ");
				m = decimal.Parse(Console.ReadLine());
				v = 0;
				foreach (var a in cfList) {
					v = v * m + a;
				}
				Console.WriteLine("P({0}) = {1}", m, v);
				Console.Write("Още едно пресмятане (Да/Не)? ");
				//cfList.Reverse();
			}
			while(Console.ReadLine().ToLower() == "да");
		}
		// Метод void PrintPoly() – извежда на екрана многочлена,
		// като го подрежда по намаляващ ред на степените.
		public void PrintPoly()
		{
			if(cfList.Count > 0)
			{
				int deg = cfList.Count - 1;
				string t = "P(x) = " + cfList[0] + "x^" + deg;
				deg--;
				for (int i = 1; i < cfList.Count-1; i++, deg--) 
				{
					if (cfList[i] > 0) t += " +" + cfList[i] + "x^" +deg;
					else if(cfList[i] < 0) t += " " + cfList[i] + "x^" +deg;
				}
				if (cfList[cfList.Count - 1] > 0) t += " +" + cfList[cfList.Count-1];
				else if(cfList[cfList.Count - 1] < 0) t += " " + cfList[cfList.Count-1];
				Console.WriteLine(t);
			}
			else Console.WriteLine("P(x) = 0");
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Polynomial p = new Polynomial();
			p.CalcAndPrintPolyValues();
			//p.PrintPoly();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}