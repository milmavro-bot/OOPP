﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 18.11.2020 г.
 * Time: 13:15
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace Horner_11d
{
	class Polynomial
	{
		List<decimal> coeffList;
		
		public Polynomial()
		{
			coeffList = new List<decimal>();
			// Methods:
			GetCoeff();
		}
		
		void GetCoeff()
		{
			Console.WriteLine("Въвеждане на коефициенти:");
			for(int i = 0; ; i++)
			{
				Console.Write("Коефициент пред степен {0} (Enter за край): ", i);
				try {
					coeffList.Add(decimal.Parse(Console.ReadLine()));
				} catch {
					
					break;
				}
			}
			Console.WriteLine("Край на въвеждането!");
			
			coeffList.Reverse();
		}
		
		public void CalcAndPrintPolyValues()
		{
			decimal m, v;
			if(coeffList.Count == 0m)
			{
				PrintPoly();
				return;
			}
			do
			{
				PrintPoly();
				Console.Write("Стойност за x: ");
				m = decimal.Parse(Console.ReadLine());
				v = 0;
				foreach (var a in coeffList) {
					v = v * m + a;
				}
				Console.WriteLine("P({0}) = {1}", m, v);
				Console.Write("Още едно пресмятане (Да/Не)?");
			}while(Console.ReadLine().ToLower() == "да");
		}
		
		public void PrintPoly()
		{
			if(coeffList.Count > 0)
			{
				int deg = coeffList.Count - 1;
				string t = "P(x) = " + coeffList[0] + "x^" + deg;
				deg--;
				for(int i = 1; i < coeffList.Count - 1; i++, deg--)
				{
					if(coeffList[i] > 0) t += " +" + coeffList[i] + "x^" + deg;
					else if(coeffList[i] < 0) t += " " + coeffList[i] + "x^" + deg;
				}
				if(coeffList[coeffList.Count - 1] > 0) t += " +" + coeffList[coeffList.Count - 1];
				else if(coeffList[coeffList.Count - 1] < 0) t += " " + coeffList[coeffList.Count - 1];
				Console.WriteLine(t);
			}
			else Console.WriteLine("P(x) = 0");
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Polynomial pl = new Polynomial();
			pl.CalcAndPrintPolyValues();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}