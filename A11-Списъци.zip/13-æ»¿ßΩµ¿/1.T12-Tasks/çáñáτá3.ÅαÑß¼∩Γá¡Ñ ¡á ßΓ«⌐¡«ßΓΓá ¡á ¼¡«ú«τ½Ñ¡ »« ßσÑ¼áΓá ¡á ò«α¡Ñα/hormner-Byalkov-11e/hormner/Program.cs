﻿using System;
using System.Collections.Generic;

namespace hormner
{
    class Polynomial
    {
        List<int> cfList;
        public int i = 0;
        public double sum=0,number=0;
        public Polynomial()
        {
            cfList = new List<int>();
            GetCoeffs();
        }

        void GetCoeffs()
        {
            Console.WriteLine("Enter numbers!");
            int z;
            string b = "";
            do
            {
                
                Console.Write("Enter the number before the {0} 'x': ",i.ToString());
                b = Console.ReadLine();
                if (b == "")
                {
                    break;
                }
                else
                {

                    z = int.Parse(b);
                    cfList.Add(z);
                    i++;
                }
            } while (b!="");
            Console.WriteLine("The Entering has been ended!");
            PrintPoly(); 
            Console.WriteLine("");
        }
        void PrintPoly()
        {
            Console.Write("P(x)=");
            for (int k = i; k > 0; k--)
            {
                if (k-1==0)
                {
                    Console.Write(" {0}",cfList[k - 1]);
                }
                else if (cfList[k - 1]==0)
                {
                    Console.Write("");
                }
                else
                { 
                    Console.Write(" {1}x^{0} +",k-1,cfList[k - 1]);
                }
            }
        }
        
        public void ЕditCoeffs()
        {
            string a = "";
            int pos,newcoeff;

            while (a != "***")
            {
                Console.Write("Now you can change/delete/add a variable (type *** when you're done): ");
                a =Console.ReadLine();
                if (a == "add")
                {
                    Console.Write("Which coeff. do you want to change? ");
                    pos = int.Parse(Console.ReadLine());
                    Console.Write("What is the new number: ");
                    newcoeff = int.Parse(Console.ReadLine());
                    cfList.Remove(pos - 1);
                    cfList.Insert(pos-1, newcoeff);
                    PrintPoly();
                    
                }
                if (a == "delete")
                {
                    Console.Write("Which coeff. do you want to delete? ");
                    pos = int.Parse(Console.ReadLine());
                    cfList.Remove(pos - 1);
                    PrintPoly();
                    
                }
                if (a == "change")
                {
                    Console.Write("Where do you want to add the new coeff.");
                    pos = int.Parse(Console.ReadLine());
                    Console.Write("What is the new number: ");
                    newcoeff = int.Parse(Console.ReadLine());
                    cfList[pos - 1] = newcoeff;
                    PrintPoly();
                    
                }
                else
                {
                    
                }
                Console.WriteLine(" ");

            }
        }

        public void CalcAndPrintPolyValues()
        {
            PrintPoly();
            string yesorno = "";
            double NumbX = 0,summ=0;
            while (yesorno!="No")
            {
                Console.WriteLine("What is x: ");
                NumbX = int.Parse(Console.ReadLine());
                for (int i = 0; i < cfList.Count; i++)
                {
                    summ = summ + cfList[i];
                }
                Console.WriteLine("P({0})= {1}",NumbX,summ);

                Console.Write("Do you want to try for another x: ");
                yesorno = Console.ReadLine();
                PrintPoly();
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Polynomial pl1 = new Polynomial();
            pl1.ЕditCoeffs();
            pl1.CalcAndPrintPolyValues();
            Console.ReadKey(true);
        }
    }
}
