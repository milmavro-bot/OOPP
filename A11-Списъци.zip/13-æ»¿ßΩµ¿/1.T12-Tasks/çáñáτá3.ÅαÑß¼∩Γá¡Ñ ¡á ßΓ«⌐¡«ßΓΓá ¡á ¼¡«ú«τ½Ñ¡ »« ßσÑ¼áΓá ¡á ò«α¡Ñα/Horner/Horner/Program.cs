﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Horner
{
    class Polynomial
    {
        List<decimal> coeffList;	// списък с коефициентите на многочлена
        
        // Конструктор
        public Polynomial()
        {
        	coeffList = new List<decimal>();
            GetCoeffs();
        }
        // Метод void GetCoeffs() – извършва запълването на cfList със стойности,
		// като организира въвеждане от клавиатурата.
		// Най-напред се въвежда коефициента пред нулевата степен,
		// после коефициента пред първата степен и т.н.
		// За край се въвежда ""(празен ред).
        void GetCoeffs()
        {
        	Console.WriteLine("Въвеждане на коефициенти:");
            string input = "0";
            int i = 0;
            do
            {
                coeffList.Add(decimal.Parse(input));
                Console.Write("Коефициент пред степен {0} (само Enter за край): ", i);
                input = Console.ReadLine();
                i++;
            } while (input != "");
            coeffList.RemoveAt(0);
            Console.WriteLine("Край на въвеждането!");
        }
        
        // Метод void ЕditCoeffs() – предлага избор между:
		// - промяна на стойността на определен коефициент;
		// - изтриване на коефициент;
		// - добавяне на коефициент.
		
		// За целта се организира диалог,
		// като първо се извежда многочлена на екрана,
		// след това се "прочита" от клавиатурата вида на действието, …
		// Това се повтаря до въвеждане на  "край".
        /*public void EditCoeffs()
        {
            string action = "***";
            while(action!="")
            {
                Console.Write("Какво искате да направите (edit, delete, add) ");
                action = Console.ReadLine();
                if(action=="edit")
                {
                    int index=0;
                    Console.Write("Коефициента на коя позиция искате да промените? ");
                    index = Int32.Parse(Console.ReadLine());
                    Console.Write("Колко да бъде новата стойност? ");
                    double n= Double.Parse(Console.ReadLine());
                    cfList[index-1] = n;
                }
                if(action=="delete")
                {
                    int index = 0;
                    this.PrintPolly();
                    Console.Write("Коефициент на коя позиция искате да изтриете? ");
                    index = Int32.Parse(Console.ReadLine());
                    cfList.RemoveAt(index);
                }
                if(action=="add")
                {
                    
                    Console.Write("Колко да бъде стойността на добавения коефициент? ");
                    Double n = Double.Parse(Console.ReadLine());
                    cfList.Add(n);
                }
            }
        }*/
        
        // Метод void CalcAndPrintPolyValues() – изчислява и извежда на екрана стойността на полинома
		// за определена стойност на променливата.
		// За целта най-напред се извежда многочлена на екрана,
		// след това се организира диалог,
		// като от клавиатурата се въвежда стойността на променливата,
		// а после се извежда пресметнатата стойност на многочлена.
		// Това се повтаря до заявяване на отказ.
        public void CalcAndPrintPolyValues()
        {
            
            while(true)
            {
                PrintPolly();
                decimal x;
                Console.Write("Стойност за x: ");
                x = decimal.Parse(Console.ReadLine());
                decimal result = 0;
                for(int i = coeffList.Count-1; i>=0; i--)
                {
                    result += x * coeffList[i];
                }
                Console.WriteLine("Стойност за x = {0}: P({0}) = {1}", x, result);
                Console.Write("Още едно пресмятане? (Да/Не) ");
                string yesno = Console.ReadLine();
                if (yesno == "Не".ToLower()) break;
            }
        }
        
        // Метод void PrintPoly() – извежда на екрана многочлена,
		// като го подрежда по намаляващ ред на степените.
        public void PrintPolly()
        {
            Console.Write("P(x) = ");
            for( int i = coeffList.Count - 1; i >= 1; i--)
            {
                if (coeffList[i] > 0 && i<coeffList.Count - 1) Console.Write(" +");
                Console.Write("{0}x^{1} ", coeffList[i], i);
            }
            if (coeffList[0] > 0) Console.Write(" +");
            Console.WriteLine("{0}", coeffList[0]);
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Polynomial p = new Polynomial();
            //p.EditCoeffs();
            p.CalcAndPrintPolyValues();
            
            Console.ReadKey(true);
        }
    }
}
