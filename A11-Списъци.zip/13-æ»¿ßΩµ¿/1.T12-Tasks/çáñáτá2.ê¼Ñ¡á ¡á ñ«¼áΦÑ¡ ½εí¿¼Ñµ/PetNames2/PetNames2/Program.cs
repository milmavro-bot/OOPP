﻿/*
 * Created by SharpDevelop.
 * User: Bobo
 * Date: 17.11.2020 г.
 * Time: 9:32
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace PetName
{
	class PetNames
	{
		List<string> favNames;	// списък с всички "предложени" имена
		
		// Конструктор
		public PetNames()
		{
			favNames = new List<string>();
			GetNames();
		}
		
		// Метод void GetNames() – извършва запълването на favNames със стойности,
        // като организира въвеждане от клавиатурата (за край се въвежда ***).
        // Повторения не се допускат –
        // ако се въведе от клавиатурата име,
        // което вече се съдържа в списъка,
        // то не трябва да се добавя повторно.
		void GetNames()
		{
			Console.WriteLine("Запълване на списъка!");
			do
			{
				Console.Write("Въведете име: ");
				string s = Console.ReadLine();
				if(favNames.IndexOf(s) == -1) favNames.Add(s);
			}
			while(favNames[favNames.Count - 1] != "***");
			favNames.Remove("***");
			Console.WriteLine("Край на запълването!");
		}
		// Метод void RemoveNames() – изтрива от списъка определени имена.
        // За целта се организира диалог,
        // като първо се извежда съдържанието на списъка на екрана,
        // след това се "прочита" име за изтриване и то се премахва от списъка.
        // Това се повтаря до въвеждане на  ***.
		public void RemoveNames()
		{
			Console.WriteLine("Редакция на списъка - възможност за изтриване!");
			string s = "";
			do
			{
				
				PrintList();
				Console.Write("Изберете име за изтриване: ");
				s = Console.ReadLine();
				favNames.Remove(s);
			}
			while(s != "***");
			Console.WriteLine("Край на изтриването!");
		}
		// Метод void MoveToPosition() –
        // премества дадено име от списъка от текущата му позиция на друга (посочена) позиция.
        // За целта се организира диалог,
        // като първо се извежда съдържанието на списъка на екрана,
        // след това се "прочита" името за преместване и новата му позиция и
        // посоченото име се премества на посоченото място.
        // Това се повтаря до въвеждане на  ***.
		public void MoveToPosition()
		{
			Console.WriteLine("Редакция на списъка - възможност за преместване!");
			string s = "";
			int index;
			PrintList();
			Console.Write("Изберете име за преместване: ");
			s = Console.ReadLine();
			while(s != "***")
			{
				Console.Write("Посочете номера на новата позиция: ");
				index = int.Parse(Console.ReadLine());
				if(favNames.Contains(s))
				{
					favNames.Remove(s);
					favNames.Insert(index - 1, s);
				}
				PrintList();
				Console.Write("Изберете име за преместване: ");
				s = Console.ReadLine();				
			}
			Console.WriteLine("Край на разместването!");
		}
		
		// Метод void PrintList() – извежда на екрана имената от списъка (разделени с "//").
		public void PrintList()
		{
			Console.WriteLine("Списък: {0}", string.Join("//", favNames));
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			PetNames p = new PetNames();
			p.RemoveNames();
			p.MoveToPosition();
			p.PrintList();
			Console.ReadKey(true);
		}
	}
}