﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 17.11.2020 г.
 * Time: 9:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace MyPetName
{
	class PetNames
	{
		List<string> favNames;
		public PetNames()
		{
			favNames = new List<string>();
			// Methods:
			GetNames();
		}
		
		void GetNames()
		{
			Console.WriteLine("Запълване на списъка!");
			string input = "";
			while(input != "***")
			{
				if(favNames.IndexOf(input) == -1) favNames.Add(input);
				Console.Write("Въведете име: ");
				input = Console.ReadLine();
			}
			Console.WriteLine("Край на запълването!");
		}
		
		public void PrintList()
		{
			Console.Write("Списък: {0}", favNames[0]);
			for(int i = 1; i < favNames.Count; i++)
			{
				Console.Write("//{0}", favNames[i]);
			}
			Console.WriteLine();
		}
		
		public void RemoveNames()
		{
			string input = "";
			Console.WriteLine("Редакция на списъка - възможност за изтриване!");
			do
			{
				bool flag = false;
				if(favNames.IndexOf(input) != -1)
				{
					favNames.Remove(input);
					PrintList();
					flag = true;
				}
				if(!flag) PrintList();
				Console.Write("Изберете име за изтриване: ");
				input = Console.ReadLine();
			}while(input != "***");
			Console.WriteLine("Край на изтриването!");
		}
		public void MoveToPosition()
		{
			string input = "";
			int pos = 0;
			Console.WriteLine("Редакция на списъка - въвможност за разместване!");
			do
			{
				if(favNames.IndexOf(input) != -1)
				{
					favNames.Remove(input);
					favNames.Insert(pos, input);
				}
				PrintList();
				Console.Write("Изберете име за разместване: ");
				input = Console.ReadLine();
				if(input == "***") break;
				Console.Write("Посочете номера на новата позиция: ");
				pos = int.Parse(Console.ReadLine()) - 1;
			}while(true);
			Console.WriteLine("Край на разместването!");
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			PetNames pn = new PetNames();
			pn.RemoveNames();
			pn.MoveToPosition();
			pn.PrintList();
			
			Console.ReadKey(true);
		}
	}
}