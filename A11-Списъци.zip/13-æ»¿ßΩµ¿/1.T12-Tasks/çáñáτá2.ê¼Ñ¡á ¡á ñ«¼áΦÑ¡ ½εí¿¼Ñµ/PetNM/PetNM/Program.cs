﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.11.2020 г.
 * Time: 15:39
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Linq;

namespace PetNM
{
	class PetNames
	{
		List<string> favNames;	// списък с всички "предложени" имена
		
		// Конструктор
		public PetNames()
		{
			favNames = new List<string>();
			// GetNames();
		}
		
		// Метод void GetNames() – извършва запълването на favNames със стойности,
		// като организира въвеждане от клавиатурата
		// (за край се въвежда ***).
		// Повторения не се допускат –
		// ако се въведе от клавиатурата име,
		// което вече се съдържа в списъка, 
		// то не трябва да се добавя повторно.
		
	}
	class Program
	{
		public static void Main(string[] args)
		{
			
			
			Console.ReadKey(true);
		}
	}
}