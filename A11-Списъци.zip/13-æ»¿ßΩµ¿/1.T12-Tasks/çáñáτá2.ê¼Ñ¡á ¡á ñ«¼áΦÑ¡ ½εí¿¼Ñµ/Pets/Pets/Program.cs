﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pets
{
    class PetNames
    {
        List<string> favNames;	// списък с всички "предложени" имена
        
        // Конструктор
        public PetNames()
        {
        	favNames = new List<string>();
            this.GetNames();
        }
        
        // Метод void GetNames() – извършва запълването на favNames със стойности,
        // като организира въвеждане от клавиатурата (за край се въвежда ***).
        // Повторения не се допускат –
        // ако се въведе от клавиатурата име,
        // което вече се съдържа в списъка,
        // то не трябва да се добавя повторно.
        void GetNames()
        {
            Console.WriteLine("Запълване на списъка!");
            string input = "";
            while(input != "***")
            {
                if(favNames.IndexOf(input) == -1) favNames.Add(input);
                Console.Write("Въведете име: ");
                input = Console.ReadLine();
            }
            
            Console.WriteLine("Край на запълването!");
        }
        
        // Метод void PrintList() – извежда на екрана имената от списъка (разделени с "//").
        public void PrintList()
        {
            Console.Write("Списък: {0}", favNames[0]);
            for( int i = 1; i < favNames.Count; i++)
            {
                Console.Write("\\{0}", favNames[i]);
            }
            Console.WriteLine();
        }
        
        // Метод void RemoveNames() – изтрива от списъка определени имена.
        // За целта се организира диалог,
        // като първо се извежда съдържанието на списъка на екрана,
        // след това се "прочита" име за изтриване и то се премахва от списъка.
        // Това се повтаря до въвеждане на  ***.
        public void RemoveNames()
        {
            string input = "";
            Console.WriteLine("Редакция на списъка - възможност за изтриване!");
            
            do
            {
                bool flag = false;
                if (favNames.IndexOf(input) != -1)
                {
                    favNames.Remove(input);
                    this.PrintList();
                    flag = true;
                }
                if (!flag) this.PrintList();
                Console.Write("Изберете име за изтриване: ");
                input = Console.ReadLine();
                
            } while (input != "***");
            Console.WriteLine("Край на изтриването!");
        }
        // Метод void MoveToPosition() –
        // премества дадено име от списъка от текущата му позиция на друга (посочена) позиция.
        // За целта се организира диалог,
        // като първо се извежда съдържанието на списъка на екрана,
        // след това се "прочита" името за преместване и новата му позиция и
        // посоченото име се премества на посоченото място.
        // Това се повтаря до въвеждане на  ***.
        public void MoveToPosition()
        {
            string name="";
            int pos = 0;
            Console.WriteLine("Редакция на списъка - възможност за разместване на списъка!");
            do
            {
                if (favNames.IndexOf(name) != -1)
                {
                    favNames.Remove(name);
                    favNames.Insert(pos, name);
                }
                this.PrintList();
                Console.Write("Изберете име за разместване: ");
                name = Console.ReadLine();
                if (name == "***") break;
                Console.Write("Посочете номера на новата позиция: ");
                pos = int.Parse(Console.ReadLine()) - 1;
                
            } while (true);
            Console.WriteLine("Край на разместването!");
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            PetNames p1 = new PetNames();
            p1.RemoveNames();
            p1.MoveToPosition();
            p1.PrintList();
            Console.ReadKey(true);
        }
    }
}
