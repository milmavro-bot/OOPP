﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 14.1.2021 г.
 * Time: 8:39
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace duties
{
	public class CarFromGermany : Car
	{
		public CarFromGermany(string model, double price, int volumeEngine)
			: base(model, price, volumeEngine)
		{
			Console.WriteLine("Държава производител: Германия");
		}
		public override double CalcDuty()
		{
			double tariff = 0;
			if(volumeEngine >= 0 && volumeEngine <= 1000)
			{
				tariff = 0.15;
			}
			else if(volumeEngine >= 1001 && volumeEngine <= 3000)
			{
				tariff = 0.2;
			}
			else if(volumeEngine >= 3001)
			{
				tariff = 0.25;
			}
			const double TRANSPORT_COSTS = 550;
			return (base.CalcDuty() + TRANSPORT_COSTS) * tariff;
		}
		public override void PrintInfo()
		{
			Console.WriteLine("Марка: Golf");
			base.PrintInfo();
			Console.WriteLine(new String('-', 30));
			Console.WriteLine("Мито (лв): {0:0.00}", CalcDuty());
		}
	}
}
