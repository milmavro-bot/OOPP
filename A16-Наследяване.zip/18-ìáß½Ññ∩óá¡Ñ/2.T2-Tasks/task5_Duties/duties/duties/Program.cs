﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 14.1.2021 г.
 * Time: 6:43
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace duties
{
	class Program
	{
		public static void Main(string[] args)
		{
			CarFromGermany cg = new CarFromGermany("VW", 28000, 1800);
			cg.PrintInfo();
			Console.WriteLine();
			CarFromFrance cf = new CarFromFrance("Clio", 12000, 1300);
			cf.PrintInfo();
			
			Console.Write(". . . ");
			Console.ReadKey(true);
		}
	}
}