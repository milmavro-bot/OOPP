﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 15.1.2021 г.
 * Time: 7:03
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace duties
{
	public class CarFromFrance : Car
	{
		public CarFromFrance(string model, double price, int volumeEngine)
			: base(model, price, volumeEngine)
		{
			Console.WriteLine("Държава производител: Франция");
		}
		public override double CalcDuty()
		{
			double tariff = 0;
			if(volumeEngine >= 0 && volumeEngine <= 1000)
			{
				tariff = 0.15;
			}
			else if(volumeEngine >= 1001 && volumeEngine <= 3000)
			{
				tariff = 0.2;
			}
			else if(volumeEngine >= 3001)
			{
				tariff = 0.25;
			}
			const double TRANSPORT_COSTS = 600;
			return (base.CalcDuty() + TRANSPORT_COSTS) * tariff;
		}
		public override void PrintInfo()
		{
			Console.WriteLine("Марка: Renault");
			base.PrintInfo();
			Console.WriteLine(new String('-', 30));
			Console.WriteLine("Мито (лв): {0:0.00}", CalcDuty());
		}
	}
}
