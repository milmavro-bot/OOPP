﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 14.1.2021 г.
 * Time: 8:17
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace duties
{
	public class Car
	{
		string model;
		double price;
		protected int volumeEngine;
		public Car(string m, double pr, int volume)
		{
			model = m;
			price = pr;
			volumeEngine = volume;
		}
		public virtual double CalcDuty()
		{
			return price;
		}
		public virtual void PrintInfo()
		{
			Console.WriteLine("Модел: {0}", model);
			Console.WriteLine("Обем на двигателя: {0} к.с.", volumeEngine);
			Console.WriteLine("Цена (лв): {0:0.00}", price);
		}
	}
}
