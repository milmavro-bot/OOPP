﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 30.12.2020 г.
 * Time: 7:27
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace VirtualBank
{
	public class BankAccount
	{
		protected double balance;
		
		public BankAccount()
		{
			balance = 0;
		}
		public BankAccount(double b)
		{
			balance = b;
		}
		
		public virtual void Deposit(double amount)
		{
			balance = balance + amount;
		}
		public virtual void Withdraw(double amount)
		{
			balance = balance - amount;
			if(balance < 0)
			{
				Console.WriteLine("Insufficient availability!");
				balance += amount;
			}
		}
		public void PrintBalance()
		{
			Console.WriteLine("Balance: {0:#.00}", balance);
		}
	}
}
