﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 5.1.2021 г.
 * Time: 13:52
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace HeatingEquipment
{
	/// <summary>
	/// Description of Heater.
	/// </summary>
	public class Heater
	{
		protected bool isWorking;
		protected Heater()
		{
			isWorking = false;
		}
		
		public virtual void TurnOn()
		{
			if(isWorking) return;
			Console.WriteLine("Изпълнете посочените действия и се насладете на топлината :)");
			isWorking = true;
		}
		
		public virtual void TurnOff()
		{
			if(!isWorking) return;
			Console.WriteLine("Изпълнете точно изброените действия!");
			isWorking = false;
		}
	}
}
