﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 5.1.2021 г.
 * Time: 16:32
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace HeatingEquipment
{
	/// <summary>
	/// Description of ElectricRadiator.
	/// </summary>
	public class ElectricRadiator : Heater
	{
		public ElectricRadiator()
		{
			Console.WriteLine("Електрически радиатор");
		}
		
		public override void TurnOn()
		{
			if(isWorking) return;
			base.TurnOn();
			Console.WriteLine("Включете радиатора в захранването.{0}Поставете бутона за включване/изключване в позиция \"Включено\".{0}Изберете желаната степен.", Environment.NewLine);
		}
		
		public override void TurnOff()
		{
			if(!isWorking) return;
			base.TurnOff();
			Console.WriteLine("Поставете бутона за включване/изключване в позиция \"Изключено\".{0}Изключете радиатора от захранването.", Environment.NewLine);
		}
	}
}
