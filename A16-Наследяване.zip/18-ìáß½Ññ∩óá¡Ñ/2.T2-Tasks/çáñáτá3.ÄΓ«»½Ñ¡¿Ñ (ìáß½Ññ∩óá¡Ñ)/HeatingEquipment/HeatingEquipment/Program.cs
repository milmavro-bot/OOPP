﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 5.1.2021 г.
 * Time: 13:52
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace HeatingEquipment
{
	class Program
	{
		public static void Main(string[] args)
		{
			Fireplace fp = new Fireplace();
			fp.TurnOn();
			Console.WriteLine();
			fp.TurnOff();
			Console.WriteLine();
			Console.WriteLine();
			
			GasStove gs = new GasStove();
			gs.TurnOn();
			Console.WriteLine();
			gs.TurnOff();
			Console.WriteLine();
			Console.WriteLine();
			
			Heater h = new ElectricRadiator();
			h.TurnOn();
			Console.WriteLine();
			h.TurnOff();
			Console.WriteLine();
			Console.WriteLine();

			h = new AirConditioner();
			h.TurnOn();
			Console.WriteLine();
			h.TurnOff();
			Console.WriteLine();
			Console.WriteLine();
		
			
			Console.ReadKey(true);
		}
	}
}