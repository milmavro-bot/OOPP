﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 5.1.2021 г.
 * Time: 16:23
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace HeatingEquipment
{
	public class GasStove : Heater
	{
		// Конструктор
		public GasStove()
		{
			Console.WriteLine("Газова печка");
		}
		
		// public void TurnOn() – "включва" уреда, като:
		// Ако полето isWorking има стойност true, методът на прави нищо.
		// Ако полето isWorking има стойност false –
		// извиква съответния метод от базовия клас и след това извежда съобщението
		// "Отворете клапата на газта и запалете.
		// Изберете желаната степен.".
		public override void TurnOn()
		{
			if(isWorking) return;
			base.TurnOn();
			Console.WriteLine("Отворете клапата на газта и запалете.{0}Изберете желаната степен.", Environment.NewLine);
		}
		// void TurnOff() – "изключва" уреда, като:
		// Ако полето isWorking има стойност false, методът на прави нищо.
		// Ако полето isWorking има стойност true –
		// извиква съответния метод от базовия клас и след това извежда съобщението
		// "Загасете пламъка и затворете клапата на газта.
		// Проверете повторно дали клапата на газта е затворена!".
		public override void TurnOff()
		{
			if(!isWorking) return;
			base.TurnOff();
			Console.WriteLine("Загасете пламъка и затворете клапата на газта.{0}Проверете повторно дали клапата на газта е затворена!", Environment.NewLine);
		}
	}
}
