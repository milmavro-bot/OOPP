﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 5.1.2021 г.
 * Time: 14:05
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace HeatingEquipment
{
	public class Fireplace : Heater
	{
		// Конструктор
		public Fireplace()
		{
			Console.WriteLine("Камина с дърва");
		}
		
		// public void TurnOn() – "включва" уреда, като:
		// Ако полето isWorking има стойност true, методът на прави нищо.
		// Ако полето isWorking има стойност false –
		// извиква съответния метод от базовия клас и след това извежда съобщението:
		// "Изчистете камината, ако е нужно.
		// Заредете я с дърва.
		// Отворете клапата и запалете огъня.".
		public override void TurnOn()
		{
			if(isWorking) return;
			base.TurnOn();
			Console.WriteLine("Изчистете камината, ако е нужно.{0}Заредете я с дърва.{0}Отворете клапата и запалете огъня.",
			                  Environment.NewLine);
		}
		// void TurnOff() – "изключва" уреда, като:
		// Ако полето isWorking има стойност false, методът на прави нищо.
		// Ако полето isWorking има стойност true –
		// извиква съответния метод от базовия клас и след това извежда съобщението
		// "Затворете клапата на камината.
		// Уверете се, че дървата за загаснали.
		// Уверете се, че няма останали живи въглени.
		// Съберете и изхвърлете пепелта.".
		public override void TurnOff()
		{
			if(!isWorking) return;
			base.TurnOff();
			Console.WriteLine("Затворете клапата.{0}Уверете се, че дървата за загаснали.{0}Уверете се, " +
			                  "че няма останали живи въглени.{0}Съберете и изхвърлете пепелта.", Environment.NewLine);
		}
	}
}
