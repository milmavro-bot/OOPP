﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 5.1.2021 г.
 * Time: 16:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace HeatingEquipment
{
	/// <summary>
	/// Description of AirConditioner.
	/// </summary>
	public class AirConditioner : Heater
	{
		public AirConditioner()
		{
			Console.WriteLine("Климатик");
		}
		
		public override void TurnOn()
		{
			if(isWorking) return;
			base.TurnOn();
			Console.WriteLine("Включете климатика в захранването.{0}Включете го от дистанционното управление.{0}Настройте на \"Отопление\".{0}Изберете желаната температура.", Environment.NewLine);
		}
		
		public override void TurnOff()
		{
			if(!isWorking) return;
			base.TurnOff();
			Console.WriteLine("Изключете климатика от дистанционното управление.", Environment.NewLine);
		}
	}
}
