﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.1.2021 г.
 * Time: 9:36
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace hotel
{
	public class Apartment : SingleRoom
	{
		bool isFB;
		public Apartment(DateTime dateOfAccommodation, DateTime dateOfDeparture, bool fb)
			: base(dateOfAccommodation, dateOfDeparture)
		{
			isFB = fb;
		}
		public override double CalcPrice()
		{
			const double PRICE_FB = 22.0;
			if(isFB)
			{
				return (base.CalcPrice() * 2) + PRICE_FB;
			}
			return base.CalcPrice() * 2;
		}
		string FullBoard()
		{
			if(isFB) return "Да";
			return "Не";
		}
		public override void Info()
		{
			Console.WriteLine("Апартамент");
			Console.WriteLine("Пълен пансион: {0}", FullBoard());
			base.Info();
		}
	}
}
