﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.1.2021 г.
 * Time: 8:40
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace hotel
{
	public class SingleRoom : Room
	{
		public SingleRoom(DateTime dateOfAccommodation, DateTime dateOfDeparture)
			: base(dateOfAccommodation, dateOfDeparture)
		{
			Console.WriteLine("Хотел 'Импулс'");
		}
		public virtual double CalcPrice()
		{
			double p = 0;
			if(NumberOfNights() >= 1 && NumberOfNights() <= 3)
			{
				p = 20.0;
			}
			else if(NumberOfNights() > 3 && NumberOfNights() <= 9)
			{
				p = 18.0;
			}
			else if(NumberOfNights() > 9)
			{
				p = 16.0;
			}
			else
			{
				p = 0;
			}
			return p * NumberOfNights();
		}
		public override void Info()
		{
			base.Info();
			Console.WriteLine("Крайна цена: {0:0.00} лева\n", CalcPrice());
		}
	}
}
