﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 12.1.2021 г.
 * Time: 12:40
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace hotel
{
	class Program
	{
		public static void Main(string[] args)
		{
			SingleRoom sr = new SingleRoom(new DateTime(2021, 1, 5), new DateTime(2021, 1, 10));
			sr.Info();
			Apartment ap = new Apartment(new DateTime(2021, 1, 10), new DateTime(2021, 1, 18), false);
			ap.Info();
			
			Console.Write(". . . ");
			Console.ReadKey(true);
		}
	}
}