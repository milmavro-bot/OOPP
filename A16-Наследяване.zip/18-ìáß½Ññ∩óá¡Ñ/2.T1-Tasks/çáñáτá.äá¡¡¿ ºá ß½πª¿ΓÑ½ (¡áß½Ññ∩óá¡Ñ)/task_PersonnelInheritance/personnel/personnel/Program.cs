﻿using System;

namespace personnel
{
    class Person
    {
        private string name; // поле
        // Конструктор по подразбиране
        public Person() { name = "Unknown"; }
        // Задаване на име
        public void SetName(string nm) { name = nm; }
        // Отпечатване на име
        public void Print()
        {
            Console.WriteLine("Employee name: {0}", name);
        }
    }
    class Contact : Person
    {
        private string address; // поле
        // Конструктор по подразбиране
        public Contact() { address = "No permanent address"; }
        // Записване на адрес
        public void SetAddress(string adr) { address = adr; }
        // Отпечатване на име и адрес
        public void PrintInfo()
        {
            Print(); // активиране на метода от Person
            Console.WriteLine("Employee address: {0}", address);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Contact contact = new Contact();
            Console.WriteLine("Enter an employee name:");
            contact.SetName(Console.ReadLine());
            Console.WriteLine("Enter an employee address:");
            contact.SetAddress(Console.ReadLine());
            Console.WriteLine(new String('=', 35));
            Console.WriteLine("Employee details");
            Console.WriteLine(new String('-', 35));
            contact.PrintInfo();
            Console.ReadKey(true);
        }
    }
}
