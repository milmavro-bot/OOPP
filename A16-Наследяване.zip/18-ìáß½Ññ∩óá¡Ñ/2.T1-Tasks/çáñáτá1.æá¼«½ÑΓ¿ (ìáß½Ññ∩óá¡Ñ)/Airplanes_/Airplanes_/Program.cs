﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.12.2020 г.
 * Time: 16:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Airplanes_
{
	
	class Program
	{
		public static void Main(string[] args)
		{
			Airliner b737 = new Airliner("United Airlines","Варна - Прага", 123);
			b737.GetPassangersOnAndDepart();
			b737.LandAndGetPassangersOff();
			
			Fighter f14 = new Fighter("България","Унищожаване на ПВО база");
			f14.CompleteTheMission();
			
			Bomber b52 = new Bomber("СССР", "Ликвидиране на лагери на афганистанската съпротива");
			b52.CompleteTheMission();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}