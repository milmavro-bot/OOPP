﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.12.2020 г.
 * Time: 16:29
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Airplanes_
{
	/// <summary>
	/// Description of Airplane.
	/// </summary>
	public class Airplane
	{
		protected string planeId;	// идентификатор на самолета
		protected int fuelLevel;	// число от 0 до 100 (процент от макс. количество гориво)
		protected bool isFlying;	// true, ако самолетът е в полет; false, ако самолетът е на земята

		// Конструктор
		public Airplane()
		{
			Random r = new Random();
			planeId = "" + (char)('A' + r.Next(0, 26));
			planeId +=(char)('A' + r.Next(0, 26));
			planeId += r.Next(0, 10);
			planeId += r.Next(0, 10);
			planeId += r.Next(0, 10);
			fuelLevel = r.Next(35, 76);
			isFlying = false;
		}
		
		// void StartTakeOff() – ако полето isFlying има стойност false,
		// извежда съобщението "Старт на двигателите! …. Засилване! … Излитане! … Набиране на височина!"
		// и променя стойността на полето isFlying на true.
		// Ако полето isFlying има стойност true, методът на прави нищо.
		protected void StartTakeOff()
		{
			if(!isFlying)
			{
				isFlying = true;
				Console.WriteLine("Старт на двигателите!... Засилване!... Излитане!... Набиране на височина!");
			}
		}
		// void StartLanding() – ако полето isFlying има стойност true,
		// извежда съобщението "Снижаване! … Заход за кацане! … Кацане! … Стоп на двигателите!"
		// и променя стойността на полето на false.
		// Ако полето isFlying има стойност false, методът на прави нищо.
		protected void StartLanding()
		{
			if(isFlying)
			{
				isFlying = false;
				Console.WriteLine("Снижаване!... Заход за кацане!... Кацане!... Стоп на двигателите!");
			}
		}
		// void LoadFuel(int fuelToAdd) – увеличава количеството гориво със стойността на параметъра,
		// но така, че стойността на fuelLevel да не стане повече от 100.
		// Извежда съобщението "Зареждане с гориво! Степен на запълване на резервоарите: ??%",
		// където ?? е стойността на полето fuelLevel.
		protected void LoadFuel(int fuelToAdd)
		{
			fuelLevel = Math.Min(fuelLevel + fuelToAdd, 100);
			Console.WriteLine("Зареждане с гориво! Степен на запълване на резервоарите: {0}%", fuelLevel);
		}
	}
}
