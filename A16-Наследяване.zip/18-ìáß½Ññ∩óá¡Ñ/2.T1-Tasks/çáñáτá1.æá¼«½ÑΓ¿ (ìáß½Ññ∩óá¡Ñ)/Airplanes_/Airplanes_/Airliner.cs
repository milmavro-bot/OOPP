﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.12.2020 г.
 * Time: 16:37
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Airplanes_
{
	/// <summary>
	/// Description of Airliner.
	/// </summary>
	public class Airliner : Airplane
	{
		string	airline;		// име на авиокомпанията
		int	passangersToFly;	// брой пътници според продадените билети
		string	flight;			// направление на полета

		// Конструктор
		public Airliner(string aName, string fl, int psTF)
		{
			airline = aName;
			passangersToFly = psTF;
			flight = fl;
		}
		
		// - извежда съобщение с данните за самолета и полета от типа "Самолет planeId на airline по маршрут flight с passangersToFly пътници"
		// - извиква метода LoadFuel() с параметър – случайно число между 20 и 40;
		// - организира последователно "качване" на пътниците – изписва "Качване на пътници…" и "заспива" за 0,75 секунди и го повтаря 3 пъти;
		// - изписва "Всички пътници са на борда!";
		// - извиква метода StartTakeOff().
		public void GetPassangersOnAndDepart() 
		{
			Console.WriteLine("Самолет {0} на {1} по маршрут {2} с {3} пътници", planeId, airline, flight, passangersToFly);
			Random r = new Random();
			LoadFuel(r.Next(20, 41));	// извиква метода LoadFuel() с параметър – случайно число между 20 и 40;
			for (int i = 0; i < 3; i++) // организира последователно "качване" на пътниците – изписва "Качване на пътници…" и "заспива" за 0,5 секунди и го повтаря 3 пъти;
			{
				Console.Write("Качване на пътници ... ");
				System.Threading.Thread.Sleep(1000);
			}
			Console.WriteLine();
			Console.WriteLine("Всички пътници са на борда!");
			StartTakeOff(); 			// извиква метода StartTakeOff().
			Console.WriteLine();
		}
		// - извежда съобщение с данните за самолета и полета от типа "Самолет planeId на airline по маршрут flight с passangersToFly пътници"
		// - извиква метода StartLanding();
		// - организира последователно "слизане" на пътниците – изписва "Слизане на пътници…" и "заспива" за 0,75 секунди и го повтаря 3 пъти;
		// - изписва "Всички пътници са напуснали самолета! Полетът приключи!".
		public void LandAndGetPassangersOff() 
		{
			Console.WriteLine("Самолет {0} на {1} по маршрут {2} с {3} пътници", planeId, airline, flight, passangersToFly);
			StartLanding();
			for (int i = 0; i < 3; i++) 
			{
				Console.Write("Слизане на пътници ... ");
				System.Threading.Thread.Sleep(1000);
			}
			Console.WriteLine();
			Console.WriteLine("Всички пътници са напуснали самолета! Полетът приключи!");
			Console.WriteLine();
		}
	}
}
