﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.12.2020 г.
 * Time: 17:18
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Airplanes_
{
	/// <summary>
	/// Description of Bomber.
	/// </summary>
	public class Bomber:Airplane
	{
		string	country;	// име на държавата от чиито ВВС е бомбардировачът
		int	bombs;			// брой на бомбите
		string	mission;	// описание на мисията
		
		// Конструктор
		public Bomber(string cn, string msn)
		{
			country = cn;
			mission = msn;
			bombs = 0;
		}
		
		// void LoadBombs() - изписва "Зареждане с бомби!"
		// и записва в полето bombs случайно число между 30 и 50 включително;
		void LoadBombs()  
		{
			Console.WriteLine("Зареждане на бомби!");
			Random r = new Random();
			bombs = r.Next(30, 51);
		}
		// void DropABomb() - ако стойността на bombs надвишава 0,
		// изписва "Б…!" и стойността на bombs се намалява с 1.
		// Ако стойността на bombs е 0 – не прави нищо.
		void DropABomb() 
		{
			if(bombs > 0)
			{
				Console.Write("Б...! ");
				bombs--;
			}
		}
		// void CompleteTheMission() – симулира изпълнението на мисия, като:
		// - извежда съобщение с данните за самолета и мисията от типа "Бомбардировач planeId от ВВС на country на мисия mission"
		// - извиква метода LoadFuel() с параметър – случайно число между 30 и 50;
		// - извиква метода LoadBombs();
		// - извиква метода StartTakeOff();
		// - организира симулация на бомбардировка – N извиквания на метода DropABomb(), като N е случайно число между 20 и 60 включително;
		// - извиква метода StartLanding();
		// - изписва "Мисията е изпълнена! Полетът приключи!".
		public void CompleteTheMission()
		{
			Console.WriteLine("Бомбардировач {0} от ВВС на {1} на мисия {2}", planeId, country, mission);
			Random r = new Random();
			LoadFuel(r.Next(30, 51));
			LoadBombs();
			StartTakeOff();
			Console.WriteLine();
			int n = r.Next(20, 61);
			for (int i = 0; i < n; i++) {
				DropABomb();
			}
			Console.WriteLine();
			Console.WriteLine();
			StartLanding();
			Console.WriteLine("Мисията е изпълнена! Полетът приключи!");
		}
	}
}
