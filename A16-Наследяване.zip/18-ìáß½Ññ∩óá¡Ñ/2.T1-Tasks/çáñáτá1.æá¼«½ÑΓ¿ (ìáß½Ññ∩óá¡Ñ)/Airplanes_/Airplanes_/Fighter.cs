﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.12.2020 г.
 * Time: 16:57
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Airplanes_
{
	/// <summary>
	/// Description of Fighter.
	/// </summary>
	public class Fighter : Airplane
	{
		string	country;	// име на държавата, от чиито ВВС е изтребителят
		int	missiles;		// брой на ракетите
		string	mission;	// описание на мисията

		// Конструктор
		public Fighter(string cn, string msn)
		{
			country = cn;
			mission = msn;
			missiles = 0;
		}
		
		// void LoadMissiles() – изписва "Зареждане на ракети!"
		// и записва в полето missiles случайно число между 6 и 12 включително;
		void LoadMissiles() 
		{
			Console.WriteLine("Зареждане на ракети!");
			Random r = new Random();
			missiles = r.Next(6, 13);
		}
		// void FireAMissile() – ако стойността на missiles надвишава 0,
		// изписва "Изстреляна е ракета!" и стойността на missiles се намалява с 1.
		// Ако стойността на missiles е 0 – не прави нищо.
		void FireAMissile()
		{
			if(missiles > 0)
			{
				Console.Write("Изстреляна е ракета! ");
				missiles--;
			}
		}
		// void FireCannon() – изписва "Стрелба с автоматично оръдие!"
		void FireCannon()
		{
			Console.Write("Стрелба с автоматично оръдие! ");
		}
		// void CompleteTheMission() – симулира изпълнението на мисия, като:
		// - извежда съобщение с данните за самолета и мисията от типа "Изтребител planeId от ВВС на country на мисия mission";
		// - извиква метода LoadFuel() с параметър – случайно число между 30 и 50;
		// - извиква метода LoadMissiles();
		// - извиква метода StartTakeOff();
		// - организира симулация на огневи действия – N повторения на извикване на методите  FireAMissile() или
		// FireCannon(), като N е случайно число между 10 и 15 включително;
		// - извиква метода StartLanding();
		// - изписва "Мисията е изпълнена! Полетът приключи!".
		public void CompleteTheMission()// – симулира изпълнението на мисия, като:
		{
			Console.WriteLine("Изтребител {0} от ВВС на {1} на мисия {2}", planeId, country, mission);
			Random r = new Random();
			LoadFuel(r.Next(30, 51));
			LoadMissiles();
			StartTakeOff();
			Console.WriteLine();
			int n = r.Next(10, 16);
			for (int i = 0; i < n; i++) {
				if(r.Next()%3 == 0) FireAMissile();
				else FireCannon();
			}
			Console.WriteLine();
			Console.WriteLine();
			StartLanding();
			Console.WriteLine("Мисията е изпълнена! Полетът приключи!");
		}
	}
}
