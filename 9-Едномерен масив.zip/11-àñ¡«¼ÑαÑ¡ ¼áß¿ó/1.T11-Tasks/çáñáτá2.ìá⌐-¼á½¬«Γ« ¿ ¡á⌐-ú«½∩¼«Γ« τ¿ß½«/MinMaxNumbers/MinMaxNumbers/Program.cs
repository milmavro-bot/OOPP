﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 1.11.2020 г.
 * Time: 11:16
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MinMaxNumbers
{
	class MinMaxNum
	{
		int num, minNum, maxNum;
		
		// Конструктор
		public MinMaxNum(int n)
		{
			num = n;
			CalcMinMax();
		}
		
		// Метод void CalcMinMax() – намира най-малкото и най-голямото число,
		// които могат да се образуват при разместване на цифрите на числото,
		// записано в полето num.
		// Намерените числа се записват в полетата minNum(за най-малкото)
		// и maxNum(за най-голямото).
		void CalcMinMax()
		{
			// Създава целочислен масив с толкова елементи, колкото са цифрите на num.
			int[] c = new int[num.ToString().Length];
			
			// Чрез извличане на цифрите на num се запълва този масив със стойности
			// (във всеки негов елемент се записва цифра).
			int nn = num;
			for (int i = 0; i < c.Length; i++) 
			{
				c[i] = nn % 10;
				nn /= 10;
			}
			
			// Масивът се сортира.
			Array.Sort(c);
			
			// Образува се числото,
			// което се получава при последователно „прочитане“ на елементите на масива – това е минималното число.
			// Записва се в minNum.
			minNum = 0;
			for (int i = 0; i < c.Length; i++) {
				minNum = minNum * 10 + c[i];
			}
			
			// Масивът се пренарежда огледално.
			Array.Reverse(c);
			
			// Образува се числото,
			// което се получава при последователно „прочитане“ на елементите на масива – това е максималното число.
			// Записва се в maxNum.
			maxNum = 0;
			for (int i = 0; i < c.Length; i++) {
				maxNum = maxNum * 10 + c[i];
			}
		}
		
		// Метод void PrintNumbers() – извежда на екрана съобщение за най-малкото и най-голямото число,
		// образувани от цифрите на num.
		public void PrintNumbers()
		{
			Console.WriteLine("От цифрите на числото {0} могат да се образуват:", num);
			Console.WriteLine("Най-малко число: {0} и най-голямо число: {1}", minNum, maxNum);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Въведете естествено число: ");
			int n = int.Parse(Console.ReadLine());
			
			MinMaxNum m = new MinMaxNum(n);
			m.PrintNumbers();
			
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}