﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 7.11.2020 г.
 * Time: 13:24
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FirstSmallerThanLast
{
	class FirstSmaller
	{
		int[] a;	// масив от 10 цели числа
		
		// Конструктор
		public FirstSmaller()
		{
			a = new int[10];
			Read();
		}
		
		// Извършва запълването на масива със стойности
		// като организира въвеждане от клавиатурата
		void Read()
		{
			Console.WriteLine("Въведете последователно цели положителни числа, като след всяко натискате Enter!");
			for(int i = 0; i < 10; i++)
			{
				Console.Write("Въведете " + (i + 1) + ". число: ");
				a[i] = int.Parse(Console.ReadLine());
			}
			Console.WriteLine(new String('-', 80));
		}
		
		// Намира и отпечатва първия срещнат елемент, който е по-малък от последния.
		// Извежда подходящо съобщение, ако не намери такъв
		public void ShowFirstSmaller()
		{
			int i = 0;
			for(i = 0; a[i] >= a[9]; i++);
			if(i == 9) { Console.WriteLine("Не е намерено такова число!"); }
			else { Console.WriteLine("Намереното число е " + a[i]); }
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			FirstSmaller fs = new FirstSmaller();
			fs.ShowFirstSmaller();
			
			Console.ReadKey(true);
		}
	}
}