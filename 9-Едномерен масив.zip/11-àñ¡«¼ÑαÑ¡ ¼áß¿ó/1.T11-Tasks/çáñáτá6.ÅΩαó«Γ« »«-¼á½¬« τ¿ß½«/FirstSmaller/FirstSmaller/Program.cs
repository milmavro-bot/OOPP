﻿using System;

namespace FirstSmaller
{
	class FirstSmaller
	{
		int[] a;
		public FirstSmaller()
		{
			a = new int[10];
			Read();
		}
		void Read()
		{
			Console.WriteLine("Въведете последователно цели положителни числа:");
			for(int i = 0; i < a.Length; i++)
			{
				Console.Write("Въведете " + (i + 1) + ". число: ");
				a[i] = int.Parse(Console.ReadLine());
			}
		}
		public void ShowFirstSmaller()
		{
			Console.WriteLine(new String('-', 50));
			for(int i = 0; i < a.Length - 1; i++)
			{
				if(a[i] < a[a.Length - 1])
				{
					Console.WriteLine("Намереното число е " + a[i]);
					return;
				}
			}
			Console.WriteLine("Не е намерено такова число!");
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			FirstSmaller first = new FirstSmaller();
			first.ShowFirstSmaller();
			
			Console.ReadKey(true);
		}
	}
}