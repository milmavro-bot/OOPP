﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 12.11.2020 г.
 * Time: 9:48
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace FirstSmallers1
{
	class FirstSmaller
	{
		int[] a;
		
		public FirstSmaller()
		{
			a = new int[10];
			Read();
		}
		
		void Read()
		{
			Console.WriteLine("Въведете последователно цели положителни числа:");
			for(int i = 0; i < a.Length; i++)
			{
				Console.Write("Въведете " + (i + 1) + " .число: ");
				a[i] = int.Parse(Console.ReadLine());
			}
		}
		
		public void ShowFirstSmaller()
		{
			Console.WriteLine(new String('-', 50));
			
			// Solution 1
			/*for(int i = 0; i < a.Length - 1; i++)
			{
				if(a[i] < a[a.Length - 1])
				{
					Console.WriteLine("Намереното число е " + a[i]);
					return;
				}
			}
			Console.WriteLine("Не е намерено такова число!");*/
			
			// Solution 2
			/*int m = 0;
			bool isFound = false;
			for(int i = 0; i < a.Length - 1; i++)
			{
				if(a[i] < a[9])
				{
					m = a[i];
					isFound = true;
					Console.WriteLine("Намереното число е {0}", a[i]);
					break;
				}
			}
			if(!isFound)
			{
				Console.WriteLine("Не е намерено такова число!");
			}*/
			
			// Solution 3
			int i = 0;
			for(i = 0; a[i] >= a[9]; i++);
			if(i == 9) { Console.WriteLine("Не е намерено такова число!"); }
			else { Console.WriteLine("Намереното число е {0}", a[i]);}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			FirstSmaller first = new FirstSmaller();
			first.ShowFirstSmaller();
			
			Console.ReadKey(true);
		}
	}
}