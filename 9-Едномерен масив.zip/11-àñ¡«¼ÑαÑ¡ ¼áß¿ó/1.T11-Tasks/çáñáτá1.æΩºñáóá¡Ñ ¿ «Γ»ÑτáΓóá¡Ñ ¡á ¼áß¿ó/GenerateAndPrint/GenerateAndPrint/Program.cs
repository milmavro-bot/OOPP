﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 1.11.2020 г.
 * Time: 7:36
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace GenerateAndPrint
{
	class GPArr
	{
		int[] arr;	// масив от 10 целочислени стойности
		
		// Конструктор
		public GPArr()
		{
			arr = new int[10];
			Fill();
		}
		
		// Метод void Fill() – извършва запълването на масива със стойности,
		// като организира въвеждане от клавиатурата.
		void Fill()
		{
			Console.WriteLine("Въведете последователно 10 цели числа, като след всяко натискате Enter!");
			for(int i = 0; i < arr.Length; i++)
			{
				Console.Write("Въведете " + (i + 1) + ". число: ");
				arr[i] = int.Parse(Console.ReadLine());
			}
		}
		
		// Метод void PrintArray(string delim) – извежда на екрана числата от масива на един ред,
		// като между всеки две числа се извежда като разделител съдържанието на параметъра delim.
		// След последното число не се извежда разделител,
		// а се преминава на нов ред.
		public void PrintArray(string delim)
		{
			string s = string.Join(delim, arr);
			Console.WriteLine("Съдържание на масива:");
			Console.WriteLine(s);
		}
		
		// Метод void CheckSymm() – проверява дали масивът е симетричен
		// (първият и последният елементи са равни, вторият и предпоследният също са равни и т.н.).
		// Извежда на екрана съответното съобщение.
		public void CheckSymm()
		{
			bool sym = true;
			for(int i = 0; i < arr.Length; i++)
			{
				if(arr[i] != arr[arr.Length - 1 - i]) { sym = false; }
			}
			if(sym)
			{
				Console.WriteLine("Този масив е симетричен!");
			}
			else
			{
				Console.WriteLine("Този масив не е симетричен!");
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			GPArr gp = new GPArr();
			string d = "//";
			gp.PrintArray(d);
			gp.CheckSymm();
			
			Console.ReadKey(true);
		}
	}
}