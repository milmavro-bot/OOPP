﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 9.11.2020 г.
 * Time: 10:06
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace GenerateAndPrintArray
{
	class GPArr
	{
		int[] arr;
		
		public GPArr()
		{
			arr = new int[10];
			Fill();
		}
		
		void Fill()
		{
			Console.WriteLine("Въведете 10 жели числа:");
			for(int i = 0; i < arr.Length; i++)
			{
				Console.Write("Въведете " + (i + 1) + " .число: ");
				arr[i] = int.Parse(Console.ReadLine());
			}
		}
		
		public void PrintArray(string delim)
		{
			string s = string.Join(delim, arr);
			Console.WriteLine("Съдържание на масива:");
			Console.WriteLine(s);
		}
		
		public void CheckSymm()
		{
			bool sym = true;
			for(int i = 0; i < arr.Length; i++)
			{
				if(arr[i] != arr[arr.Length - 1 - i]) { sym = false; break;}
			}
			if(sym)
			{
				Console.WriteLine("Този масив е симетричен.");
			}
			else
			{
				Console.WriteLine("Този масив не е симетричен.");
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			GPArr gp = new GPArr();
			string d = ", ";
			gp.PrintArray(d);
			gp.CheckSymm();
			
			Console.ReadKey(true);
		}
	}
}