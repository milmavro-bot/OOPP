﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 7.11.2020 г.
 * Time: 9:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EvenOddNumbers
{
	class EvenOdd
	{
		double[] a;	// масив от реални числа със n > 1 елемента
		
		// Конструктор
		public EvenOdd(int n)
		{
			a = new double[n];
			Read();
		}
		
		// Извършва запълването на масива със стойности
		// като организира въвеждане от клавиатурата
		void Read()
		{
			Console.WriteLine("Въведете последователно реални числа, като след всяко натискате Enter!");
			for(int i = 0; i < a.Length; i++)
			{
				Console.Write("Въведете " + (i + 1) + ". число: ");
				a[i] = double.Parse(Console.ReadLine());
			}
		}
		// Намира елементите на масива с четни позиции
		void FindEven()
		{
			for(int i = 1; i < a.Length; i += 2)
			{
				Console.Write(a[i] + "  ");
			}
		}
		// Намиране елементите на масива с нечетни позиции
		void FindOdd()
		{
			for(int i = 0; i < a.Length; i += 2)
			{
				Console.Write(a[i] + "  ");
			}
		}
		
		// Извежда на екрана числата от масива на един ред,
		// като между всеки две числа се извежда като разделител два интервала.
		public void Print()
		{
			Console.WriteLine(new String('-', 70));
			FindEven();
			FindOdd();
			Console.WriteLine();
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			//EvenOdd eo = new EvenOdd(7);
			EvenOdd eo = new EvenOdd(int.Parse(Console.ReadLine()));
			eo.Print();
			
			Console.ReadKey(true);
		}
	}
}