﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 1.11.2020 г.
 * Time: 10:17
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace redica
{
	class Sequence
	{
		int[] a;	// масив от 10 целочислени стойности
		
		// Конструктор
		public Sequence()
		{
			a = new int[12];
			Read();
		}
		
		// Извършва запълването на масива със стойности,
		// като организира въвеждане от клавиатурата
		void Read()
		{
			Console.WriteLine("Въведете последователно 12 цели числа, като след всяко натискате Enter!");
			for(int i = 0; i < a.Length; i++)
			{
				Console.Write("Въведете " + (i + 1) + ". число: ");
				a[i] = int.Parse(Console.ReadLine());
			}
		}
		
		// Пресмята и връща броя на нечетните числа
		int CountOdd()
		{
			int odd = 0;
			for(int i = 0; i < a.Length; i++)
			{
				if(a[i] % 2 != 0) { odd++; }
			}
			return odd;
		}
		
		// Намира и връща като резултат индекса на първото четно число в масива
		int FirstEven()
		{
			for(int i = 0; i < a.Length; i++)
			{
				if(a[i] % 2 == 0) { return i; }
			}
			return -1;
		}
		
		// Извежда всички нечетни елементи на масива с разстояние
		// два интервала между всяко число,
		// ако броят на нечетните числа съвпада с индекса на
		// първото четно число или текста
		// „Броят на нечетните числа в редицата НЕ СЪВПАДА с индекса на първото четно число.“ – в противен случай.
		// Да се използват описаните по-горе методи CountOdd() и FirstEven().		
		void ShowOdd()
		{
			if(FirstEven() == CountOdd())
			{
				Console.WriteLine("Нечетни числа в редицата:");
				for(int i = 0; i < a.Length; i++)
				{
					if(a[i] % 2 != 0) { Console.Write(a[i] + "  "); }
				}
				Console.WriteLine();
			}
			else
			{
				Console.WriteLine("Броят на нечетните числа в редицата НЕ СЪВПАДА с индекса на първото четно число.");
			}
		}
		
		// Организира отпечатване на елементите от масива (два интервала като разделител)
		// и резултатите от работата на горните методи на екрана.
		public void PrintArray()
		{
			string s = string.Join("  ", a);
			Console.WriteLine(new String('-', 45));
			Console.WriteLine("Съдържание на редицата:");
			Console.WriteLine(s);
			Console.WriteLine(new String('-', 45));
			Console.WriteLine("Брой на нечетните числа в редицата: {0}", CountOdd());
			Console.WriteLine("Индекс на първото четно число в редицата: {0}", FirstEven());
			ShowOdd();
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Sequence sq = new Sequence();
			sq.PrintArray();
			
			Console.ReadKey(true);
		}
	}
}