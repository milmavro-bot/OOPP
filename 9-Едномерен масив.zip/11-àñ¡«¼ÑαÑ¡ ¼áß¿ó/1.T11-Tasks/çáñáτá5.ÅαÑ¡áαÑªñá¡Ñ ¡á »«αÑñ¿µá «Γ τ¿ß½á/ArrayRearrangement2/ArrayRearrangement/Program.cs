﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 7.11.2020 г.
 * Time: 11:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace ArrayRearrangement
{
	class ArrRearrangement
	{
		double[] a;	// масив от n > 1 реални числа
		
		// Конструктор
		public ArrRearrangement(int n)
		{
			a = new double[n];
			Read();
		}
		
		// Извършва запълването на масива със стойности
		// като организира въвеждане от клавиатурата
		void Read()
		{
			Console.WriteLine("Въведете последователно реални числа, като след всяко натискате Enter!");
			for(int i = 0; i < a.Length; i++)
			{
				Console.Write("Въведете " + (i + 1) + ". число: ");
				a[i] = double.Parse(Console.ReadLine());
			}
			Console.WriteLine(new String('-', 70));
		}
		// Пренареждане и отпечатване на масива
		public void ShowArray()
		{
			for(int i = 0; i < a.Length / 2; i++)
			{
				Console.Write(a[i] + "  ");
				Console.Write(a[a.Length - i - 1] + "  ");
			}
			if(a.Length % 2 != 0) { Console.Write(a[(a.Length / 2)]); }
			Console.WriteLine();
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			//ArrRearrangement ar = new ArrRearrangement(8);
			ArrRearrangement ar = new ArrRearrangement(int.Parse(Console.ReadLine()));
			ar.ShowArray();
			
			Console.ReadKey(true);
		}
	}
}