﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contest
{
    class ContestScores
    {
        int[] scores;
        public ContestScores(int n)
        {
            scores = new int[n];
            this.GetScores();
        }
        void GetScores()
        {
            Random rnd = new Random();
            for(int i=0; i<scores.Length; i++)
            {
                scores[i] = rnd.Next(1, 61);
            }
        }
        double GetAverageScore()
        {
            int sum = 0;
            foreach(int score in scores)
            {
                sum += score;
            }
            return (double)sum / (double)scores.Length;
        }
        int NumberOfScoresAbove(double d)
        {
            int number = 0;
            foreach(int score in scores)
            {
                if (score > d) number++;
            }
            return number;
        }
        int GetMaxScore()
        {
            int maxscore= -1;
            foreach(int score in scores)
            {
                if (score > maxscore) maxscore = score;
            }
            return maxscore;
        }
        public void PrintscoreInfo()
        {
            Console.WriteLine("Списък с резултати:");
            foreach(int score in scores)
            {
                Console.Write("{0} ", score);
            }
            Console.WriteLine();
            Console.WriteLine("Най-висок резултат: {0}",GetMaxScore());
            Console.WriteLine("Брой златни медали: {0}", NumberOfScoresAbove((double)GetMaxScore() * (double)9 / (double)10));
            Console.WriteLine("Среден резултат: {0}", GetAverageScore());
            Console.WriteLine("Брой резултати над средния: {0}", NumberOfScoresAbove(GetAverageScore()));
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Въведете броя на резултатите: ");
            ContestScores c1 = new ContestScores(Int32.Parse(Console.ReadLine()));
            c1.PrintscoreInfo();
            Console.ReadKey(true);
        }
    }
}
