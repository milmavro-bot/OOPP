﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.01.2021 г.
 * Time: 19:47
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Shapes
{
	/// <summary>
	/// Description of Shape.
	/// </summary>
	public class Shape
	{
		string type;
		protected Shape(string t)
		{
			type = t;
		}
		
		public virtual void Describe() 
		{
			Console.WriteLine("Тази фигура е {0}", type);
		}
		
		public virtual void CalcAndPrintPerimeter() 
		{
			Console.WriteLine("Няма обща формула за обиколка :(");
		}
		
		public virtual void CalcAndPrintArea() 
		{
			Console.WriteLine("Няма обща формула за лице :(");
		}
	}
}
