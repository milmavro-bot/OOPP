﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.01.2021 г.
 * Time: 19:55
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Shapes
{
	/// <summary>
	/// Description of Rectangle.
	/// </summary>
	public class Rectangle :Shape
	{
		double sideA, sideB;
		public Rectangle(double sA, double sB) : base("правоъгълник")
		{
			sideA = sA;
			sideB = sB;
		}
		
		public override void Describe()
		{
			base.Describe();
			Console.WriteLine("Страните на правоъгълника са {0} и {1}", sideA, sideB);
		}
		
		public override void CalcAndPrintPerimeter()
		{
			Console.WriteLine("Формулата за обиколка на правоъгълник е Р = 2 .( а + b )");
			Console.WriteLine("За този правоъгълник Р = 2 . ( {0} + {1} ) = {2}", sideA, sideB, 2*sideA + 2*sideB);
		}
		
		public override void CalcAndPrintArea()
		{
			Console.WriteLine("Формулата за лице на правоъгълник е S = a . b");
			Console.WriteLine("За този правоъгълник S = {0} . {1} = {2}", sideA,sideB, sideA*sideB);
		}
	}
}
