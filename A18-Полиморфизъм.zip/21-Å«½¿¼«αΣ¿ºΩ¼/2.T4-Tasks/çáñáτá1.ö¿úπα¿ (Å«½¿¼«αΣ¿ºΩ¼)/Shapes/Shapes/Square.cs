﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.01.2021 г.
 * Time: 19:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Shapes
{
	/// <summary>
	/// Description of Square.
	/// </summary>
	public class Square : Shape
	{
		double side;
		public Square(double s) : base("квадрат")
		{
			side = s;
		}
		
		public override void Describe()
		{
			base.Describe();
			Console.WriteLine("Страната на квадрата е {0}", side);
		}
		
		public override void CalcAndPrintPerimeter()
		{
			Console.WriteLine("Формулата за обиколка на квадрат е Р = 4 . а");
			Console.WriteLine("За този квадрат Р = 4 . {0} = {1}", side, 4*side);
		}
		
		public override void CalcAndPrintArea()
		{
			Console.WriteLine("Формулата за лице на квадрат е S = a . а");
			Console.WriteLine("За този квадрат S = {0} . {0} = {1}", side, side*side);
		}		
	}
}
