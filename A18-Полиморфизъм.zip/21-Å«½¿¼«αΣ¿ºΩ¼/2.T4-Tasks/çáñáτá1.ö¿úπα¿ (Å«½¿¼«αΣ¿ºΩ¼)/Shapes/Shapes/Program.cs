﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.01.2021 г.
 * Time: 19:47
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
namespace Shapes
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.Unicode;
			List <Shape> shapes = new List<Shape> {new Square(3), new Rectangle(4, 5.5), new Circle(4), new Square(1.5), new Rectangle(2, 3), new Circle(10)};
			
			foreach(Shape s in shapes)
			{
				s.Describe();
				s.CalcAndPrintPerimeter();
				s.CalcAndPrintArea();
				Console.WriteLine();
			}
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}