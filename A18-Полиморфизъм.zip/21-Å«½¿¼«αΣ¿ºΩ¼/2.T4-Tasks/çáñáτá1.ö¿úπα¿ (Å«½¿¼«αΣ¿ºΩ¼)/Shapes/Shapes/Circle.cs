﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 17.01.2021 г.
 * Time: 19:59
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Shapes
{
	/// <summary>
	/// Description of Circle.
	/// </summary>
	public class Circle : Shape
	{
		double radius;
		public Circle(double s) : base("окръжност")
		{
			radius = s;
		}
		
		public override void Describe()
		{
			base.Describe();
			Console.WriteLine("Радиусът на окръжността е {0}", radius);
		}
		
		public override void CalcAndPrintPerimeter()
		{
			Console.WriteLine("Формулата за дължина на окръжност е C = 2.{0}.r", '\u03c0');
			Console.WriteLine("За тази окръжност C = 2.{0}.{1} = {2}", '\u03c0',radius, 2*Math.PI*radius);
		}
		
		public override void CalcAndPrintArea()
		{
			Console.WriteLine("Формулата за лице на кръг е S = {0}.r.r", '\u03c0');
			Console.WriteLine("За този кръг S = {0}.{1}.{1} = {2}", '\u03c0',radius, Math.PI*radius*radius);
		}
	}
}
