﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.1.2021 г.
 * Time: 8:40
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace hotel
{
	public class SingleRoom : Room
	{
		public SingleRoom(DateTime dateOfAccommodation, DateTime dateOfDeparture)
			: base(dateOfAccommodation, dateOfDeparture)
		{
		}
		public override void Info()
		{
			Console.WriteLine("Единична стая");
			base.Info();
			Console.WriteLine("Крайна цена: {0:0.00} лева", CalcPrice());
		}
	}
}
