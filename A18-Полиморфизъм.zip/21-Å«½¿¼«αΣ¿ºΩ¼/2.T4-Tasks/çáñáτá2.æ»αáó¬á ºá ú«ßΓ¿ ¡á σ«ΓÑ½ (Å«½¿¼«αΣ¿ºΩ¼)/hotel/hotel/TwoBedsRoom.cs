﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 18.1.2021 г.
 * Time: 11:29
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace hotel
{
	public class TwoBedsRoom : Room
	{
		public TwoBedsRoom(DateTime dateOfAccommodation, DateTime dateOfDeparture)
			: base(dateOfAccommodation, dateOfDeparture)
		{
		}
		public override double CalcPrice()
		{
			const int BEDS = 2;
			return base.CalcPrice() * BEDS;
		}
		public override void Info()
		{
			Console.WriteLine("Стая с две легла");
			base.Info();
			Console.WriteLine("Крайна цена: {0:0.00} лева", CalcPrice());
		}
	}
}
