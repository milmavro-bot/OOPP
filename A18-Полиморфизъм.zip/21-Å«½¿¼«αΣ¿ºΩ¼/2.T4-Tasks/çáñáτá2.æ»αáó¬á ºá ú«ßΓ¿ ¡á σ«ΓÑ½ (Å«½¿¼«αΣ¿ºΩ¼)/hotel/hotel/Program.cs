﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 12.1.2021 г.
 * Time: 12:40
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace hotel
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.Unicode;
			/*SingleRoom sr = new SingleRoom(new DateTime(2021, 1, 5), new DateTime(2021, 1, 10));
			sr.Info();
			Apartment ap = new Apartment(new DateTime(2021, 1, 10), new DateTime(2021, 1, 18), false);
			ap.Info();*/
			
			List<Room> rooms = new List<Room>()
			{
				new SingleRoom(new DateTime(2020, 6, 20), new DateTime(2020, 6, 25)),
				new TwoBedsRoom(new DateTime(2020, 6, 20), new DateTime(2020, 6, 28)),
				new ThreeBedsRoom(new DateTime(2020, 6, 20), new DateTime(2020, 6, 23)),
				new Apartment(new DateTime(2020, 6, 21), new DateTime(2020, 6, 28), true),
				new SingleRoom(new DateTime(2020, 6, 21), new DateTime(2020, 6, 25)),
				new TwoBedsRoom(new DateTime(2020, 6, 22), new DateTime(2020, 6, 30)),
				new ThreeBedsRoom(new DateTime(2020, 6, 22), new DateTime(2020, 6, 25)),
				new Apartment(new DateTime(2020, 6, 23), new DateTime(2020, 7, 2), false)
			};
			foreach(Room r in rooms)
			{
				r.Info();
				Console.WriteLine();
			}
			
			Console.Write(". . . ");
			Console.ReadKey(true);
		}
	}
}