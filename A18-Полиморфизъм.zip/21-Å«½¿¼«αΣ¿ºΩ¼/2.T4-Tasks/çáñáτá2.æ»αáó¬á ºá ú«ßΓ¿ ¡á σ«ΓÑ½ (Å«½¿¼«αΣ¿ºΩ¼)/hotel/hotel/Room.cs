﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.1.2021 г.
 * Time: 7:13
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace hotel
{
	public class Room
	{
		DateTime dateOfAccommodation;
		DateTime dateOfDeparture;
		
		public Room(DateTime dtOfAcc, DateTime dtOfDep)
		{
			dateOfAccommodation = dtOfAcc;
			dateOfDeparture = dtOfDep;
		}
		private int NumberOfNights()
		{
			return (dateOfDeparture.Date - dateOfAccommodation.Date).Days;
		}
		public virtual double CalcPrice()
		{
			double p = 0;
			if(NumberOfNights() >= 1 && NumberOfNights() <= 3)
			{
				p = 20.0;
			}
			else if(NumberOfNights() > 3 && NumberOfNights() <= 9)
			{
				p = 18.0;
			}
			else if(NumberOfNights() > 9)
			{
				p = 16.0;
			}
			return p * NumberOfNights();
		}
		public virtual void Info()
		{
			Console.WriteLine("Дата на настаняване: {0:d}", dateOfAccommodation);
			Console.WriteLine("Дата на заминаване: {0:d}", dateOfDeparture);
			Console.WriteLine("Брой нощувки: {0}", NumberOfNights());
		}
	}
}
