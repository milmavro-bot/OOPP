﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 13.1.2021 г.
 * Time: 9:36
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace hotel
{
	public class Apartment : Room
	{
		bool isFB;
		public Apartment(DateTime dateOfAccommodation, DateTime dateOfDeparture, bool fb)
			: base(dateOfAccommodation, dateOfDeparture)
		{
			isFB = fb;
		}
		public override double CalcPrice()
		{
			const int BEDS = 4;
			const double PRICE_FB = 22.0;
			if(isFB)
			{
				return (base.CalcPrice() * BEDS) + PRICE_FB;
			}
			return base.CalcPrice() * BEDS;
		}
		string FullBoard()
		{
			if(isFB) return "Да";
			return "Не";
		}
		public override void Info()
		{
			Console.WriteLine("Апартамент");
			Console.WriteLine("Пълен пансион: {0}", FullBoard());
			base.Info();
			Console.WriteLine("Крайна цена: {0:0.00} лева", CalcPrice());
		}
	}
}
