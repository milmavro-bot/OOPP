﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 13.01.2021 г.
 * Time: 12:31
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace OverrideDemo
{
	/// <summary>
	/// Description of Dog.
	/// </summary>
	public class Dog : Animal //Derived class
	{
	    public Dog()
	    {
	        commonName = "Куче";
	    }
	    public sealed override void MakeSound() 
	    {
	        Console.WriteLine("Кучето лае!");
	    }
		public override string ToString()
		{
			return "Tова животно е " + commonName + " - обект от клас Dog.";
		}
	}
}
