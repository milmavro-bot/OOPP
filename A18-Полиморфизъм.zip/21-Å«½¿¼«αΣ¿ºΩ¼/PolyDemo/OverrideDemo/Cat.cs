﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 13.01.2021 г.
 * Time: 12:32
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace OverrideDemo
{
	/// <summary>
	/// Description of Cat.
	/// </summary>
	public class Cat : Animal //Derived class
	{
	    public Cat()
	    {
	        commonName = "Котка";
	    }
	    public override void MakeSound() 
	    {
	        Console.WriteLine("Котката мяука!");
	    }
	    
	    public override string ToString()
		{
			return "Tова животно е " + commonName + " - обект от клас Cat.";
		}
	}
}
