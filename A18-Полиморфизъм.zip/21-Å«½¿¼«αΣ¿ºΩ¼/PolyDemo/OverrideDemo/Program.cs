﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 1.1.2021 г.
 * Time: 17:56
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
namespace OverrideDemo
{
	class Program
	{
		public static void Main(string[] args)
		{
			List <Animal> animals = new List<Animal>(){new Animal(), new Dog(), new Cow(), new Cat(), new Snake()};
			foreach (Animal an in animals)
			{
				Console.WriteLine(an);
				an.MakeSound();
				Console.WriteLine();
			}
			Console.ReadKey(true);
		}
	}
}