﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 13.01.2021 г.
 * Time: 12:31
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace OverrideDemo
{
	/// <summary>
	/// Description of Animal.
	/// </summary>
	public class Animal //Base class
	{
		protected string commonName;
		

	    public virtual void MakeSound() 
	    {
	        Console.WriteLine("Животното издава звук!");
	    }
	    
		public override string ToString()
		{
			return string.Format("Това е просто животно - обект от клас Animal");
		}

	}
}
