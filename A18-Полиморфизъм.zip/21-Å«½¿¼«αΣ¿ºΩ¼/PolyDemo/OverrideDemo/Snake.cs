﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 13.01.2021 г.
 * Time: 12:33
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace OverrideDemo
{
	/// <summary>
	/// Description of Snake.
	/// </summary>
	
	public class Snake : Animal
	{
		public Snake()
		{
			commonName = "Змия";
		}
		public override void MakeSound()
		{
			Console.WriteLine( "Змията е животно, но мълчаливо!");
		}
		
		public override string ToString()
		{
			return "Tова животно е " + commonName + " - обект от клас Snake.";
		}
	}

}
