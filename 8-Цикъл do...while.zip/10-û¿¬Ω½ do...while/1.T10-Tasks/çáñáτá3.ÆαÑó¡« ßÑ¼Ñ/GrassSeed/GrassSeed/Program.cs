﻿using System;

namespace GrassSeed
{
    class Price
    {
        double c, w, l;

        // Конструктор
        public Price(double cost) { c = cost; }

        // Изчислява разходите за засяване на всички тревни площи
        double TotalCost()
        {
            int i = 0;
            double totalArea = 0;
            do
            {
                i++;
                Console.Write("Enter w" + i + ": ");
                w = double.Parse(Console.ReadLine());
                Console.Write("Enter l" + i + ": ");
                l = double.Parse(Console.ReadLine());
                totalArea += l * w;
            }
            while (w != 0 && l != 0);
            return totalArea * c;
        }

        // Отпечатване на резултата
        public void Print()
        {
            Console.WriteLine("The cost to sow all of the lawns: " + TotalCost());
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the cost of seed to sow one square metre of lawn: ");
            double cost = double.Parse(Console.ReadLine());
            Price price = new Price(cost);
            price.Print();
            Console.ReadKey(true);
        }
    }
}
