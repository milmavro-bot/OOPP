﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 28.10.2020 г.
 * Time: 8:15
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace money
{
	class Banknotes
	{
		int total;		// общата стойност на парите в машината
		int billsOf5;	// брой на банкнотите от 5 лева
		int billsOf10;	// брой на банкнотите от 10 лева
		int billsOf20;	// брой на банкнотите от 20 лева
		
		// Конструктор
		public Banknotes()
		{
			SortAndCount();
		}
		
		// Метод void SortAndCount() – извършва сортирането и броенето на банкнотите
		// като организира въвеждане на поредица от числа от клавиатурата (0 е сигнал за край).
		// Всяко число е 5, 10 или 20 – стойността на поредната банкнота.
		// След края на въвеждането методът записва в полето total общата стойност на всички банкноти,
		// а в полетата  billsOf5, billsOf10 и billsOf5 – броя на банкнотите от съответния номинал.
		
		// За тестовете ще бъдат въвеждани само валидни числови стойности (5, 10, 20 или 0).
		void SortAndCount()
		{
			int bills = 0, i5 = 0, i10 = 0, i20 = 0;
			do
			{
				Console.Write("Въведете стойността на поредната банкнота - 5, 10, 20 или 0 за край: ");
				bills = int.Parse(Console.ReadLine());
				if(bills == 5) { i5++; }
				if(bills == 10) { i10++; }
				if(bills == 20) { i20++; }
			}while(bills != 0);
			int br = i5 + i10 + i20;
			total = (i5 * 5) + (i10 * 10) + (i20 * 20);
			Console.WriteLine("Справка за наличността");
			if((i5 >= i10) && (i5 >= i20))
			{
				billsOf5 = i5;
				if(i10 >= i20)
				{
					billsOf10 = i10;
					billsOf20 = i20;
					Console.WriteLine("Банкноти от 5 лева: {0} броя", billsOf5);
					Console.WriteLine("Банкноти от 10 лева: {0} броя", billsOf10);
					Console.WriteLine("Банкноти от 20 лева: {0} броя", billsOf20);
				}
				else
				{
					billsOf10 = i10;
					billsOf20 = i20;
					Console.WriteLine("Банкноти от 5 лева: {0} броя", billsOf5);
					Console.WriteLine("Банкноти от 20 лева: {0} броя", billsOf20);
					Console.WriteLine("Банкноти от 10 лева: {0} броя", billsOf10);
				}
			}
			else if((i10 >= i5) && (i10 >= i20))
			{
				billsOf10 = i10;
				if(i5 >= i20)
				{
					billsOf5 = i5;
					billsOf20 = i20;
					Console.WriteLine("Банкноти от 10 лева: {0} броя", billsOf10);
					Console.WriteLine("Банкноти от 5 лева: {0} броя", billsOf5);
					Console.WriteLine("Банкноти от 20 лева: {0} броя", billsOf20);
				}
				else
				{
					billsOf5 = i5;
					billsOf20 = i20;
					Console.WriteLine("Банкноти от 10 лева: {0} броя", billsOf10);
					Console.WriteLine("Банкноти от 20 лева: {0} броя", billsOf20);
					Console.WriteLine("Банкноти от 5 лева: {0} броя", billsOf5);
				}
			}
			else
			{
				billsOf20 = i20;
				if(i10 >= i5)
				{
					billsOf10 = i10;
					billsOf5 = i5;
					Console.WriteLine("Банкноти от 20 лева: {0} броя", billsOf20);
					Console.WriteLine("Банкноти от 10 лева: {0} броя", billsOf10);
					Console.WriteLine("Банкноти от 5 лева: {0} броя", billsOf5);
				}
				else
				{
					billsOf10 = i10;
					billsOf5 = i5;
					Console.WriteLine("Банкноти от 20 лева: {0} броя", billsOf20);
					Console.WriteLine("Банкноти от 5 лева: {0} броя", billsOf5);
					Console.WriteLine("Банкноти от 10 лева: {0} броя", billsOf10);
				}
			}
			
			Console.WriteLine("Общо: {0} банкноти на стойност {1} лева", br, total);
		}
		// Метод void Print() –извежда на екрана информация за
		// броя на банкнотите от всеки един вид,
		// за общия брой банкноти и за
		// общата стойност.
		public void Print()
		{
			SortAndCount();
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			// Създава обект от класа Banknotes
			Banknotes b = new Banknotes();
			
			// Извежда информация за данните,
			// записани в този обект,
			// чрез извикване на съответния метод.
			b.Print();
			
			Console.ReadKey(true);
		}
	}
}