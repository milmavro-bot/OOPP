﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 28.10.2020 г.
 * Time: 11:37
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MoneyMain
{
	class Program
	{
		public static void Main(string[] args)
		{
			int bills = 0, i5 = 0, i10 = 0, i20 = 0;
			do
			{
				Console.Write("Въведи стойността на поредната банкнота - 5, 10, 20 или 0 за край: ");
				bills = int.Parse(Console.ReadLine());
				if(bills == 5) { i5++; }
				if(bills == 10) { i10++; }
				if(bills == 20) { i20 ++; }
			}while(bills != 0);
			int br = i5 + i10 + i20;
			int total = (i5 * 5) + (i10 * 10) + (i20 * 20);
			Console.WriteLine("Справка за наличността");
			Console.WriteLine("Банкноти от 5 лева: {0}", i5);
			Console.WriteLine("Банкноти от 10 лева: {0}", i10);
			Console.WriteLine("Банкноти от 20 лева: {0}", i20);
			Console.WriteLine("Общ брой: {0}", br);
			Console.WriteLine("Обща сума: {0}", total);
			
			Console.ReadKey(true);
		}
	}
}