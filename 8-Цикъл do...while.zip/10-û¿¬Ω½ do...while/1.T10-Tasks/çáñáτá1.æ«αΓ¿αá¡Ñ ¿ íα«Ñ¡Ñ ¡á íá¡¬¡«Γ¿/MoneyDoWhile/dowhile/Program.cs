﻿/*
 * Created by SharpDevelop.
 * User: Mitko
 * Date: 11/4/2020
 * Time: 8:22 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace dowhile
{
	class Banknotes
	{
		public Banknotes()
		{
			SortCount();
		}
		int total, bill5, bill10, bill20, count;
		void SortCount()
		{
			int a;
			do
			{
				Console.Write("Въведи стойността на поредната банкнота - 5, 10, 20 или 0 за край: ");
				a=Convert.ToInt32(Console.ReadLine());
				total+=a;
				count++;
				switch(a)
				{
					case 5: bill5++; break;
					case 10: bill10++; break;
					case 20: bill20++; break;
					case 0: break;
				}
			}
			while(a!=0);
		}
		public void Print()
		{
			Console.WriteLine("Справка за наличността");
			Console.WriteLine("Банкноти от 5 лв.: {0}", bill5);
			Console.WriteLine("Банкноти от 10 лв.: {0}", bill10);
			Console.WriteLine("Банкноти от 20 лв.: {0}", bill20);
			Console.WriteLine("Общо: {0} банкноти на стойност {1}", count, total);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.Unicode;
			Console.InputEncoding = System.Text.Encoding.Unicode;
			Banknotes e1=new Banknotes();
			e1.Print();
			Console.ReadKey(true);
		}
	}
}