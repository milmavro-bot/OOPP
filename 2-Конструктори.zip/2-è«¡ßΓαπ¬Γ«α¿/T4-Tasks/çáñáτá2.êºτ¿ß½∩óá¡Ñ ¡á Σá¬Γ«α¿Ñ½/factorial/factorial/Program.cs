﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 26.9.2020 г.
 * Time: 13:49
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Numerics;

namespace factorial
{
	class Fact
	{
		int x;
		
		public Fact()
		{
			x = 3;
		}
		public Fact(int a)
		{
			x = a;
		}
		
		public void Value()
		{
			BigInteger f = 1;
			for(int i = 1; i <= x; i++)
			{
				f *= i;
			}
			Console.WriteLine(f);
		}
		public void PrintFact()
		{
			Console.Write(x + "! = ");
			Value();
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Fact f1 = new Fact();
			f1.PrintFact();
			
			Console.Write("Enter a number: ");
			int n = int.Parse(Console.ReadLine());
			Fact f2 = new Fact(n);
			f2.PrintFact();
			
			Console.ReadKey(true);
		}
	}
}