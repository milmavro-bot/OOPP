﻿/*
 * Created by SharpDevelop.
 * User: mega
 * Date: 9/30/2020
 * Time: 12:39 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace BGLake
{
	class BGLake
	{
		string name;
		int area;
		double depth;
		public BGLake()
		{
			Console.WriteLine("Creating a lake object!");
			Console.Write("What's the name of this lake? ");
			name = Console.ReadLine();
			Console.Write("How big is the lake? ( sq. mt ) ");
			area = int.Parse(Console.ReadLine());
			Console.Write("How deep is this lake? ");
			depth = double.Parse(Console.ReadLine());
			Console.WriteLine("------End of constructor------");
		}
		public BGLake(string nm, int ar, double dp)
		{
			name = nm;
			area = ar;
			depth = dp;
			Console.WriteLine("Creating a lake object!");
			Console.WriteLine("------End of constructor------");
		}
		public void EditArea(int newArea)
		{
			Console.WriteLine("Lake " + name + " area edited. Old value: " +
			                  area + " New value: " + newArea);
			area = newArea;
		}
		public void EditName(string newName)
		{
			Console.WriteLine("Lake " + name + " name edited. Old value: "
			                  + name + " New value: " + newName);
			name = newName;
		}
		public void Print()
		{
			Console.WriteLine("Lake: " + name);
			Console.WriteLine("Area: " + area);
			Console.WriteLine("Depth: " + depth);
			Console.WriteLine();
		}
		public void IsBiggerThan(BGLake other)
		{
			if(this.area > other.area)
			{
				Console.WriteLine("Lake " + this.name + " is bigger than " +
				                  other.name);
			}
			else if(this.area < other.area)
			{
				Console.WriteLine("Lake " + other.name + " is bigger than " + this.name);
			}
			else { Console.WriteLine("The both lakes have the same area."); }
		}
		public void IsDeeperThan( BGLake other)
		{
			if(this.depth > other.depth) { Console.WriteLine("Lake " + this.name + " is deeper than " + other.name); }
			else if(this.depth < other.depth) { Console.WriteLine("Lake " + other.name + " is deeper than " + this.name); }
			else { Console.WriteLine("The both lakes have the same depth."); }
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			BGLake l1 = new BGLake();
			l1.Print();
			BGLake l2 = new BGLake("Mokroto ezero", 16500, 12.5);
			l2.Print();
			l1.EditArea(12000);
			l2.EditName("Lokvata");
			l1.IsBiggerThan(l2);
			l1.IsDeeperThan(l2);
			
			Console.ReadKey(true);
		}
	}
}