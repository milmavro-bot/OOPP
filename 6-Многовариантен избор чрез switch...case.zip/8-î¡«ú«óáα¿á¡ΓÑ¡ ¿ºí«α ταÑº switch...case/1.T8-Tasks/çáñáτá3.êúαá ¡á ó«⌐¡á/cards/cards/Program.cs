﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 15.10.2020 г.
 * Time: 17:40
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace cards
{
	class Card
	{
		int n, m;
		
		// Конструктор
		public Card(int _n, int _m)
		{
			n = _n;
			m = _m;
		}
		
		// Показва картата
		public void ShowCard()
		{
			string result = "";
			switch(n)
			{
					case 7: result = "seven of "; break;
					case 8: result = "eight of "; break;
					case 9: result = "nine of "; break;
					case 10: result = "ten of "; break;
					case 11: result = "jack of "; break;
					case 12: result = "queen of "; break;
					case 13: result = "king of "; break;
					case 14: result = "ace of "; break;
			}
			switch(m)
			{
					case 1: result += "spades"; break;
					case 2: result += "clubs"; break;
					case 3: result += "diamonds"; break;
					case 4: result += "hearts"; break;
			}
			Console.WriteLine("Card value: {0}\tSuit: {1}", n, m);
			Console.WriteLine("Card: {0}", result);
			Console.WriteLine(new String('-', 25));
		}
		// Сравнява двете карти
		public void BetterCardThan(Card other)
		{
			int th = this.n;
			int oth = other.n;
			if(th > oth) Console.WriteLine("First player wins!");
			else if(th < oth) Console.WriteLine("Second player wins!");
			else Console.WriteLine("War!!!");
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Random rnd = new Random();
			Card c1 = new Card(rnd.Next(7, 15), rnd.Next(1, 5));
			Console.WriteLine("First player card:");
			c1.ShowCard();
			Card c2 = new Card(rnd.Next(7, 15), rnd.Next(1, 5));
			Console.WriteLine("Second player card:");
			c2.ShowCard();
			c1.BetterCardThan(c2);
			
			Console.ReadKey(true);
		}
	}
}