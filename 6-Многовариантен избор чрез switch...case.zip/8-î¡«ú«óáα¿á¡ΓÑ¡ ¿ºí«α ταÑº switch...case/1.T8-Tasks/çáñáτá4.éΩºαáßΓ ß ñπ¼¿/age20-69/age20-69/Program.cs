﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 17.10.2020 г.
 * Time: 10:27
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace age20_69
{
	class Age
	{
		int y;
		
		// Конструктор
		public Age(int _y)
		{
			y = _y;
		}
		
		// Показва възрастта на човек между 20 и 69 години с думи
		public void ShowAgeInWords()
		{
			string result = "";
			// Проверка на десетиците
			switch (y / 10) {
					case 2: result = "twenty-"; break;
					case 3: result = "thirty-"; break;
					case 4: result = "forty-"; break;
					case 5: result = "fifty-"; break;
					case 6: result = "sixty-"; break;
			}
			// Проверка на единиците
			switch (y % 10) {
					case 1: result += "one years"; break;
					case 2: result += "two years"; break;
					case 3: result += "three years"; break;
					case 4: result += "four years"; break;
					case 5: result += "five years"; break;
					case 6: result += "six years"; break;
					case 7: result += "seven years"; break;
					case 8: result += "eight years"; break;
					case 9: result += "nine years"; break;
			}
			// Коректно отпечатване на кръглите години
			switch (y) {
					case 20: result = "twenty years"; break;
					case 30: result = "thirty years"; break;
					case 40: result = "forty years"; break;
					case 50: result = "fifty years"; break;
					case 60: result = "sixty years"; break;
			}
			//Console.WriteLine(y);
			Console.WriteLine(result);
		}
		// Сравнява възрастта на двама души
		public void OlderPersonThan(Age other)
		{
			int thPerson = this.y;
			int othPerson = other.y;
			if(thPerson > othPerson) Console.WriteLine("The first person is older than the second.");
			else if(thPerson < othPerson) Console.WriteLine("The second person is older than the first.");
			else Console.WriteLine("They are both the same age.");
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Random rnd = new Random();
			Age p1 = new Age(rnd.Next(20, 70));
			Console.Write("Age of the first person: ");
			p1.ShowAgeInWords();
			Age p2 = new Age(rnd.Next(20, 70));
			Console.Write("Age of the second person: ");
			p2.ShowAgeInWords();
			p1.OlderPersonThan(p2);
			
			Console.ReadKey(true);
		}
	}
}