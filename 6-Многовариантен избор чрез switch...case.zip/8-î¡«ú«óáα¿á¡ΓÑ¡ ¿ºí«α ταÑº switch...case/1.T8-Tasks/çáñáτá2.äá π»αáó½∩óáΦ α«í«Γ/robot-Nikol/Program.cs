﻿/*
 * Created by SharpDevelop.
 * User: mega
 * Date: 19.10.2020 г.
 * Time: 7:47
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace robot
{
	class Robot
	{
		int posX, posY;
		string lastSessionLog;
		public Robot(int x, int y)
		{
			posX = x;
			posY = y;
			lastSessionLog = "";
		}
		void MoveNorth()
		{
			posY++;
			lastSessionLog += string.Format("{0}{3,6}New position ({1,4};{2,4})\n","One step North",posX, posY," ");
		}
		void MoveSouth()
		{
			posY--;
			lastSessionLog += string.Format("{0}{3,6}New position ({1,4};{2,4})\n","One step South",posX, posY," ");
		}
		void MoveEast()
		{
			posX++;
			lastSessionLog += string.Format("{0}{3,7}New position ({1,4};{2,4})\n","One step East",posX, posY," ");
		}
		void MoveWest()
		{
			posX--;
			lastSessionLog += string.Format("{0}{3,7}New position ({1,4};{2,4})\n","One step West",posX, posY," ");
		}
		bool ReadCommand()
		{
			Console.Write("Enter a command: ");
			string command = Console.ReadLine();
			switch(command)
			{
					case "north": {MoveNorth();
						return true;} break;
					case "south": {MoveSouth();
						return true;} break;
					case "east": {MoveEast();
						return true;} break;
					case "west":{MoveWest();
						return true;} break;
					case "stop": {return false;} break;
					default: {Console.WriteLine("Unknown command! Try again!");
						return true;} break;
			}
		}
		public void StartNewCommandSession()
		{
			lastSessionLog += string.Format("New session started at {0:dd MMM yyyy hh:mm:ss}\n",DateTime.Now);
			lastSessionLog += string.Format("Initial robot position: ({0,4};{1,4})\n",posX,posY);
			lastSessionLog += string.Format(new string('*',60)+"\n");
			Console.WriteLine("List of valid commands: north/south/east/west/stop\n");
			while(ReadCommand()==true)
			{
				ReadCommand();
			}
			lastSessionLog += string.Format(new string('*',60)+"\n");
			lastSessionLog += string.Format("Session ended at {0:dd MMM yyyy hh:mm:ss}\n",DateTime.Now);
			Console.Clear();
			Console.Write(lastSessionLog);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Robot r1 = new Robot(1,2);
			r1.StartNewCommandSession();
			Console.ReadKey(true);
		}
	}
}