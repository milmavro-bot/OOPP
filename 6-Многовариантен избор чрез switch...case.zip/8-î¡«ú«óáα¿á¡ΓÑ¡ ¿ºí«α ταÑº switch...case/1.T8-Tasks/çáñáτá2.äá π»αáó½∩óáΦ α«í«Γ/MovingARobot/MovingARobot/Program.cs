﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 15.10.2020 г.
 * Time: 17:49
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MovingARobot
{
	class Robot
	{
		int posX, posY;
		string lastSessionLog="";
		
		public Robot(int x, int y)
		{
			posY = y; posX = x;
		}
		
		void MoveNorth() 
		{
			posY++;
			lastSessionLog += string.Format("{0, -20}New position ({1,4};{2,4}){3}",
			                                "One step North",
			                                posX, posY, Environment.NewLine);
		}
		void MoveSouth() 
		{
			posY--;
			lastSessionLog += string.Format("{0, -20}New position ({1,4};{2,4}){3}","One step South",posX, posY, Environment.NewLine);
		}
		void MoveEast() 
		{
			posX++;
			lastSessionLog += string.Format("{0, -20}New position ({1,4};{2,4}){3}","One step East",posX, posY, Environment.NewLine);
		}
		void MoveWest() 
		{
			posX--;
			lastSessionLog += string.Format("{0, -20}New position ({1,4};{2,4}){3}","One step West",posX, posY, Environment.NewLine);
		}

		bool ReadCommand()
		{
			Console.Write("Enter a command: ");
			switch (Console.ReadLine()) 
			{
				case "north":
					MoveNorth();
					return true;
				case "south":
					MoveSouth();
					return true;
				case "east":
					MoveEast();
					return true;
				case "west":
					MoveWest();
					return true;
				case "stop":
					return false;
				default:
					Console.WriteLine("Unknown command! Try again!");
					return true;
			}
		}
		public void StartNewCommandSession()
		{
			lastSessionLog = string.Format("New session started at {0:dd MMM yyy HH:mm:ss}",
			                               DateTime.Now );
			lastSessionLog += Environment.NewLine;
			lastSessionLog += string.Format("Initial robot position: ({0,4};{1,4})",
			                                posX, posY) + Environment.NewLine;
			lastSessionLog += string.Format(new String('*', 60) + Environment.NewLine);
			Console.WriteLine("List of valid commands: north/south/east/west/stop");
			while (ReadCommand());
			lastSessionLog += string.Format(new String('*',60)+Environment.NewLine);
			lastSessionLog += string.Format("Session ended at {0:dd MMM yyy HH:mm:ss}",
			                                DateTime.Now );
			Console.Clear();
			Console.WriteLine(lastSessionLog);
		}
	}
	
	class Program
	{
		public static void Main(string[] args)
		{
			Robot r2d2 = new Robot(1, 2);
			r2d2.StartNewCommandSession();
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}