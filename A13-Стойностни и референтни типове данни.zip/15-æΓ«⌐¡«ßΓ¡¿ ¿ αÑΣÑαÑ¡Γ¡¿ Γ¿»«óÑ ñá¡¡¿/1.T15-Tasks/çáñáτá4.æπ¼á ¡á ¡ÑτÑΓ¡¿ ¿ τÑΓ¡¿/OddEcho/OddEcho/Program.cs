﻿using System;

namespace OddEcho
{
    public static class OddEven
    {
        public static void OddEvenSum(int[] arr, out int odd, out int even)
        {
            odd = 0; even = 0;
            for(int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 != 0) odd += arr[i];
                else even += arr[i];
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int o, e;
            int[] a = new int[10];
            Random rnd = new Random();
            for(int i = 0; i < 10; i++)
            {
                a[i] = rnd.Next(1, 101);
            }
            Console.WriteLine("Числа на масива:");
            Console.WriteLine(string.Join(", ", a));
            OddEven.OddEvenSum(a, out o, out e);
            Console.WriteLine("Сума на нечетните числа: {0}", o);
            Console.WriteLine("Сума на четните числа: {0}", e);
            Console.ReadKey(true);
        }
    }
}
