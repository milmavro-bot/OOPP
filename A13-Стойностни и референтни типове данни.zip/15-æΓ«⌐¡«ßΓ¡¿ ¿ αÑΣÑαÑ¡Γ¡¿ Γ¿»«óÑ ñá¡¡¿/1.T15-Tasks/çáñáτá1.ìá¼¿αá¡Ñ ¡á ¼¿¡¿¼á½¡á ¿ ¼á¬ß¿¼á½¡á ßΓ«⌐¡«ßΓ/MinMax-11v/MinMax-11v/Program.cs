﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 26.11.2020 г.
 * Time: 8:42
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MinMax_11v
{
	static class MinMax
	{
		static void FindMinMax(int[] arr, ref int min, ref int max)
		{
			min = arr[0];
			max = arr[0];
			for(int i = 1; i < arr.Length; i++)
			{
				if(arr[i] < min) min = arr[i];
				if(arr[i] > max) max = arr[i];
			}
		}
		
		public static void PrintMinMax()
		{
			int smallest = 0, largest = 0;
			int[] a = new int[25];
			Random rnd = new Random();
			
			for(int i = 0; i < a.Length; i++)
			{
				a[i] = rnd.Next(1, 101);
			}
			Console.WriteLine("Числа на масива!");
			Console.WriteLine(string.Join(", ", a));
			MinMax.FindMinMax(a, ref smallest, ref largest);
			Console.WriteLine("Най-малко число: {0}", smallest);
			Console.WriteLine("Най-голямо число: {0}", largest);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			MinMax.PrintMinMax();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}