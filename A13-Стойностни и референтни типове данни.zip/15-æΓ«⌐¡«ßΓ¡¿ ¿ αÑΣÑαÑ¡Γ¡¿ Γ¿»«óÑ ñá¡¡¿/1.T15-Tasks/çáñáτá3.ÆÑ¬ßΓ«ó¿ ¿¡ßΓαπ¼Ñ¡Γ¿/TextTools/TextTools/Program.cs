﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 26.11.2020 г.
 * Time: 14:08
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace TextTools
{
	class TextTools
	{
		// Метод bool AreAnagrams(string a, string b) – извършва проверка дали двата текста са анаграми -
		// дали единият може да се получи от другия само чрез пренареждане на символите.
		// Например "самолет" и "сметало" са анаграми,
		// но "боб" и "бобо" не са.
		// Връщаният резултат е true (ако текстовете са анаграми) или false (ако не са).
		public static bool AreAnagrams(string a, string b)
		{
			if (a.Length != b.Length) return false;
			char[] aChars = a.ToCharArray();
			char[] bChars = b.ToCharArray();
			Array.Sort(aChars);
			Array.Sort(bChars);
			for (int i = 0; i < a.Length; i++) {
				if(aChars[i] != bChars[i]) return false;
			}
			return true;
		}
		// Метод bool IsMonoLingual(string text, ? string lang) – извършва необходимите проверки и
		// определя дали текстът е написан само със символи от един език (една азбука).
		// Връщаният резултат е true
		// (ако текстът е едноезичен – всички букви са от една и съща азбука)
		// или false (ако не е).
		// Засега методът може да прави проверки само за български,
		// английски и гръцки.
		// В променливата lang се записва:
		// "български", "english",  "ελληνικά" или ""(празен стринг),
		// в зависимост от това, което е определено за езика в text.
		
		// Гръцката азбука: "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνσροπςτυφχψωάέήίϊΐόύϋΰώ".
		public static bool IsMonoLingual(string text, out string lang)
		{
			string bg = "абвгдежзийклмнопрстуфхцчшщъьюя", en = "abcdefghijklmnopqrstuvwxyz",
			gr = "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνσροπςτυφχψωάέήίϊΐόύϋΰώ";
			int bgCounter = 0, enCounter = 0, grCounter = 0, totalLetters = 0;
			
			foreach (var c in text) 
			{
				if(char.IsLetter(c))
				{
					totalLetters++;
					if(bg.Contains((c+"").ToLower())) bgCounter++;
					else if(en.Contains((c+"").ToLower())) enCounter++;
					else if(gr.Contains((c+"").ToLower())) grCounter++;
				}
			}
			if(totalLetters == bgCounter) {lang = "български";  return true;}
			if(totalLetters == enCounter) {lang = "english";  return true;}
			if(totalLetters == grCounter) {lang = "ελληνικά";  return true;}
			lang = "";
			return false;
		}
		// Метод void TwoWordsCross(string a, string b) – извежда на екрана двете думи,
		// пресечени в тяхна обща буква
		// (първата буква от думата а, която се среща и в думата b).
		// Думата а се разполага хоризонтално, а думата b – вертикално.
		// Ако двете думи нямат обща буква,
		// се извежда "Тези думи нямат обща буква!".
		
		// Например, ако а = "параван", b = "врана" и тогава трябва да се изведе следното:
		public static void TwoWordsCross(string a, string b)
		{
			int row = -1, col = -1;
			
			for (int i = 0; i < a.Length; i++) 
			{
				if (b.IndexOf(a[i])>=0) { col = i; row = b.IndexOf(a[i]); break;}
			}
			
			if( row == -1) 
			{
				Console.WriteLine("Тези думи нямат обща буква!");
				return;
			}
			
			System.Collections.Generic.List <char> myTempList = new System.Collections.Generic.List<char>(new String(' ', a.Length));
			
			for (int i = 0; i < b.Length; i++) 
			{
				myTempList[col] = b[i];
				if(i != row) Console.WriteLine(string.Join("",myTempList));
				else Console.WriteLine(a);
			}
			
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.Unicode;
			Console.InputEncoding = System.Text.Encoding.Unicode;
			
			Console.WriteLine("Анаграми");
			Console.Write("Въведете първата дума и натиснете Enter: ");
			string aWord = 	Console.ReadLine();
			Console.Write("Въведете втората дума и натиснете Enter: ");
			string bWord = 	Console.ReadLine();
			if(TextTools.AreAnagrams(aWord, bWord)) Console.WriteLine("Двете думи са анаграми :)");
			else  Console.WriteLine("Двете думи не са анаграми :(");
			
			Console.WriteLine(Environment.NewLine+"Проверка за едноезичен текст");
			Console.Write("Въведете текст и натиснете Enter: ");
			string textT = 	Console.ReadLine();
			string lng;
			if(TextTools.IsMonoLingual(textT, out lng)) Console.WriteLine("Език на текста: " + lng);
			else  Console.WriteLine("Текстът не е едноезичен!");
			
			Console.WriteLine(Environment.NewLine + "Две думи на кръст :)");
			Console.Write("Въведете първата дума и натиснете Enter: ");
			aWord = 	Console.ReadLine();
			Console.Write("Въведете втората дума и натиснете Enter: ");
			bWord = 	Console.ReadLine();
			TextTools.TwoWordsCross(aWord, bWord);
			
			Console.ReadKey(true);
		}
	}
}