﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 27.11.2020 г.
 * Time: 10:11
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace TextTools_11d
{
	static class TextTools
	{
		public static bool AreAnagrams(string a, string b)
		{
			if(a.Length != b.Length) return false;
			char[] aChars = a.ToCharArray();
			char[] bChars = b.ToCharArray();
			Array.Sort(aChars);
			Array.Sort(bChars);
			for(int i = 0; i < a.Length; i++)
			{
				if(aChars[i] != bChars[i]) return false;
			}
			return true;
		}
		
		public static bool IsMonoLingual(string text, out string lang)
		{
			string bg = "абвгдежзийклмнопрстуфхцчшщъьюя";
			string en = "abcdefghijklmnopqrstuvwxyz";
			string gr = "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνσροπςτυφχψωάέήίϊΐόύϋΰώ";
			int bgCounter = 0, enCounter = 0, grCounter = 0, totalCounter = 0;
			
			foreach (var c in text) {
					if(char.IsLetter(c))
					{
						totalCounter++;
						if(bg.Contains((c + "").ToLower())) bgCounter++;
						else if(en.Contains((c + "").ToLower())) enCounter++;
						else if(gr.Contains((c + "").ToLower())) grCounter++;
					}
			}
			if(totalCounter == bgCounter) { lang = "български"; return true; }
			if(totalCounter == enCounter) { lang = "english"; return true; }
			if(totalCounter == grCounter) { lang = "ελληνικά"; return true; }
			lang = "";
			return false;
		}
		
		// От тук трябва да се напише следващия час
	}
	class Program
	{
		public static void Main(string[] args)
		{
			
			
			Console.Write(". . . ");
			Console.ReadKey(true);
		}
	}
}