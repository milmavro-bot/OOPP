﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 30.11.2020 г.
 * Time: 10:27
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;

namespace TextTools_11a
{
	static class TextTools
	{
		public static bool AreAnagrams(string a, string b)
		{
			if(a.Length != b.Length) return false;
			char[] aChars = a.ToCharArray();
			char[] bChars = b.ToCharArray();
			Array.Sort(aChars);
			Array.Sort(bChars);
			for(int i = 0; i < a.Length; i++)
			{
				if(aChars[i] != bChars[i]) return false;
			}
			return true;
		}
		public static bool IsMonoLangual(string text, out string lang)
		{
			string bg = "абвгдежзийклмнопрстуфхцчшщъьюя";
			string en = "abcdefghijklmnopqrstuvwxyz";
			string gr = "ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνσροπςτυφχψωάέήίϊΐόύϋΰώ";
			int bgCounter = 0, enCounter = 0, grCounter = 0, totalLetters = 0;
			
			// 11а клас остава за вторник
			foreach (var c in text) {
				if(char.IsLetter(c))
				{
					totalLetters++;
					if(bg.Contains((c + "").ToLower())) bgCounter++;
					else if(en.Contains((c + "").ToLower())) enCounter++;
					else if(gr.Contains((c + "").ToLower())) grCounter++;
				}
			}
			if(totalLetters == bgCounter) { lang = "български"; return true; }
			if(totalLetters == enCounter) { lang = "english"; return true; }
			if(totalLetters == grCounter) { lang = "ελληνικά"; return true; }
			lang = "";
			return false;
		}
		public static void TwoWordsCross(string a, string b)
		{
			int row = -1, col = -1;
			
			for(int i = 0; i < a.Length; i++)
			{
				if(b.IndexOf(a[i]) >= 0) { col = i; row = b.IndexOf(a[i]); break; }
			}
			
			if(row == -1)
			{
				Console.WriteLine("Тези думи нямат обща буква!");
				return;
			}
			
			List<char> myTempList = new List<char>(new String(' ', a.Length));
			
			for(int i = 0; i < b.Length; i++)
			{
				myTempList[col] = b[i];
				if(i != row) Console.WriteLine(string.Join("", myTempList));
				else Console.WriteLine(a);
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.Unicode;
			Console.InputEncoding = System.Text.Encoding.Unicode;
			
			Console.WriteLine("Анаграми");
			Console.Write("Въведете първата дума: ");
			string aWord = Console.ReadLine();
			Console.Write("Въведете втората дума: ");
			string bWord = Console.ReadLine();
			if(TextTools.AreAnagrams(aWord, bWord))
			{
				Console.WriteLine("Двете думи СА анаграми!");
			}
			else
			{
				Console.WriteLine("Двете думи НЕ са анаграми!");
			}
			
			Console.Write(". . . ");
			Console.ReadKey(true);
		}
	}
}