﻿/*
 * Created by SharpDevelop.
 * User: beasts
 * Date: 27.11.2020 
 * Time: 09:39 ч.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
namespace Txt
{
	class TextTools
	{
		 public static string SortString(string input)
		 {
   	 		char[] characters = input.ToCharArray();
   	 		Array.Sort(characters);
    	 	return new string(characters);
		 }
		public static bool AreAnagrams(string a,string b)
		 {
		 	a=TextTools.SortString(a);
		 	b=TextTools.SortString(b);
		 	if(a.Length!=b.Length) return false;
		 	else 
		 	{
		 		for(int i=0;i<a.Length;i++)
		 		{
		 			if(a[i]!=b[i]) return false;
		 		}
		 		return true;
		 	}
		 }
		public static bool Monolingual(string text, ref string lan)
		 {
		 	string GR="ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνσροπςτυφχψωάέήίϊΐόύϋΰώ";
		 	string BG="АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЬЮЯабвгежзийклмнопрстуфхцчшщъьюя";
		 	string EN="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		 	bool gr=false,bg=false,en=false;
		 	for (int i = 0; i < text.Length; i++) {
		 		if(EN.IndexOf(text[i])!=-1) en=true;
		 		else if(BG.IndexOf(text[i])!=-1) bg=true;
		 		else if(GR.IndexOf(text[i])!=-1) gr=true;
		 	}
		 	if(en==false&&gr==false&&bg==false)
		 	{
		 		lan="Unknown language";
		 		return false;
		 	}
		 	else if(en==true&&gr==false&&bg==false)
		 	{
		 		lan="English";
		 		return true;
		 	}
		 	else if(en==false&&gr==true&&bg==false)
		 	{
		 		lan="Ελληνικά";
		 		return true;
		 	}
		 	else if(en==false&&gr==false&&bg==true)
		 	{
		 		lan="Български";
		 		return true;
		 	}
		 	else
		 	{
		 		lan="";
		 		return false;
		 	}
		 }
		public static void Cross(string a, string b)
		 {
		 	bool f=false;
		 	int ina=0;
		 	int inb=0;
		 	for(int i=0;i<a.Length;i++)
		 	{
		 		for(int j=0;j<b.Length;j++)
		 		{
		 			if(a[i]==b[j])
		 			{
		 				ina=i;
		 				inb=j;
		 				f=true;
		 				break;
		 			}
		 		}
		 		if(f==true) break;
		 	}
		 	
		 	if(f==false) 
		 	{
		 		Console.WriteLine("Word crossing not possible!");
		 		return;
		 	}
		 	string space=new string(' ',ina);
		 	for(int i=0;i<b.Length;i++)
		 	{
		 		if(inb==i)
		 		{
		 			Console.WriteLine(a);
		 		}
		 		else
		 		{
		 			Console.WriteLine(space+b[i]);
		 		}
		 	}
		 }
	}
	class Program
	{
		public static void Main(string[] args)
		{
			string a,b;
			Console.WriteLine("Анаграми");
			Console.Write("Въведете първата дума и натиснете Enter:");
			a=Console.ReadLine();
			Console.Write("Въведете втората дума и натиснете Enter:");
			b=Console.ReadLine();
			if(TextTools.AreAnagrams(a,b)==true) 
			{
				Console.WriteLine("Думите са анаграми :)");
				
			}
			else
			{
				Console.WriteLine("Думите не са анаграми :(");
			}
			Console.WriteLine();
			
			Console.WriteLine("Проверка на едноезичен текст:");
			Console.Write("Въведете текст и натиснете Enter:");
			a=Console.ReadLine();
			bool f=TextTools.Monolingual(a, ref b);
			if(f==true)
			{
				Console.WriteLine("{0}",b);
			}
			else
			{
				if(b=="")
				{
					Console.WriteLine("Текстът не е едноезичен");
				}
				else
				{
					Console.WriteLine(b+"/Езикът не е разпознат");
				}
			}
			Console.WriteLine();
			
			Console.WriteLine("Две думи на кръст");
			Console.Write("Въведете първата дума и натиснете Enter:");
			a=Console.ReadLine();
			Console.Write("Въведете втората дума и натиснете Enter:");
			b=Console.ReadLine();
			TextTools.Cross(a,b);
			Console.WriteLine();
			
			Console.Write("Press any key to continue . . . ");
			//Enter
			Console.ReadKey(true);
		}
		
	}
}