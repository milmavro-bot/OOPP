﻿using System;
using System.Collections.Generic;

namespace g_30._11._2020_01
{
    public class TextTools
    {
        public static bool AreAnagrams(string a,string b)
        {
            char[] a1 = a.ToCharArray();
            char[] b1 = b.ToCharArray();
            List<char> a2 = new List<char>();
            List<char> b2 = new List<char>();
            a2.AddRange(a1);
            b2.AddRange(b1);
            if(a2.Count!=b2.Count)
            {
                return false;
            }
            a2.Sort();
            b2.Sort();
            for(int i=0;i<a2.Count;i++)
            {
                if(a2[i]!=b2[i])
                {
                    return false;
                }
            }
            return true;
        }
        public static bool IsMonoLingual(string text, out string lang)
        {
            lang = "";
            bool check = true;
            char c1 = text[0];
            if(c1>=913&&c1<=1007)
            {
                lang = "ελληνικά";
                for(int i=0;i<text.Length;i++)
                {
                    if((text[i]<913||text[i]>1007)&&char.IsLetter(text[i]))
                    {
                        lang = "";
                        check = false;
                    }
                }
            }
            if(c1>=65&&c1<=122)
            {
                lang = "english";
                for (int i = 0; i < text.Length; i++)
                {
                    if ((text[i] < 65 || text[i] > 122)&& char.IsLetter(text[i]))
                    {
                        lang = "";
                        check = false;
                    }
                }
            }
            if(c1>=1040&&c1<=1103)
            {
                lang = "български";
                for (int i = 0; i < text.Length; i++)
                {
                    if ((text[i] < 1040 || text[i] > 1103)&& char.IsLetter(text[i]))
                    {
                        lang = "";
                        check = false;
                    }
                }
            }
            return check;
        }
        public static void TwoWordsCross(string a, string b)
        {
            int fCross=-1;
            int sCross=-1;
            bool check = false;
            for(int i=0;i<a.Length;i++)
            {
                for(int j=0;j<b.Length;j++)
                {
                    if(a[i]==b[j])
                    {
                        fCross = i;
                        sCross = j;
                        check = true;
                        break;
                    }
                }
                if (check)
                {
                    break;
                }
            }
            if(fCross==-1)
            {
                Console.WriteLine("Тези думи нямат обща буква");
            }
            else
            {
                for(int i=0;i<b.Length;i++)
                {
                    if (i != sCross)
                    {
                        Console.Write(new string(' ', fCross));
                        Console.WriteLine(b[i]);
                    }
                    else
                    {
                        Console.WriteLine(a);
                    }
                }
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = System.Text.Encoding.Unicode;
            Console.OutputEncoding = System.Text.Encoding.Unicode;
            Console.WriteLine("Анаграми");
            Console.Write("Въведете първата дума и натиснете Enter: ");
            string a1 = Console.ReadLine();
            Console.Write("Въведете втората дума и натиснете Enter: ");
            string b1 = Console.ReadLine();
            if(TextTools.AreAnagrams(a1,b1))
            {
                Console.WriteLine("Двете думи са анаграми :)");
            }
            else
            {
                Console.WriteLine("Двете думи не са анаграми :(");
            }
            Console.WriteLine();
            Console.WriteLine("Проверка за едноезичен текст");
            Console.Write("Въведете текст и натиснете Enter: ");
            string text = Console.ReadLine();
            string lang;
            if(TextTools.IsMonoLingual(text, out lang))
            {
                Console.WriteLine("Език на текста: " + lang);
            }
            else
            {
                Console.WriteLine("Текстът не е едноезичен!");
            }
            Console.WriteLine();
            Console.WriteLine("Две думи на кръст :)");
            Console.Write("Въведете първата дума и натиснете Enter: ");
            string w1 = Console.ReadLine();
            Console.Write("Въведете втората дума и натиснете Enter: ");
            string w2 = Console.ReadLine();
            TextTools.TwoWordsCross(w1, w2);
        }
    }
}
