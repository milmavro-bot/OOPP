﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 24.11.2020 г.
 * Time: 12:15
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SwapAndSort
{
	static class SwapAndSort
	{
		// Метод void Swap(? int a, ? int b) – извършва размяна на стойностите на променливите a и b,
		// така че тази промяна да се отрази и на фактическите параметри.
		// На мястото на ? да се постави подходяща служебна дума.
		static void Swap (ref int a, ref int b)
		{
			int temp = a;
			a = b;
			b = temp;
		}
		
		// Метод void Sort3(? int a, ? int b, ? int c) – извършва необходимите размени на стойности
		// между a, b и c,
		// за да ги подреди по големина.
		// След приключване на работа,
		// в променливата a трябва да е записано най-малкото число,
		// в b трябва да е средното по големина,
		// а в  c – най-голямото число.
		// Промяната на стойностите трябва да се отрази и на фактическите параметри.
		// На мястото на ? да се постави подходяща служебна дума.
		
		// При създаването на метода Sort3
		// да се използва само метода Swap и оператор за избор, нищо друго!
		public static void Sort3(ref int a, ref int b, ref int c)
		{
			if (a > b) SwapAndSort.Swap(ref a, ref b);
			if (b > c) SwapAndSort.Swap(ref b, ref c);
			if (a > b) SwapAndSort.Swap(ref a, ref b);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Random r = new Random();
			int x = r.Next (1, 1001);
			int y = r.Next (1, 1001);
			int z = r.Next (1, 1001);
			
			Console.WriteLine("В началото x={0} y={1} z={2}", x, y, z);
			SwapAndSort.Sort3(ref x, ref y, ref z);
			Console.WriteLine("След подреждането x={0} y={1} z={2}", x, y, z);
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}