﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 27.11.2020 г.
 * Time: 12:05
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SwapAndSort_11e
{
	static class SwapAndSort
	{
		static void Swap(ref int a, ref int b)
		{
			int temp = a;
			a = b;
			b = temp;
		}
		public static void Sort3(ref int a, ref int b, ref int c)
		{
			if(a > b) SwapAndSort.Swap(ref a, ref b);
			if(b > c) SwapAndSort.Swap(ref b, ref c);
			if(a > b) SwapAndSort.Swap(ref a, ref b);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Random r = new Random();
			int x = r.Next(1, 1001);
			int y = r.Next(1, 1001);
			int z = r.Next(1, 1001);
			
			Console.WriteLine("В началото x = {0} y = {1} z = {2}", x, y, z);
			SwapAndSort.Sort3(ref x, ref y, ref z);
			Console.WriteLine("След подреждането x = {0} y = {1} z = {2}", x, y, z);
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}