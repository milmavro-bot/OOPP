﻿/*
 * Created by SharpDevelop.
 * User: Bobo
 * Date: 4.1.2021 г.
 * Time: 9:46
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace StudentMeetings
{
	class Meeting
	{
		DateTime time;
		int day;
		int month;
		int year;
		int hour;
		int minutes;
		string subject;
		public Meeting(int d, int m, int y, int h, int mins, string sub)
		{
			day = d;
			month = m;
			year = y;
			hour = h;
			minutes = mins;
			subject = sub;
			time = new DateTime(year, month, day, hour, minutes, 0);
		}
		public Meeting(int d, int m, string sub)
		{
			day = d;
			month = m;
			subject = sub;
			year = DateTime.Now.Year;
			hour = 10;
			minutes = 0;
			time = new DateTime(year, month, day, hour, minutes, 0);
		}
		protected string Details()
		{
			return string.Format("Дата и час: {0:dd.MM.yyyy HH:mm} \nТема: {1}", time, subject);
		}
	}
	class StudentsMeeting : Meeting
	{
		string location;
		public StudentsMeeting(string loc, int d, int m, int y, int h, int mins, string sub) 
			: base(d, m, y, h, mins, sub)
		{
			location = loc;
		}
		public StudentsMeeting(string loc, int d, int m, string sub)
			: base (d, m, sub)
		{
			location = loc;
		}
		public void PrintDetails()
		{
			Console.WriteLine();
			Console.WriteLine("Среща на ученици:");
			Console.WriteLine("Място: {0}", location);
			Console.WriteLine("{0}", Details());
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			StudentsMeeting sm;
			Console.WriteLine("Въведете тема на срещата:");
			string subject = Console.ReadLine();
			Console.WriteLine("Въведете място на срещата:");
			string location = Console.ReadLine();
			Console.WriteLine("Изберете 1 за да определите само месец и ден или 2 за пълно определяне на дата и час:");
			int choice = int.Parse(Console.ReadLine());
			switch(choice)
			{
				case 1: 
					{
						Console.Write("Въведете ден: ");
						int day = int.Parse(Console.ReadLine());
						Console.Write("Въведете месец: ");
						int month = int.Parse(Console.ReadLine());
						sm = new StudentsMeeting(location, day, month, subject);
						sm.PrintDetails();
						break;
					}
				case 2:
					{
						Console.Write("Въведете ден: ");
						int day = int.Parse(Console.ReadLine());
						Console.Write("Въведете месец: ");
						int month = int.Parse(Console.ReadLine());
						Console.Write("Въведете година: ");
						int year = int.Parse(Console.ReadLine());
						Console.Write("Час: ");
						int hour = int.Parse(Console.ReadLine());
						Console.Write("Минути: ");
						int minutes = int.Parse(Console.ReadLine());
						sm = new StudentsMeeting(location, day, month, year, hour, minutes, subject);
						sm.PrintDetails();
						break;
					}
			}
			Console.ReadKey(true);
		}
	}
}