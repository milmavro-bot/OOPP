﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 6.1.2021 г.
 * Time: 8:37
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace meetings_extra_11v
{
	/// <summary>
	/// Description of EmployeeMeeting.
	/// </summary>
	public class EmployeeMeeting
	{
		public EmployeeMeeting()
		{
		}
	}
}
