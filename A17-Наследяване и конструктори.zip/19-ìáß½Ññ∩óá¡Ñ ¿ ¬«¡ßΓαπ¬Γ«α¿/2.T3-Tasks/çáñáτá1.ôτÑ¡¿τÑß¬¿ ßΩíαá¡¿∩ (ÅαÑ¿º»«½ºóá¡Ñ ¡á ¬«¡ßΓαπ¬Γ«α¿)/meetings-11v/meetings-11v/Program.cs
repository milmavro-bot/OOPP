﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 5.1.2021 г.
 * Time: 8:36
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace meetings_11v
{
	class Meeting
	{
		DateTime time;
		int day, month, year, hour, minutes;
		string subject;
		
		public Meeting(int d, int m, int y, int h, int mins, string sub)
		{
			day = d;
			month = m;
			year = y;
			hour = h;
			minutes = mins;
			subject = sub;
			time = new DateTime(year, month, day, hour, minutes, 0);
		}
		public string Details()
		{
			string result = string.Format(" at {0:dd.MM.yyyy hh:mm}; Subject: {1}", time, subject);
			return result;
		}
	}
	class StudentsMeeting : Meeting
	{
		string location;
		public StudentsMeeting(string loc, int day, int month, int year, int hour, int minutes, string subject)
			: base(day, month, year, hour, minutes, subject)
		{
			location = loc;
		}
		public void PrintDetails()
		{
			Console.WriteLine();
			Console.WriteLine("Information of a meeting:");
			Console.WriteLine("Meeting in {0}{1}", location, Details());
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Enter the date and time of the meeting:");
			Console.Write("day: ");
			int day = int.Parse(Console.ReadLine());
			Console.Write("month: ");
			int month = int.Parse(Console.ReadLine());
			Console.Write("year: ");
			int year = int.Parse(Console.ReadLine());
			Console.Write("hour: ");
			int hour = int.Parse(Console.ReadLine());
			Console.Write("minutes: ");
			int minutes = int.Parse(Console.ReadLine());
			Console.WriteLine("Enter a meeting location:");
			string location = Console.ReadLine();
			Console.WriteLine("Enter a subject for the meeting:");
			string subject = Console.ReadLine();
			
			StudentsMeeting sm = new StudentsMeeting(location, day, month, year, hour, minutes, subject);
			sm.PrintDetails();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}