﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 7.1.2021 г.
 * Time: 9:22
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace TravelClock_11a
{
	class Clock
	{
		bool isMilitary;
		DateTime dt;
		public Clock(bool useMilitary)
		{
			isMilitary = useMilitary;
			dt = DateTime.Now;
		}
		public string GetLocation()
		{
			return TimeZoneInfo.Local.DisplayName;
		}
		public int GetHours()
		{
			int hours = dt.Hour;
			if(isMilitary) return hours;
			if(hours == 0) return 12;
			if(hours > 12) return hours - 12;
			return hours;
		}
		public int GetMinutes()
		{
			int minutes = dt.Minute;
			return minutes;
		}
		public bool IsMilitary()
		{
			return isMilitary;
		}
	}
	class TravelClock : Clock
	{
		string location;
		int timeDifference;
		public TravelClock(bool mil, string loc, int diff)
			: base(mil)
		{
			location = loc;
			timeDifference = diff;
			// SetTimeDiff();
		}
		public int SetTimeDiff()
		{
			while(timeDifference < 0)
			{
				timeDifference = timeDifference + 24;
			}
			return timeDifference;
		}
		public string GetNewLocation()
		{
			return location;
		}
		public int GetNewHours()
		{
			int h = GetHours();
			if(IsMilitary())
			{
				return (h + timeDifference) % 24;
			}
			else
			{
				h = (h + timeDifference) % 12;
				if(h == 0) return 12;
				else return h;
			}
		}
		public void PrintTimeZone()
		{
			foreach(TimeZoneInfo z in TimeZoneInfo.GetSystemTimeZones())
			{
				Console.WriteLine(z.DisplayName);
			}
			Console.WriteLine(new String('-', 70));
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			/*bool more = true;
			while(more)
			{
				Clock clock1 = new Clock(true);
				Clock clock2 = new Clock(false);
				Console.WriteLine("Military time is " + clock1.GetHours() + ":" + clock1.GetMinutes());
				Console.WriteLine("AM/PM time is " + clock2.GetHours() + ":" + clock2.GetMinutes());
				Console.Write("Try again? (y/n): ");
				string input = Console.ReadLine();
				if(input != "y") more = false;
			}*/
			
			Clock clock1 = new Clock(true);
			TravelClock clock2 = new TravelClock(false, "Moscow", 1);
			TravelClock clock3 = new TravelClock(true, "Vladivostok", 8);
			//clock2.PrintTimeZone();
			Console.WriteLine("{0} time is {1}:{2:00}", clock1.GetLocation(), clock1.GetHours(),
			                  clock1.GetMinutes());
			Console.WriteLine("{0} time is {1}:{2:00}", clock2.GetNewLocation(), clock2.GetNewHours(),
			                  clock2.GetMinutes());
			Console.WriteLine("{0} time is {1}:{2:00}", clock3.GetNewLocation(), clock3.GetNewHours(),
			                  clock3.GetMinutes());
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}