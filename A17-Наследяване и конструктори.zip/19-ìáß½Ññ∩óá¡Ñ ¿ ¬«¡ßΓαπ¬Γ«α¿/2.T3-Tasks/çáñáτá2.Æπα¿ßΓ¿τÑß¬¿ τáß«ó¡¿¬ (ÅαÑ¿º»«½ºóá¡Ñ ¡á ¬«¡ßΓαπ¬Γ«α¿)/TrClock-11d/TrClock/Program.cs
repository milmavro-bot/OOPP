﻿/*
 * Created by SharpDevelop.
 * User: user
 * Date: 1/6/2021
 * Time: 12:39 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace TrClock
{
	class Clock
	{
		bool isMilitary;
		protected DateTime dt = DateTime.Now;
		public Clock(bool useMilitary)
		{
			isMilitary=useMilitary;
		}
		public string GetLocation()
		{
			return TimeZoneInfo.Local.DisplayName;
		}
		public bool IsMilitary()
		{
			return isMilitary;
		}
		public int GetHours()
		{
			if(dt.Hour>12)
			{
				if(IsMilitary()) return dt.Hour;
				return dt.Hour-12;
			}
			return dt.Hour;
		}
		public int GetMinutes()
		{
			return dt.Minute;
		}
	}
	class TravelClock : Clock
	{
		string location;
		int timeDifference;
		public TravelClock(bool mil, string loc, int diff) : base (mil)
		{
			location=loc;
			timeDifference=diff;
			SetTimeDiff();
		}
		void SetTimeDiff()
		{
			while(timeDifference < 0)
			{
				timeDifference+=24;
			}
		}
		public string GetNewLocation()
		{
			return location;
		}
		public int GetNewHours()
		{	
			DateTime dt1 = dt.AddHours(timeDifference);
			if(dt1.Hour>12)
			{
				if(IsMilitary()) return dt.Hour;
				return dt1.Hour-12;
			}
			return dt1.Hour;
		}
		public void PrintTimeZone()
		{
			foreach(TimeZoneInfo z in TimeZoneInfo.GetSystemTimeZones())
			{
				Console.WriteLine(z.DisplayName);
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Clock clock1 = new Clock(true);
			TravelClock clock2 = new TravelClock(true, "Rome", -1);
			TravelClock clock3 = new TravelClock(false, "Tokyo", 7);
			clock2.PrintTimeZone();
			Console.WriteLine(new String('-', 70));
			Console.WriteLine(string.Format("{0} time is {1}:{2:00}", clock1.GetLocation(), clock1.GetHours(), clock1.GetMinutes()));
			Console.WriteLine(string.Format("{0} time is {1}:{2:00}", clock2.GetNewLocation(), clock2.GetNewHours(), clock2.GetMinutes()));
			Console.WriteLine(string.Format("{0} time is {1}:{2:00}", clock3.GetNewLocation(), clock3.GetNewHours(), clock3.GetMinutes()));
			
			Console.ReadKey(true);
		}
	}
}