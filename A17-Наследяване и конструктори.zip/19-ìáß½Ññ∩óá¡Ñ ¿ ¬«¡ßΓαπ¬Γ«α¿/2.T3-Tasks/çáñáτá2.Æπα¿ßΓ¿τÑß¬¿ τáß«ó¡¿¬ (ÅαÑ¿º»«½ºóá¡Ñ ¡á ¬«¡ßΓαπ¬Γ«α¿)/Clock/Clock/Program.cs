﻿/*
 * Created by SharpDevelop.
 * User: beasts
 * Date: 08.01.2021 
 * Time: 07:22 ч.
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Clock
{
	class Clock
	{
		public DateTime dt;
		public bool isMilitary;
		public Clock(bool useMilitary)
		{
			dt=new DateTime();
			dt=DateTime.Now;
			isMilitary=useMilitary;
		}
		public string GetLocation()
		{
			return TimeZoneInfo.Local.DisplayName;
		}
		public void PrintTimeAll()
		{
			if(isMilitary==true) Console.WriteLine("{0} time is {1:HH:mm}",GetLocation(),dt);
			else Console.WriteLine("{0} time is {1:hh:mm}",GetLocation(),dt);
			Console.Write("Try again? (y/n):");
			string c;
			c=Console.ReadLine();
			if(c=="y"||c=="Y") PrintTimeAll();
		}
	}
	class TravelClock: Clock
	{
		string location;
		int timeDiff;
		public TravelClock(bool mil, string loc, int diff) : base(mil)
		{
			location=loc;
			timeDiff=diff;
		}
		DateTime NewTime()
		{
			int h=dt.Hour;
			h=h+timeDiff+24;
			h=h%24;
			DateTime nt=new DateTime(1,1,1,h,DateTime.Now.Minute,0);
			return nt;
		}
		public static void PrintTimeZone()
		{
			foreach(TimeZoneInfo z in TimeZoneInfo.GetSystemTimeZones())
{
Console.WriteLine(z.DisplayName);
}
		}
		public void PrintTime()
		{
			if(isMilitary==true) Console.WriteLine("{0} time is {1:HH:mm}",location,NewTime());
			else Console.WriteLine("{0} time is {1:hh:mm}",location,NewTime());
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			bool c;
			string f;
			Console.Write("Military clock for here? (y/n)");
			f=Console.ReadLine();
			if(f=="y"||f=="Y") c=true;
			else c=false;
			Clock cl=new Clock(c);
			cl.PrintTimeAll();
			
			string lc;
			int td;
			TravelClock.PrintTimeZone();
			
			Console.WriteLine();
			
			Console.Write("Location:");
			lc=Console.ReadLine();
			Console.Write("Time Difference: ");
			td=Convert.ToInt32(Console.ReadLine());
			Console.Write("Military clock for {0}? (y/n)",lc);
			f=Console.ReadLine();
			if(f=="y"||f=="Y") c=true;
			else c=false;
			TravelClock tcl1=new TravelClock(c,lc,td);
			tcl1.PrintTime();
			
			Console.WriteLine();
			
			
			Console.Write("Location:");
			lc=Console.ReadLine();
			Console.Write("Time Difference: ");
			td=Convert.ToInt32(Console.ReadLine());
			Console.Write("Military clock for {0}? (y/n)",lc);
			f=Console.ReadLine();
			if(f=="y"||f=="Y") c=true;
			else c=false;
			TravelClock tcl2=new TravelClock(c,lc,td);
			tcl2.PrintTime();
			
			cl.PrintTimeAll();
			tcl1.PrintTime();
			tcl2.PrintTime();
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}