﻿/*
 * Created by SharpDevelop.
 * User: Bobo
 * Date: 5.1.2021 г.
 * Time: 9:34
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace TravelClock
{
	class Clock
	{
		bool isMilitary;
		protected DateTime dt;
		public Clock(bool useMilitary)
		{
			isMilitary = useMilitary;
			dt = DateTime.Now;
		}
		public string GetLocation()
		{
			return TimeZoneInfo.Local.DisplayName;
		}
		public int GetHours()
		{
			if(IsMilitary()) return dt.Hour;
			else if(dt.Hour > 12) return dt.Hour-12;
			return dt.Hour;
		}
		public int GetMinutes()
		{
			return dt.Minute;
		}
		protected bool IsMilitary()
		{
			if(isMilitary) return true;
			return false;
		}
	}
	class TravelClock : Clock
	{
		string location;
		int timeDifference;
		public TravelClock(bool mil, string loc, int diff) : base(mil)
		{
			location = loc;
			timeDifference = diff;
			SetTimeDiff();
		}
		int SetTimeDiff()
		{
			int tD = timeDifference -TimeZoneInfo.Local.BaseUtcOffset.Hours;
			if(tD < 0) tD += 24;
			return tD;
		}
		public string GetNewLocation()
		{
			return location;
		}
		public int GetNewHours()
		{
			int newHours = dt.AddHours(SetTimeDiff()).Hour;
			if(IsMilitary()) return newHours;
			else if(newHours > 12) return newHours-12;
			return newHours;
		}
		public static void PrintTimeZone() 
		{
			foreach(TimeZoneInfo z in TimeZoneInfo.GetSystemTimeZones())
			Console.WriteLine(z.DisplayName);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Clock clock1 = new Clock(true);
			TravelClock clock2 = new TravelClock(true, "Rome", -1);
			TravelClock clock3 = new TravelClock(false, "Tokyo", 7);
			TravelClock.PrintTimeZone();
			Console.WriteLine(new String('-', 50));
			Console.WriteLine(clock1.GetLocation());
			Console.WriteLine("{0} time is {1}:{2}", clock2.GetNewLocation(), clock2.GetNewHours(), clock2.GetMinutes());
			Console.WriteLine("{0} time is {1}:{2}", clock3.GetNewLocation(), clock3.GetNewHours(), clock3.GetMinutes());
			Console.ReadKey(true);
		}
	}
}