﻿using System;
using System.Collections.Generic;
using System.Text;

namespace touristclock
{
    class Clock
    {
        bool isMilitary;
        public DateTime dt;
        public Clock(bool useMilitary)
        {
            dt = DateTime.Now;
            isMilitary = useMilitary;
        }
        public string GetLocation()
        {
            return TimeZoneInfo.Local.DisplayName;
        }
        public int GetHours()
        {
            if (isMilitary) return dt.Hour;
            else return dt.Hour - 12;
        }
        public int GetMinutes()
        {
            return dt.Minute;
        }
        public bool IsMilitary()
        {
            if (isMilitary) return true;
            else return false;
        }
    }
}
