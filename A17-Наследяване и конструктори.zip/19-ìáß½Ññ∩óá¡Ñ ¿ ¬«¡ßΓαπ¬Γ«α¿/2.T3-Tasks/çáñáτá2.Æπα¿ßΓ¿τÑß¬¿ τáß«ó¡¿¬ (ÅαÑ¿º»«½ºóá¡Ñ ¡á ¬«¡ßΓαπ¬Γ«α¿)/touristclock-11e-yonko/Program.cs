﻿using System;

namespace touristclock
{
    class Program
    {
        static void Main(string[] args)
        {
            Clock clock1 = new Clock(true);
            TravelClock clock2 = new TravelClock(true, "Rome", -1);
            TravelClock clock3 = new TravelClock(false, "Tokyo", 7);
            clock2.PrintTimeZone();
            Console.WriteLine(new string('-',60));
            Console.WriteLine($"{clock1.GetLocation()} time is {clock1.GetHours()}:{clock1.GetMinutes()}");
            Console.WriteLine($"{clock3.GetNewLocation()} time is {clock3.GetNewHours()}:{clock3.GetMinutes()}");
            Console.WriteLine($"{clock2.GetNewLocation()} time is {clock2.GetNewHours()}:{clock2.GetMinutes()}");
        }
    }
}
