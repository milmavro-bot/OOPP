﻿using System;
using System.Collections.Generic;
using System.Text;

namespace touristclock
{
    class TravelClock:Clock
    {
        string location;
        int timeDifference;
        public TravelClock(bool mil,string loc,int diff)
            : base (mil)
        {
            location = loc;
            timeDifference = diff;
            timeDifference=SetTimeDiff();
        }
        int SetTimeDiff()
        {
            int diff = dt.Hour + timeDifference;
            if (diff <= 0) diff += 24;
            return diff;
        }
        public string GetNewLocation()
        {
            return location;
        }
        public string GetNewHours()
        {
            return timeDifference.ToString();
        }
        public void PrintTimeZone()
        {
            foreach(var z in TimeZoneInfo.GetSystemTimeZones())
            {
                Console.WriteLine(z.DisplayName);
            }
        }
    }
}
