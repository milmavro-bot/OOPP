﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 25.1.2021 г.
 * Time: 7:44
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace cinema
{
	interface IPremierable
	{
		double CalcTotalIncome();
	}
	interface INormal
	{
		double CalcTotalIncome();
	}
	interface IWithDiscount
	{
		double CalcTotalIncome();
	}
	class Movie : IPremierable, INormal, IWithDiscount
	{
		int rows, columns;
		public Movie(int r, int c)
		{
			rows = r;
			columns = c;
		}
		double IPremierable.CalcTotalIncome()
		{
			return rows * columns * 12.0;
		}
		double INormal.CalcTotalIncome()
		{
			return rows * columns * 7.5;
		}
		double IWithDiscount.CalcTotalIncome()
		{
			return rows * columns * 5.0;
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Печалби от прожекциите в кино 'Култура'");
			Console.WriteLine("---------------------------------------");
			IPremierable ip = new Movie(10, 12);
			Console.WriteLine("Премиера: {0:c2}", ip.CalcTotalIncome());
			INormal inor = new Movie(21, 13);
			Console.WriteLine("Нормална прожекция: {0:c2}", inor.CalcTotalIncome());
			IWithDiscount idis = new Movie(12, 30);
			Console.WriteLine("Прожекция за деца, ученици и студенти: {0:c2}", idis.CalcTotalIncome());
			
			Console.Write(". . . ");
			Console.ReadKey(true);
		}
	}
}