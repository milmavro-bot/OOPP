﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 25.01.2021 г.
 * Time: 15:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace DataTransfer
{
	/// <summary>
	/// Description of AirFlowConnection.
	/// </summary>
	public class AirFlowConnection : IConnectable
	{
		bool	connected;
		public AirFlowConnection()
		{
			connected = false;
		}
		
		public bool Connect()
		{
			Console.Write("Да се свърже ли помещението към общата вентилационна система? ");
			if(Console.ReadLine().ToUpper() == "ДА")
			{
				Console.WriteLine("Успешно свързване към общата вентилационна система!");
				connected = true;
				Console.ReadKey(true);
				return true;
			}
			Console.WriteLine("Неуспешно свързване към общата вентилационна система!");
			Console.ReadKey(true);
			return false;
		}


		public void Disconnect()
		{
			Console.WriteLine("Прекъсната е връзката с общата вентилационна система!");
			connected = false;
		}

	}
}
