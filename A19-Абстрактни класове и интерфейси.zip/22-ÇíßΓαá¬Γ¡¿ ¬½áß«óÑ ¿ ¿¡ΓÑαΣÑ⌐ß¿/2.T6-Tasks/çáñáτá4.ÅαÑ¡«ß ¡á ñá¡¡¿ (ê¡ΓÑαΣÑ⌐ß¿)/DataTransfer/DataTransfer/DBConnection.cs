﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 25.01.2021 г.
 * Time: 14:30
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace DataTransfer
{
	/// <summary>
	/// Description of DBConnection.
	/// </summary>
	public class DBConnection : IConnectable, ITransferable
	{
		string	dbServer, dbUser, dbPass;
		bool	isConnected;

		public DBConnection (string dbServer, string dbUser, string dbPass)
		{
			this.dbPass = dbPass;
			this.dbServer = dbServer;
			this.dbUser = dbUser;
			isConnected = false;
		}
		
		public bool Connect()
		{
			Console.WriteLine("Опит за свързване с DB Server: {0}", dbServer );
			int n = new Random().Next(1, 11);
			if( n!= 10)
			{
				Console.WriteLine("Успешно свързване с базата данни");
				isConnected = true;
				return true;
			}
			Console.WriteLine("Неуспешно свързване, моля проверете потребителското име и паролата!");
			return false;
		}
		
		public void Disconnect()
		{
			Console.WriteLine("Край на връзката с DB Server: {0}", dbServer );
			isConnected = false;
		}
		
		public string ReceiveMessage() 
		{
			Random r = new Random();
			const string azbuka = "абвгдежзийклмнопрстуфхцчшщъьюя";
			string rez = "";
			for (int i = 0; i < 10; i++) 
			{
				rez += azbuka[r.Next(0, azbuka.Length)];
			}
			return rez;
		}
		
		public void SendMessage(string message)
		{
			Console.WriteLine("Към базата данни е изпратено съобщението: {0}", message);
		}
	}
}
