﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 25.01.2021 г.
 * Time: 15:11
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace DataTransfer
{
	/// <summary>
	/// Description of BluetoothConnection.
	/// </summary>
	public class BluetoothConnection : IConnectable, ITransferable
	{
		string	deviceToPair;
		public BluetoothConnection()
		{
			deviceToPair = "";
		}
		
		public bool Connect()
		{
			Console.Write("Въведете устройство за свързване: ");
			deviceToPair = Console.ReadLine();
			Console.WriteLine("Опит за установяване на Bluetooth връзка с устройство: {0}", deviceToPair );
			int n = new Random().Next(1, 8);
			if( n <= 5)
			{				
				Console.WriteLine("Успешно сдвояване!");
				return true;
			}
			Console.WriteLine("Неуспешно сдвояване, моля опитайте по-късно!");
			return false;
		}
		
		public void Disconnect()
		{
			Console.WriteLine("Прекратена е Bluetooth връзка с устройство: {0}", deviceToPair );
		}
		
		public string ReceiveMessage() 
		{
			return "Bluetooth поздрав!";
		}
		
		public void SendMessage(string message)
		{
			Console.WriteLine("На Bluetooth сдвоеното устройство е предадено съобщението: {0}", message);
		}
	}
}
