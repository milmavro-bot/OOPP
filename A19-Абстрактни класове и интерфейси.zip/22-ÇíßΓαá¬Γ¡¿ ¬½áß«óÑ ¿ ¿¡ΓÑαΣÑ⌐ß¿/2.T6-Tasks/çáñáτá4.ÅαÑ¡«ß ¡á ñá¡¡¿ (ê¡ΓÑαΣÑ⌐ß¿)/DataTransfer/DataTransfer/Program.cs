﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 25.01.2021 г.
 * Time: 14:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace DataTransfer
{
	class Program
	{
		public static void TestConnection(IConnectable cntn)
		{
			if(cntn.Connect())
			{
				if(cntn is ITransferable)
				{
					ITransferable itr = (ITransferable)cntn;
					Console.WriteLine("Получено е съобщение: {0}", itr.ReceiveMessage() );
					itr.SendMessage("Здравей");
				}
				cntn.Disconnect();
			}
			Console.WriteLine();
		}
		public static void Main(string[] args)
		{
			IConnectable c = new DBConnection("SQL_server", "Admin", "pass123");
			TestConnection(c);
			
			c = new CellPhoneConnection("052100102");
			TestConnection(c);
			
			c = new BluetoothConnection();
			TestConnection(c);
			
			c = new AirFlowConnection();
			TestConnection(c);
			
			
			Console.ReadKey(true);
		}
	}
}