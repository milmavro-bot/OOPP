﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 25.01.2021 г.
 * Time: 14:29
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace DataTransfer
{
	/// <summary>
	/// Description of ITranferable.
	/// </summary>
	public interface ITransferable
	{
		
		string ReceiveMessage();
		
		void SendMessage(string message);

	}
}
