﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 25.01.2021 г.
 * Time: 14:28
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace DataTransfer
{
	/// <summary>
	/// Description of IConnectable.
	/// </summary>
	public interface IConnectable
	{
		
		bool Connect();
		
		void Disconnect();

	}
}
