﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 25.01.2021 г.
 * Time: 14:51
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace DataTransfer
{
	/// <summary>
	/// Description of CellPhoneConnection.
	/// </summary>
	public class CellPhoneConnection : IConnectable, ITransferable
	{
		string	numToCall;
		
		public CellPhoneConnection(string numToCall)
		{
			this.numToCall = numToCall;
		}
		
		public bool Connect()
		{
			Console.WriteLine("Опит за свързване с телефонен номер: {0}", numToCall );
			int n = new Random().Next(1, 21);
			if( n <= 15)
			{			
				Console.WriteLine("Успешно свързване!");
				return true;
			}
			Console.WriteLine("Абонатът е зает, моля опитайте по-късно!");
			return false;
		}
		
		public void Disconnect()
		{
			Console.WriteLine("Край на разговора с телефонен номер: {0}", numToCall );
		}
		
		public string ReceiveMessage() 
		{
			return "Ало";
		}
		
		public void SendMessage(string message)
		{
			Console.WriteLine("По телефона е предадено съобщението: {0}", message);
		}
	}
}
