﻿using System;

namespace figures
{
    public abstract class Figure
    {
        abstract public double S();         // абстрактен метод
        virtual public void Print()         // виртуален метод
        {
            Console.WriteLine("S = {0}", S());
        }
    }
    public abstract class Figure3D : Figure
    {
        abstract public double V();          // нов абстрактен метод
        override public void Print()         // предефиниран метод
        {
            base.Print();                    // достъп до Print() на Figure
            Console.WriteLine("V = {0}", V());
        }
    }
    public class Parallelepiped : Figure3D
    {
        private double a, b, c;              // страни
        // Конструктор
        public Parallelepiped(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        // Реализиране на метод S()
        override public double S()
        {
            return 2 * (a + b + c * (a + b));
        }
        // Реализиране на метод V()
        override public double V()
        {
            return a * b * c;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Abstract Test");
            Console.WriteLine(new String('-', 15));
            Parallelepiped parallelepiped = new Parallelepiped(2, 5, 3);
            // или с полиморфизъм
            // Figure figure = new Parallelepiped(2, 5, 3);
            parallelepiped.Print();
            Console.ReadKey(true);
        }
    }

    public abstract class Class1
    {
    }
}
