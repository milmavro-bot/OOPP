﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 19.1.2021 г.
 * Time: 9:01
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace duties2
{
	abstract class Car
	{
		protected abstract double CalcDuty();
		protected abstract double CalcExcise();
		protected abstract double CalcVAT();
		protected abstract double CalcTotal();
		public abstract void PrintInfo();
	}
	class CarFromEU : Car
	{
		string model, country;
		int volumeEngine, powerEngine;
		double price, transportCosts;
		
		public CarFromEU(string country, string model, int volumeEngine, int powerEngine, double price, double transportCosts)
		{
			this.country = country;
			this.model = model;
			this.price = price;
			this.transportCosts = transportCosts;
			this.volumeEngine = volumeEngine;
			this.powerEngine = powerEngine;
		}
		protected override double CalcDuty()
		{
			double tariff = 0;
			if(volumeEngine >= 0 && volumeEngine <= 1000)
			{
				tariff = 0.15;
			}
			else if(volumeEngine >= 1001 && volumeEngine <= 3000)
			{
				tariff = 0.2;
			}
			else if(volumeEngine >= 3001)
			{
				tariff = 0.25;
			}
			return (price + transportCosts) * tariff;
		}
		protected override double CalcExcise()
		{
			const double EXCISE = 0.4;
			if(powerEngine > 164) return price * EXCISE;
			return 0;
		}
		protected override double CalcVAT()
		{
			const double VAT = 0.2;
			return (price + transportCosts + CalcDuty()) * VAT;
		}
		protected override double CalcTotal()
		{
			return CalcDuty() + CalcExcise() + CalcVAT() + price;
		}
		public override void PrintInfo()
		{
			Console.WriteLine("Държава: {0}", country);
			Console.WriteLine("Модел: {0}", model);
			Console.WriteLine("Обем на двигателя: {0}", volumeEngine);
			Console.WriteLine("Мощност на двигателя: {0} к.с.", powerEngine);
			Console.WriteLine("Цена (лв): {0:0.00}", price);
			Console.WriteLine(new String('-', 30));
			Console.WriteLine("Мито (лв): {0:0.00}", CalcDuty());
			Console.WriteLine("Акциз (лв): {0:0.00}", CalcExcise());
			Console.WriteLine("ДДС (лв): {0:0.00}", CalcVAT());
			Console.WriteLine("Обща стойност (лв): {0:0.00}", CalcTotal());
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			CarFromEU myCar = new CarFromEU("Германия", "VW Golf", 1800, 170, 28000, 600);
			myCar.PrintInfo();
			
			Console.Write(". . . ");
			Console.ReadKey(true);
		}
	}
}