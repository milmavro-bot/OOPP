﻿using System;

namespace RentalCars
{
    interface IRentalCar
    {
        // Моделът трябва да се отпечата
        void ShowModel();
        // Горивото трябва да се отпечата: дизел, бензин, метан, газ
        void ShowFuel();
        // Има ли шофьор "Да", "Не"
        string HasDriver();
        // Брой дни, за които е нает автомобилът
        int CalcNumberOfDays();
        // Изчисляване на дължимата сума
        double CalcAmount();
        // Изчисляване на общата сума
        double CalcTotal();
    }
    class Opel : IRentalCar
    {
        string model, fuel;
        bool isDriver;
        DateTime startDate, endDate;
        double price24;
        public Opel(string m, string f, bool isDr, DateTime start, DateTime end, double price)
        {
            model = m;
            fuel = f;
            isDriver = isDr;
            startDate = start;
            endDate = end;
            price24 = price;
        }
        public void ShowModel()
        {
            Console.WriteLine("Модел: {0}", model);
        }
        public void ShowFuel()
        {
            Console.WriteLine("Гориво: {0}", fuel);
        }
        public string HasDriver()
        {
            if (isDriver) return "Да";
            return "Не";
        }
        public int CalcNumberOfDays()
        {
            return (endDate.Date - startDate.Date).Days;
        }
        public double CalcAmount()
        {
            return price24 * CalcNumberOfDays();
        }
        public double CalcTotal()
        {
            const double DRIVER = 15;
            if(HasDriver() == "Да")
            {
                return CalcAmount() + CalcNumberOfDays() * DRIVER;
            }
            return CalcAmount();
        }
        public void Print()
        {
            ShowModel();
            ShowFuel();
            Console.WriteLine("Шофьор: {0}", HasDriver());
            Console.WriteLine("Дата на наемане: {0:d}", startDate);
            Console.WriteLine("Дата на връщане: {0:d}", endDate);
            Console.WriteLine("Брой дни на наемане на автомобила: {0}", CalcNumberOfDays());
            Console.WriteLine("Дължима сума: {0:c2}", CalcAmount());
            Console.WriteLine("Обща сума: {0:c2}", CalcTotal());
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Автомобили 'Опел' под наем");
            Console.WriteLine("--------------------------");

            Opel op1 = new Opel("Корса", "дизел", true, new DateTime(2020, 7, 5), new DateTime(2020, 7, 10), 25);
            op1.Print();
            Console.WriteLine();
            Opel op2 = new Opel("Вектра", "газ", false, new DateTime(2020, 7, 2), new DateTime(2020, 7, 15), 20);
            op2.Print();

            Console.ReadKey(true);
        }
    }
}
