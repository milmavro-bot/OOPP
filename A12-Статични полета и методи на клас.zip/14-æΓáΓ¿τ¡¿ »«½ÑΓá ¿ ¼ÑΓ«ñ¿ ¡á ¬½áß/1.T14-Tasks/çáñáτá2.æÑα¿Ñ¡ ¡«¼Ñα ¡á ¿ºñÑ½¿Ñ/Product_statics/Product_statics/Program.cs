﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 21.11.2020 г.
 * Time: 15:24
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Product_statics
{
	class Product
	{
		// Сериен номер на продукта – състои се от две латински букви (серия)
		// и двуцифрена числова част (номер) -
		// например АА00, АА01, …, АА99, АВ01, АВ02, …
		string serialNum;
		static string part = "AA";	// текуща серия
		static int amount = 0;		// брой на създадените продукти
		
		// Класът да съдържа публичен конструктор Product(),
		// който генерира серийния номер на новосъздадения обект
		// и го записва в полето serialNum.
		// За генерирането на серийния номер да се извиква статичния метод GetNextSN().
		// След това конструктора да увеличава броя на създадените продукти.
		public Product()
		{
			serialNum = GetNextSN();
			Product.amount++;
		}
		
		// Статичен метод string GetNextSN() – създава и връща като резултат поредния сериен номер.
		// Серийните номера са последователни,
		// като буквената част (серията) е една и съща за множество продукти.
		// Числовата част показва поредния номер на създадения продукт,
		// започва от 0 и нараства с 1.
		// Ако бъдат създадени повече от 99 продукта от една серия,
		// тогава трябва да се премине към нова серия.
		// Началната серия е АА,
		// следва АВ, после АС,  …, AZ, BA, BB, BC, …
		static string GetNextSN()
		{
			if(Product.amount % 100 == 0 && Product.amount > 0)
			{
				char fir = Product.part[0];
				char sec = Product.part[1];
				if (sec == 'Z')
				{
					sec = 'A';
					fir++;
				}
				else sec++;
				
				Product.part = fir + "" + sec;
			}
			return Product.part + string.Format("{0:d2}",Product.amount%100);
		}
		
		// Метод void PrintSN() – извежда на екрана информация за серийния номер на продукта.
		public void PrintSN()
		{
			Console.WriteLine("Създаден е нов продукт със сериен №: {0}", serialNum);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			int c = new Random().Next(50, 551);
			for (int i = 0; i < c; i++) {
				Product p = new Product();
				p.PrintSN();
			}
			Console.WriteLine("Създадени са общо {0} продукта!", c);
			
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}