﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 23.11.2020 г.
 * Time: 8:27
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace SerialNumber_11d
{
	class Product
	{
		string serialNum;
		static string part = "AA";
		static int amount = 0;
		
		public Product()
		{
			serialNum = GetNextSN();
			Product.amount++;
		}
		
		static string GetNextSN()
		{
			if(Product.amount % 100 == 0 && Product.amount > 0)
			{
				char fir = Product.part[0];
				char sec = Product.part[1];
				if(sec == 'Z')	//AZ => BA
				{
					sec = 'A';
					fir++;
				}
				else sec++;
				Product.part = fir + "" + sec;
			}
			return Product.part + string.Format("{0:d2}", Product.amount % 100);
		}
		
		public void PrintSN()
		{
			Console.WriteLine("Създаден е нов продукт със сериен №: {0}", serialNum);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			int c = new Random().Next(50, 551);
			for(int i = 0; i < c; i++)
			{
				Product p = new Product();
				p.PrintSN();
			}
			Console.WriteLine("Създадени са общо {0} продукта!", c);
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}