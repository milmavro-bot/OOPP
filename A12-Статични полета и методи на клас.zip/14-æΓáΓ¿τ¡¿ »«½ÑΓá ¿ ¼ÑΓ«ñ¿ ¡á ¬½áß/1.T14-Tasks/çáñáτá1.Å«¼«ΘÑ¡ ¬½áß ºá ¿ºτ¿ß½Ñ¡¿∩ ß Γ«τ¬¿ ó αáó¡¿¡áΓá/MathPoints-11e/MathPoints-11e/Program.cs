﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 20.11.2020 г.
 * Time: 11:45
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MathPoints_11e
{
	static class MathPoints2D
	{
		public static double DistanceBetween(double xA, double yA, double xB, double yB)
		{
			double d = Math.Sqrt(Math.Pow(xA - xB, 2) + Math.Pow(yA - yB, 2));
			return Math.Round(d, 3);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			//Console.WriteLine("Distance between: {0}", MathPoints2D.DistanceBetween(4, 8, 2, 6));
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}