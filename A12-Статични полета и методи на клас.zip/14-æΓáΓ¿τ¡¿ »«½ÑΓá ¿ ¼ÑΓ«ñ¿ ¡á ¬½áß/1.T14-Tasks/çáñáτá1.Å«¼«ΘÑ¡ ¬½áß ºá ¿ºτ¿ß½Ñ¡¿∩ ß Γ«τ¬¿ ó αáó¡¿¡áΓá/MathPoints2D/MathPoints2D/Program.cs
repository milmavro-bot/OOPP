﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 19.11.2020 г.
 * Time: 15:52
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MathPoints2D
{
	static class MathPoints2D
	{
		// Метод double DistanceBetween(double xA, double yA, double xB, double yB) –
		// пресмята и връща като резултат разстоянието между точка A(xА; yА) и точка В(хВ; уВ).
		// Резултатът да бъде закръглен до третия знак след десетичния разделител.
		public static double DistanceBetween(double xA, double yA, double xB, double yB) 
		{
			double d = Math.Sqrt(Math.Pow(xA-xB, 2) + Math.Pow(yA-yB, 2));
			return Math.Round(d, 3);
		}
		
		// Метод double DistanceToTheCenter(double x, double y) –  пресмята и връща като резултат
		// разстоянието от точка A(x; y) до центъра на правоъгълна координатна система – т. О(0; 0).
		// Резултатът да бъде закръглен до третия знак след десетичния разделител.
		public static double DistanceToTheCenter(double x, double y) 
		{
			return MathPoints2D.DistanceBetween(0, 0, x, y);
		}
		
		// Метод string TriangleТype(double xA, double yA, double xB, double yB, double xC, double yC) –
		// определя и връща като резултат вида (според страните) на триъгълник с върхове т. A(xА; yА),
		// т. В(хВ; уВ) и т. C(хC; уC).
		// Възможните резултати са:
		// "равностранен", "равнобедрен", "разностранен" и "не съществува".
		public static string TriangleТype(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			double ab = MathPoints2D.DistanceBetween(xA, yA, xB, yB);
			double ac = MathPoints2D.DistanceBetween(xA, yA, xC, yC);
			double bc = MathPoints2D.DistanceBetween(xC, yC, xB, yB);
			if(ab == 0 || ac == 0 || bc == 0 || ab == ac + bc || ac == ab + bc || bc == ab + ac) return "не съществува";
			if (ab == ac && ab == bc) return "равностранен";
			if (ab == ac || ab == bc || ac == bc) return "равнобедрен";
			return "разностранен";
		}
		
		// Метод double TrianglePerimeter(double xA, double yA, double xB, double yB, double xC, double yC) –
		// пресмята и връща като резултат обиколката на триъгълник с върхове:
		// т. A(xА; yА), т. В(хВ; уВ) и т. C(хC; уC).
		// Резултатът да бъде закръглен до третия знак след десетичния разделител.
		public static double TrianglePerimeter(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			if(MathPoints2D.TriangleТype(xA, yA, xB, yB, xC, yC) == "не съществува") return 0;
			double ab = MathPoints2D.DistanceBetween(xA, yA, xB, yB);
			double ac = MathPoints2D.DistanceBetween(xA, yA, xC, yC);
			double bc = MathPoints2D.DistanceBetween(xC, yC, xB, yB);
			
			return ab + ac + bc;
		}
		
		// Метод double TriangleArea(double xA, double yA, double xB, double yB, double xC, double yC) –
		// пресмята и връща като резултат лицето на триъгълник с върхове:
		// т. A(xА; yА), т. В(хВ; уВ) и т. C(хC; уC).
		// Резултатът да бъде закръглен до третия знак след десетичния разделител.
		public static double TriangleArea(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			if(MathPoints2D.TriangleТype(xA, yA, xB, yB, xC, yC) == "не съществува") return 0;
			double ab = MathPoints2D.DistanceBetween(xA, yA, xB, yB);
			double ac = MathPoints2D.DistanceBetween(xA, yA, xC, yC);
			double bc = MathPoints2D.DistanceBetween(xC, yC, xB, yB);
			
			double p = (ab + ac + bc)/2;
			double area = Math.Sqrt(p*(p-ab)*(p-ac)*(p-bc));
			return Math.Round(area, 3);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Въведете координати за точка А");
			Console.Write("x = ");
			double xA = double.Parse(Console.ReadLine());
			Console.Write("y = ");
			double yA = double.Parse(Console.ReadLine());
			
			Console.WriteLine("Въведете координати за точка B");
			Console.Write("x = ");
			double xB = double.Parse(Console.ReadLine());
			Console.Write("y = ");
			double yB = double.Parse(Console.ReadLine());
			
			Console.WriteLine("Въведете координати за точка C");
			Console.Write("x = ");
			double xC = double.Parse(Console.ReadLine());
			Console.Write("y = ");
			double yC = double.Parse(Console.ReadLine());
			
			
			Console.Write("Дължини на отсечки: OA = {0}", MathPoints2D.DistanceToTheCenter(xA, yA));
			Console.Write("   OB = {0}", MathPoints2D.DistanceToTheCenter(xB, yB));
			Console.Write("   OC = {0}", MathPoints2D.DistanceToTheCenter(xC, yC));
			Console.Write("   AB = {0}", MathPoints2D.DistanceBetween(xA, yA, xB, yB));
			Console.Write("   AC = {0}", MathPoints2D.DistanceBetween(xA, yA, xC, yC));
			Console.WriteLine("   BC = {0}", MathPoints2D.DistanceBetween(xC, yC, xB, yB));	
			Console.WriteLine("Тип на триъгълник АВС - {0}", MathPoints2D.TriangleТype(xA, yA, xB, yB, xC, yC));
			Console.WriteLine("Обиколка на триъгълник АВС - {0}", MathPoints2D.TrianglePerimeter(xA, yA, xB, yB, xC, yC));
			Console.WriteLine("Лице на триъгълник АВС - {0}", MathPoints2D.TriangleArea(xA, yA, xB, yB, xC, yC));
			Console.ReadKey(true);
		}
	}
}