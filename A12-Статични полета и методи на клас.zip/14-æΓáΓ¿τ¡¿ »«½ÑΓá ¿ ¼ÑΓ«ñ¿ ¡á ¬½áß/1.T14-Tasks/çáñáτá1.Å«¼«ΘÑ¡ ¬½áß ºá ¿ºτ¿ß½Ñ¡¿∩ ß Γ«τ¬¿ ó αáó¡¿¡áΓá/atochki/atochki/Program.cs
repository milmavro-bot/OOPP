﻿/*
 * Created by SharpDevelop.
 * User: Mitko
 * Date: 11/25/2020
 * Time: 12:11 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace atochki
{
	class MathPoints
	{
		static bool DoesntExist=false;
		public static double DistanceToCenter(double x, double y)
		{
			return Math.Round(Math.Sqrt(x*x + y*y), 3);
		}
		public static double DistanceBetween(double xA, double yA, double xB, double yB)
		{
			return Math.Round(Math.Sqrt((xB-xA)*(xB-xA) + (yB-yA)*(yB-yA)),3);
		}
		public static string TriangleType(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			double ab=MathPoints.DistanceBetween(xA, yA, xB, yB);
			double bc=MathPoints.DistanceBetween(xB, yB, xC, yC);
			double ac=MathPoints.DistanceBetween(xA, yA, xC, yC);
			if( ab==0 || ac==0 || bc==0 || ab>=ac+bc || ac>=ab+bc || bc>=ac+ab) 
			{
				MathPoints.DoesntExist=true; 
				return "Не съществува";
			}
			if(ab==ac && ab==bc) {MathPoints.DoesntExist=false; return "Триъгълникът е равностранен";}
			if(ab==ac || ac==bc || ab==bc) {MathPoints.DoesntExist=false; return "Триъгълника е равнобедрен";}
			return "Разностранен";
		}
		public static double TrianglePerimeter(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			double ab=MathPoints.DistanceBetween(xA, yA, xB, yB);
			double bc=MathPoints.DistanceBetween(xB, yB, xC, yC);
			double ac=MathPoints.DistanceBetween(xA, yA, xC, yC);
			//if(MathPoints.DoesntExist=true) return 0;
			return ab+ac+bc;
		}
		public static double TriangleArea(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			double ab=MathPoints.DistanceBetween(xA, yA, xB, yB);
			double bc=MathPoints.DistanceBetween(xB, yB, xC, yC);
			double ac=MathPoints.DistanceBetween(xA, yA, xC, yC);
			//if(MathPoints.DoesntExist=true) return 0;
			return Math.Sqrt((ab+bc+ac)/2 * ((ab+bc+ac)/2 - ab) * ((ab+bc+ac)/2 -bc) * ((ab+bc+ac)/2 - ac));
		}
		public void Print()
		{
			Console.WriteLine("Enter p.A coordinates");
			Console.Write("x= ");
			double xA=double.Parse(Console.ReadLine());
			Console.Write("y= ");
			double yA=double.Parse(Console.ReadLine());
			Console.WriteLine("Enter p.B coordinates");
			Console.Write("x= ");
			double xB=double.Parse(Console.ReadLine());
			Console.Write("y= ");
			double yB=double.Parse(Console.ReadLine());
			Console.WriteLine("Enter p.C coordinates");
			Console.Write("x= ");
			double xC=double.Parse(Console.ReadLine());
			Console.Write("y= ");
			double yC=double.Parse(Console.ReadLine());
			double ab=MathPoints.DistanceBetween(xA, yA, xB, yB);
			double bc=MathPoints.DistanceBetween(xB, yB, xC, yC);
			double ac=MathPoints.DistanceBetween(xA, yA, xC, yC);
			double oa=MathPoints.DistanceToCenter(xA, yA);
			double ob=MathPoints.DistanceToCenter(xB, yB);
			double oc=MathPoints.DistanceToCenter(xC, yC);
			Console.WriteLine("Line lenghts: OA = {0}  OB = {1}  OC = {2}  AB = {3}  BC = {4}  AC = {5}", oa, ob, oc, ab, bc, ac);
			Console.WriteLine("Triangle type: {0}", MathPoints.TriangleType(xA, yA, xB, yB, xC, yC));
			Console.WriteLine("Triangle Perimeter: {0}", MathPoints.TrianglePerimeter(xA, yA, xB, yB, xC, yC));
			Console.WriteLine("Triangle Area: {0}", MathPoints.TriangleArea(xA, yA, xB, yB, xC, yC));
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.OutputEncoding = System.Text.Encoding.Unicode;
			Console.InputEncoding = System.Text.Encoding.Unicode;
			MathPoints a=new MathPoints();
			a.Print();
			Console.ReadKey(true);
		}
	}
}