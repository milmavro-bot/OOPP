﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 20.11.2020 г.
 * Time: 10:12
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MathPoints_11d
{
	static class MathPoints2D
	{
		public static double DistanceBetween(double xA, double yA, double xB, double yB)
		{
			double d = Math.Sqrt(Math.Pow(xA - xB, 2) + Math.Pow(yA - yB, 2));
			return Math.Round(d, 3);
		}
		public static double DistanceToTheCenter(double x, double y)
		{
			return MathPoints2D.DistanceBetween(0, 0, x, y);
		}
		public static string TriangleType(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			double ab = MathPoints2D.DistanceBetween(xA, yA, xB, yB);
			double ac = MathPoints2D.DistanceBetween(xA, yA, xC, yC);
			double bc = MathPoints2D.DistanceBetween(xB, yB, xC, yC);
			if(ab == 0 || ac == 0 || bc == 0 || ab <= ac + bc || bc <= ab + ac) return "не съществува";
			if(ab == ac && ab == bc) return "равностранен";
			if(ab == ac || ab == bc || ac == bc) return "равнобедрен";
			return "разностранен";
		}
		public static double TrianglePerimeter(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			if(MathPoints2D.TriangleType(xA, yA, xB, yB, xC, yC) == "не съществува") return 0;
			double ab = MathPoints2D.DistanceBetween(xA, yA, xB, yB);
			double ac = MathPoints2D.DistanceBetween(xA, yA, xC, yC);
			double bc = MathPoints2D.DistanceBetween(xB, yB, xC, yC);
			return ab + ac + bc;
		}
		public static double TriangleArea(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			if(MathPoints2D.TriangleType(xA, yA, xB, yB, xC, yC) == "не съществува") return 0;
			double ab = MathPoints2D.DistanceBetween(xA, yA, xB, yB);
			double ac = MathPoints2D.DistanceBetween(xA, yA, xC, yC);
			double bc = MathPoints2D.DistanceBetween(xB, yB, xC, yC);
			
			double p = (ab + ac + bc) / 2;
			double area = Math.Sqrt(p * (p - ab) * (p - ac) * (p - bc));
			return Math.Round(area, 3);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}