﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 24.11.2020 г.
 * Time: 7:51
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MathPoints2D_11v
{
	static class MathPoints2D
	{
		public static double DistanceBetween(double xA, double yA, double xB, double yB)
		{
			double d = Math.Sqrt(Math.Pow(xA - xB, 2) + Math.Pow(yA - yB, 2));
			return Math.Round(d, 3);
		}
		public static double DistanceToTheCenter(double x, double y)
		{
			return MathPoints2D.DistanceBetween(0, 0, x, y);
		}
		public static string TriangleType(double xA, double yA, double xB, double yB, double xC, double yC)
		{
			double ab = MathPoints2D.DistanceBetween(xA, yA, xB, yB);
			double ac = MathPoints2D.DistanceBetween(xA, yA, xC, yC);
			double bc = MathPoints2D.DistanceBetween(xB, yB, xC, yC);
			if(ab == 0 || ac == 0 || bc == 0 || ab >= ac + bc || ac >= ab + bc || bc >= ab + ac)
			{
				return "не съществува";
			}
			if(ab == ac && ab == bc)
			{
				return "равностранен";
			}
			if(ab == ac || ab == bc || ac == bc)
			{
				return "равнобедрен";
			}
			return "разностранен";
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine(MathPoints2D.DistanceBetween(4, -2, -1, 3));
			Console.WriteLine(MathPoints2D.DistanceToTheCenter(5, -8));
			Console.WriteLine(MathPoints2D.TriangleType(2, 3, 5, -1, -1.5, -2));
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}