﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 23.11.2020 г.
 * Time: 10:06
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace MathPoints2D_11a
{
	class MathPoints2D
	{
		public static double DistanceBetween(double xA, double yA, double xB, double yB)
		{
			double d = Math.Sqrt(Math.Pow(xA - xB, 2) + Math.Pow(yA - yB, 2));
			return Math.Round(d, 3);
		}
		public static double DistanceToTheCenter(double x, double y)
		{
			return MathPoints2D.DistanceBetween(0, 0, x, y);
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine(MathPoints2D.DistanceBetween(-4, 2, 3, 6));
			Console.WriteLine(MathPoints2D.DistanceToTheCenter(5, 4));
			Console.WriteLine(Math.Log(2));
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}