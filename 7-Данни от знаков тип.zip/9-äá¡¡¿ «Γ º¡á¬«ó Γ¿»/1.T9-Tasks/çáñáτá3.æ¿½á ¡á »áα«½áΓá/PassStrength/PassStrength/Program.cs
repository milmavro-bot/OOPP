﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 19.10.2020 г.
 * Time: 9:33
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace PassStrength
{
	class PasswordStrength
	{
		string pswd;
		int strength;
		
		// Конструктор
		public PasswordStrength(string pass)
		{
			pswd = pass;
			strength = GetStrength();
		}
		
		// Метод int GetStrength() – „пресмята“ и връща силата на записаната в полето pswd парола
		// според следните изисквания:
		//    - Състои се от поне 12 знака;
		//    - Съдържа поне 1 главна буква;
		//    - Съдържа поне 1 малка буква;
		//    - Съдържа поне 1 цифра;
		//    - Съдържа поне 1 пунктуационен знак или друг символ.
		// Всяко спазено изискване увеличава силата на паролата с 1.
		// Така максималната сила е 5, а минималната сила е 0.
		int GetStrength()
		{
			int str = 0;
			if(pswd.Length >= 12) { str++; }
			int fUpper = 0, fLower = 0, fNumber = 0, fSpec = 0;
			for(int i = 0; i < pswd.Length; i++)
			{
				if(Char.IsUpper(pswd[i])) { fUpper = 1; }
				if(Char.IsLower(pswd[i])) { fLower = 1; }
				if(Char.IsNumber(pswd[i])) { fNumber = 1; }
				if(Char.IsSymbol(pswd[i]) || Char.IsPunctuation(pswd[i])) { fSpec = 1; }
			}
			str = str + fUpper + fLower + fNumber + fSpec;
			return str;
		}
		// Метод void PrintEvaluation() – проверява записаната в полето strength сила на паролата и
		// извежда на екрана следната информация:
		// 5: This password is strong enough – 5 / 5
		// 4: This password is relatively strong – 4 / 5
		// 3: This password is not strong enough – 3 / 5
		// 2: This password is weak – 2 / 5
		// 1: This password is extremely weak – 1 / 5
		// 0: This password is a failure – 0 / 5
		public void PrintEvaluation()
		{
			switch (strength) {
					case 0: Console.WriteLine("This password is a failure - 0 / 5"); break;
					case 1: Console.WriteLine("This password is extremaly weak - 1 / 5"); break;
					case 2: Console.WriteLine("This password is weak – 2 / 5"); break;
					case 3: Console.WriteLine("This password is not strong enough – 3 / 5"); break;
					case 4: Console.WriteLine("This password is relatively strong – 4 / 5"); break;
					case 5: Console.WriteLine("This password is strong enough – 5 / 5"); break;
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Enter a password to check its strength: ");
			string psw = Console.ReadLine();
			
			// Създава обект от класа PasswordStrength, като паролата се въвежда от клавиатурата
			PasswordStrength ps = new PasswordStrength(psw);
			
			// Извежда оценка за силата на паролата, описана в този обект, чрез извикване на съответния метод
			ps.PrintEvaluation();
			
			Console.ReadKey(true);
		}
	}
}