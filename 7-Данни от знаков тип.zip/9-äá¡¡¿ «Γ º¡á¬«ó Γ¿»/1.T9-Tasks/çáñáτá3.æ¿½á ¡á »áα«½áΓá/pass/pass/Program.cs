﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 19.10.2020 г.
 * Time: 10:42
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace pass
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Enter password: ");
			string pswd = Console.ReadLine();
			int str = 0, b = 0;
			if(pswd.Length >= 12) { b++; str = b;}
			b = 0;
			for(int i = 0; i < pswd.Length; i++)
			{
				if(Char.IsUpper(pswd[i])) { b++; }
			}
			if(b >= 1) { str++; }
			b = 0;
			for(int i = 0; i < pswd.Length; i++)
			{
				if(Char.IsLower(pswd[i])) { b++; }
			}
			if(b >= 1) { str++; }
			b = 0;
			for(int i = 0; i < pswd.Length; i++)
			{
				if(Char.IsDigit(pswd[i])) { b++; }
			}
			if(b >= 1) { str++; }
			b = 0;
			for(int i = 0; i < pswd.Length; i++)
			{
				if(Char.IsPunctuation(pswd[i]) || Char.IsSymbol(pswd[i]) || Char.IsWhiteSpace(pswd[i])) { b++; }
			}
			if(b >= 1) { str++; }
			Console.WriteLine(str);
			
			Console.ReadKey(true);
		}
	}
}