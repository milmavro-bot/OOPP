﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 23.10.2020 г.
 * Time: 16:39
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EncryptionFactory
{
	class Encryption
	{
		string message;
		string action;
		
		// Конструктор
		public Encryption(string m, string a)
		{
			message = m; action = a;
		}
		
		// Метод string Encode() – връща като резултат текст, образуван от долепените плътно едно до друго числа,
		// получени по формулата (300 – числовия код на поредния символ от съобщението).
		// Всяко число да е представено с точно 3 знака.
		// Пример: “come asap” се кодира ето така “201189191199268203185203188”,
		// защото:
		// числовият код на ‘c’ e 99 => 300 – 99 = 201;
		// числовият код на ‘о’ e 111 => 300 – 111 = 189; …
		string Encode() 
		{
			string enc = "";
			
			for (int i = 0; i < message.Length; i++) {
				enc += (300 - message[i]).ToString();
			}
			return enc;
		}
		// Метод string Decode() – връща като резултат текст, образуван от дешифрираната числова версия на текста,
		// по следната схема:
		//  - Образува се числото, записано с първите 3 цифри в числовото съобщение;
		// 	- От 300 се изважда това число;
		// 	- Получената стойност е числовият код на символа, който се добавя към дешифрираното съобщение;
		// 	- Продължава се нататък със следващите 3 цифри от числовото съобщение до изчерпването му.
		
		// Пример: “185203182199268191199” се декодира като “save me”, защото
		// първите 3 цифри образуват 185, 300 – 185 = 115, числовият код 115 е на ‘s’ =>”s”; 
		// следващите 3 цифри „правят“ 203, 300 – 203 = 97, числовият код 97 е на ‘а’ =>”sа”;
		// следващите 3 цифри „правят“ 182, 300 – 182 = 118, числовият код 118 е на ‘v’ =>”sаv”;
		// следващите 3 цифри „правят“ 199, 300 – 199 = 101, числовият код 101 е на ‘e’ =>”sаve”;
		// следващите 3 цифри „правят“ 268, 300 – 268 = 32, числовият код 32 е на ‘ ’ =>”sаve ”;
		// следващите 3 цифри „правят“ 191, 300 – 191 = 109, числовият код 101 е на ‘m’ =>”sаve m”;
		// последните 3 цифри „правят“ 199, 300 – 199 = 101, числовият код 101 е на ‘e’ =>”sаve me”;
		string Decode()
		{
			string dec = "";
			
			for (int i = 0; i < message.Length; i += 3) {
				int a = (message[i] - '0') * 100 + (message[i + 1] - '0') * 10 + (message[i + 2] - '0');
				dec += (char)(300 - a);
			}
			return dec;
		}
		// Метод void PrintMessage() – проверява записаната в полето action стойност и
		// извежда на екрана следната информация:
		// action | На екрана се извежда
		// -----------------------------
		// encode | кодираното само с числа съобщение
		// decode | декодираната версия на съобщението
		public void PrintMessage()
		{
			Console.WriteLine(new String('-', 50));
			if(action == "encode") Console.WriteLine(Encode());
			else Console.WriteLine(Decode());
			Console.WriteLine(new String('-', 50));
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Enter a message:");
			string m1 = Console.ReadLine();
			Console.Write("Choose an action (encode/decode): ");
			string a1 = Console.ReadLine();
			
			// Създава обект е1 от класа Encryption, като съдържанието на съобщението и командата за
			// действие се въвеждат от клавиатурата по показания на изображенията модел
			Encryption e1 = new Encryption(m1, a1);
			e1.PrintMessage();
			
			Console.WriteLine("Enter a message:");
			string m2 = Console.ReadLine();
			Console.Write("Choose an action (encode/decode): ");
			string a2 = Console.ReadLine();
			
			// Създава обект е2 от класа Encryption, като съдържанието на съобщението и командата за
			// действие се въвеждат от клавиатурата по показания на изображенията модел
			Encryption e2 = new Encryption(m2, a2);
			e2.PrintMessage();
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}