﻿/*
 * Created by SharpDevelop.
 * User: Nicol
 * Date: 28.10.2020 г.
 * Time: 22:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace words_chars
{
	class Words
	{
		string txt;
		char letter;
		public Words(string tx, char lt)
		{
			txt = tx.Trim();
			letter = lt;
			Console.WriteLine("Number of words containing letter '{0}': {1}",letter,CountWordsWithLetter());
			Console.WriteLine("Number of letters in the shortest word: {0}",ShortestWord());
			Console.WriteLine("Number of letters in the longest word: {0}",LongestWord());
		}
		int CountWordsWithLetter()
		{
			int br=0, brl=0;
			txt+="";
			for(int i=0;i<txt.Length;i++)
			{
				if(txt[i]==letter)
				{
					brl++;
				}
				else if(txt[i]==' ')
				{
					if(brl>=1) br++;
					brl=0;
				}
			}
			return br;
		}
		int ShortestWord()
        {
			int twl = 0, min = 0;
			for(int i=0; i<txt.Length; i++)
			{
				/*if(Char.IsLetter(txt[i])==true)
				{
					twl++;
				}
				if(txt[i]==' ')
				{
					if(twl<min) min=twl;
					twl=0;
				}*/
				if(txt[i] == ' ')
				{
					if(((twl < min) || (min == 0)) && (twl != 0)) { min = twl; }
					twl = 0;
				}
				else { twl++; }
			}
			return min;
        }
		int LongestWord()
        {
			int twl = 0, max = 0;
			for(int i=0; i<txt.Length; i++)
			{
				if(Char.IsLetter(txt[i])==true)
				{
					twl++;
				}
				if(txt[i]==' ')
				{
					if(twl>max) max=twl;
					twl=0;
				}
			}
			return max;
        }
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Enter words in English:");
			string wrds = Console.ReadLine();
			Console.Write("Enter a letter in English: ");
			char lt = char.Parse(Console.ReadLine());
			Words w1 = new Words(wrds,lt);
			Console.ReadKey(true);
		}
	}
}