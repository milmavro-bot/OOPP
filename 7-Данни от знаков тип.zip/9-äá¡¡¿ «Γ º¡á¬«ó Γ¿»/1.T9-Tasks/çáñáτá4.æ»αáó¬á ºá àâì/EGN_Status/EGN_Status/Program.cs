﻿/*
 * Created by SharpDevelop.
 * User: Milen
 * Date: 22.10.2020 г.
 * Time: 9:21
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EGN_Status
{
	class Program
	{
		public static void Main(string[] args)
		{
			string egn, status = "";
			
			Console.Write("Enter EGN: ");
			egn = Console.ReadLine();
			
			// Състои се от точно 10 символа.
			// ...
			
			// Всеки от символите е десетична цифра.
			// ...
			// Char.IsDigit(...)
			
			// Първите 6 цифри (от ляво надясно) съдържат информация за валидна дата във формат
			// ггммдд (за дати от ХХ век) или гг(40+м)дд (за дати от XXI век). Тоест 931119 е запис за
			// 19 ноември 1993, докато 025009 е запис за 09 октомври (40+10) 2002 година.
			int year = 1900 + (egn[0] - '0') * 10 + (egn[1] - '0'); // 7212010941: 1900 + (7) * 10 + (2) = 1972
			int month = (egn[2] - '0') * 10 + (egn[3] - '0');		// (1) * 10 + 2 = 12
			int day = (egn[4] - '0') * 10 + (egn[5] - '0');			// (0) * 10 + (1) = 1
			if(month > 40 && month < 53)
			{
				year += 100;
				month -= 40;
			}
			DateTime bd = new DateTime();
			
			try {
				bd = new DateTime(year, month, day);
			} catch (Exception) {
				status = "Incorrect date";
			}
			
			// Десетата цифра е контролна и се получава чрез събиране на произведенията от
			// числовите стойности на всяка от първите
			// девет цифри в номера и съответна
			// „тежест“ на позицията
			
			// Позиция: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9
			// Тежест:  2 | 4 | 8 | 5 | 10| 9 | 7 | 3 | 6
			
			// Получената сума се дели на 11 и се намира остатъкът от това деление
			// Ако остатъкът е под 10 – това е контролната цифра, а ако е 10 – контролната цифра е 0
			// Примерен запис: 9305141143
			// Проверка: 9.2 + 3.4 + 0.8 + 5.5 + 1.10 + 4.9 + 1.7 + 1.3 + 4.6 = 18 + 12 + 0 + 25 + 10 + 36 + 7 +
			// 3 + 24 = 65 + 46 + 24 = 65 + 70 = 135,   135 : 11 = 12 и остатък 3 => контролната цифра е 3
			int sum = (egn[0] - '0') * 2 + (egn[1] - '0') * 4 + (egn[2] - '0') * 8 + (egn[3] - '0') *5  +
				(egn[4] - '0') * 10 + (egn[5] - '0') * 9 + (egn[6] - '0') * 7 + (egn[7] - '0') * 3 + (egn[8] - '0') * 6;
			if((sum % 11) % 10 != (egn[9] - '0'))
			{
				status = "Incorrect control digit";
			}
			status = string.Format("Birth date: {0,-15:dd.MM.yyyy}Sex: ", bd);
			Console.WriteLine(status);
			
			// Проверка на пола
			if((egn[8] - '0') % 2 == 0)
			{
				status += "male";
			}
			else
			{
				status += "female";
			}
			
			Console.ReadKey(true);
		}
	}
}