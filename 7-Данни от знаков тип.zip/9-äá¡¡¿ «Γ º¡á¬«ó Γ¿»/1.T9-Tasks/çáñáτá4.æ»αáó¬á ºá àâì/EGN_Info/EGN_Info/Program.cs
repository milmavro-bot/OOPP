﻿/*
 * Created by SharpDevelop.
 * User: pc3
 * Date: 21.10.2020 г.
 * Time: 17:03
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace EGN_Info
{
	class Personal_Id
	{
		string pid, status;
		bool isOK;
		
		// Конструктор
		public Personal_Id(string t)
		{
			pid = t;
			CheckStatus();
		}
		
		// Проверява дали записаното в pid е валидно ЕГН или не
		// и записва в полето isOK true/false
		// В полето status методът записва или грешката (нарушението) в записа,
		// поради която това не е валиден ЕГН запис,
		// или рождената дата и пола на човека,
		// който би имал такъв ЕГН.
		void CheckStatus()
		{
			// Състои се от точно 10 символа
			if(pid.Length != 10 )
			{
				isOK = false;
				status = "Incorrect number of symbols";
				return; // излиза от метода
			}
			// Всеки от символите е десетична цифра.
			for (int i = 0; i < 10; i++) 
			{
				if(! char.IsDigit(pid[i]) )
				{
					isOK = false;
					status = "Invalid symbol(s) detected";
					return;
				}
			}
			
			// Първите 6 цифри (от ляво надясно) съдържат информация за валидна дата във формат
			// ггммдд (за дати от ХХ век) или гг(40+м)дд (за дати от XXI век). Тоест 931119 е запис за
			// 19 ноември 1993, докато 025009 е запис за 09 октомври (40+10) 2002 година.
			int year = 1900 + (pid[0] - '0') * 10 + (pid[1]-'0');
			int month = (pid[2] - '0') * 10 + (pid[3]-'0');
			int day = (pid[4] - '0') * 10 + (pid[5]-'0');
			if (month > 40 && month < 53) 
			{
				year += 100;
				month -= 40;
			}
			DateTime bd;
			
			// Проверката за валидност става най-лесно чрез конструкцията try...catch
			try
			{
				bd = new DateTime(year, month, day);
			} 
			catch (Exception) 
			{
					isOK = false;
					status = "Incorrect date";
					return;
			}
			
			// Десетата цифра е контролна и се получава чрез събиране на произведенията от
			// числовите стойности на всяка от първите
			// девет цифри в номера и съответна
			// „тежест“ на позицията
			
			// Позиция: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9
			// Тежест:  2 | 4 | 8 | 5 | 10| 9 | 7 | 3 | 6
			
			// Получената сума се дели на 11 и се намира остатъкът от това деление
			// Ако остатъкът е под 10 – това е контролната цифра, а ако е 10 – контролната цифра е 0
			// Примерен запис: 9305141143
			// Проверка: 9.2 + 3.4 + 0.8 + 5.5 + 1.10 + 4.9 + 1.7 + 1.3 + 4.6 = 18 + 12 + 0 + 25 + 10 + 36 + 7 +
			// 3 + 24 = 65 + 46 + 24 = 65 + 70 = 135,   135 : 11 = 12 и остатък 3 => контролната цифра е 3
			int sum = (pid[0] - '0') * 2 + (pid[1] - '0') * 4 + (pid[2] - '0') * 8 + (pid[3] - '0') * 5 + (pid[4] - '0') * 10 +
				(pid[5] - '0') * 9 + (pid[6] - '0') * 7 + (pid[7] - '0') * 3 + (pid[8] - '0') * 6;
			if ((sum % 11) % 10 != (pid[9] - '0'))
			{
				isOK = false;
				status = "Incorrect control digit";
				return;
			}
			isOK = true;
			
			// Форматиране на датата
			status = string.Format ("Birth date: {0,-15:dd.MM.yyyy}Sex: ", bd);
			
			// Проверка на пола
			if ((pid[8] - '0') % 2 == 0)
			{
				status += "male";
			}
			else
			{
				status += "female";
			}
		}
		
		// Проверява записаната в полето isOK стойност и извежда на екрана следната информация:
		// isOK	|	На екрана се извежда
		// -----------------------------
		// False|	********** is not a valid PID record.
		//		|	Error: @@@@@
		// True |	********** is a valid PID record.
		// 		|	Record data:
		// 		|	@@@@@
		// На мястото на ********* се извежда стойността на полето pid,
		// а на мястото на @@@@@ се извежда
		// стойността на полето status.
		public void PrintInfo()
		{
			if(isOK)
			{
				Console.WriteLine("{0} is a valid PID record" + Environment.NewLine + "Record data:{2}{1}",
				                  pid, status, Environment.NewLine);
			}
			else 
			{
				Console.WriteLine("{0} is NOT a valid PID record" + Environment.NewLine + "Error: {1}", pid, status);
			}
		}
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.Write("Enter a test data: ");
			Personal_Id p = new Personal_Id(Console.ReadLine());
			p.PrintInfo();
			
			// TODO: Implement Functionality Here
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}