﻿/*
 * Created by SharpDevelop.
 * User: mega
 * Date: 10/23/2020
 * Time: 10:34 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace WordCount
{
	class WordsCounter
	{
		string wrds;
		public WordsCounter(string s)
		{
			wrds = s;
		}
		public int CountWords()
		{
			int fl = 0;
			for(int i = 0; i < wrds.Length; i++ )
			{
				if(!Char.IsWhiteSpace(wrds[i]))
				{
					while(!Char.IsWhiteSpace(wrds[i]) && i < wrds.Length-1)i++;
					fl++;
				}
			}
			return fl;
		}                       
	}
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Enter text:");
			string t = Console.ReadLine();
			WordsCounter w1 = new WordsCounter(t);
			Console.WriteLine("Number of words in the text: {0}", w1.CountWords());
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}