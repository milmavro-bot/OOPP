﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordsCounter
{
    public class WordsCounter
    {
        public string wrds { get; set; }
        public WordsCounter(string wr)
        {
            this.wrds = wr;
        }
        public int CountWords() => this.wrds.Split(' ').Count();
    }
    class Program
    {
        static void Main(string[] args)
        {
            WordsCounter wc = new WordsCounter(Console.ReadLine());
            Console.WriteLine(wc.CountWords());
        }
    }
}
